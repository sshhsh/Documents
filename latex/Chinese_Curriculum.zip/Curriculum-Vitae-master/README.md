# Curriculum-Vitae
This Repository is the latex code of my CV

The current version of the CV is a 2 pages pdf including Education, Programming Skills, Experience & Research, Selected Curriculum Design, Honor & Awards and Miscellaneous. 
