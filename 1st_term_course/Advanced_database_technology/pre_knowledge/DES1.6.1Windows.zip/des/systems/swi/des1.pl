/*********************************************************/
/*                                                       */
/* DATALOG Educational System v.1.6.0                    */
/*                                                       */
/*    SYSTEM DEPENDENT PREDICATES 2                      */
/*    Tested for SWI-Prolog 5.6.55                       */
/*                                                       */
/*                                                       */
/*                                                       */
/*                          Fernando S�enz (c) 2004-2008 */
/*                                               SIP UCM */
/*             Please send comments, questions, etc. to: */
/*                                     fernan@sip.ucm.es */
/*                                                Visit: */
/*                           http://des.sourceforge.net/ */
/*                                                       */
/*********************************************************/


false :-
  fail.

% Current opened streams
my_current_stream(St) :-
  bagof(OSt,X^Y^current_stream(X,Y,OSt),OSts),
  my_memberchk(St,OSts), !.

% Executing operating system commands
my_shell(C,S) :-
  name(C,SC),
  ((shell(SC,0), S=0);                                           %Unix
   (concatLsts(["cmd.exe /C ",SC],SCC), shell(SCC,0), S=0);      %Windows NT
   (concatLsts(["command.exe /C ",SC],SCC), shell(SCC,0), S=0);  %Windows 98
   S=1),
  !.

% Date and time
my_datetime((Y,M,D,H,Mi,S)) :-
  get_time(TS),
  stamp_date_time(TS,date(Y,M,D,H,Mi,Se,_,_,_),local),
  S is integer(Se).
  
% Sorting a list, removing duplicates
my_sort(List, Orderedlist) :-
  sort(List, Orderedlist).

% Changing the current directory
my_change_directory(Path) :-
  chdir(Path).

% Testing whether exists the given directory
my_directory_exists(Path) :-
  exists_directory(Path).

% Testing whether exists the given file
my_file_exists(File) :-
  exists_file(File).

% Getting the current directory
my_working_directory(Path) :-
  absolute_file_name(., Path).

% Getting the ordered list of files from the given path
my_directory_files(Path, List) :-
  absolute_file_name(., WorkingPath),
  absolute_file_name(Path, AbsolutePath),
  chdir(AbsolutePath),
  expand_file_name('*', UnorderedList),
  chdir(WorkingPath),
  sort(UnorderedList, List).

% Testing whether the input is a file
my_is_file(File) :-
  exists_file(File).

% Testing whether the input is a directory
my_is_directory(Path) :-
  exists_directory(Path).

% Getting the absolute filename for a file
my_absolute_filename(Path, AbsolutePath) :-
  absolute_file_name(Path, AbsolutePath).

% Extracting the absolute path and file from an absolute file name
my_dir_file(AFN,AP,FN) :-
  file_directory_name(AFN,AP),
  atom_concat(AP,'/',PS),
  atom_concat(PS,FN,AFN).

% Gets a byte from the handle (Edinburgh version)
my_get0(HIn,C) :- get0(HIn,C).

% Gets a byte from the current handle (Edinburgh version)
my_get0(C) :- get0(C).

% Reading terms along with variable names and its scope in line numbers
% TODO: Get line numbers
my_read(Term, VariableNames, (0,0)) :-
  read_term(Term, [variable_names(VariableNames)]).
  
% Timing: Resetting and displaying the elapsed time
:- dynamic(time/1).

reset_elapsedtime :-
  get_time(T),
  retractall(time(_)),
  assertz(time(T)).

display_elapsedtime :-
  timing(Switch),
  (Switch==on ->
   time(T1),
   get_time(T2),
   Elapsed is integer(1000*(T2-T1)),
   write_log_list(['Info: Elapsed time: ',Elapsed,' ms.',nl])
   ;
   true).

