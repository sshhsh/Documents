/*********************************************************/
/*                                                       */
/* DATALOG Educational System v.1.6.0                    */
/*                                                       */
/*    SYSTEM DEPENDENT PREDICATES 2                      */
/*    Tested for CIAO Prolog 1.10p5                      */
/*                                                       */
/*                                                       */
/*                                                       */
/*                          Fernando S�enz (c) 2004-2008 */
/*                                             DISIA UCM */
/*             Please send comments, questions, etc. to: */
/*                                     fernan@sip.ucm.es */
/*                                Visit the Web site at: */
/*                           http://des.sourceforge.net/ */
/*                                                       */
/*********************************************************/


% Needed libraries
:- use_module(library(system)).
:- use_module(library(sort)).

false :-
  fail.

% Current opened streams
my_current_stream(St) :-
  current_stream(_,_,St).
  
% Executing operating system commands
my_shell(C,S) :-
  shell(C,S).

% Date and time
my_datetime((Y,M,D,H,Mi,S)) :-
  datime(datime(Y,M,D,H,Mi,S)).
  
% Sorting a list, removing duplicates
my_sort(List, Orderedlist) :-
  sort(List, Orderedlist).

% Changing the current directory
my_change_directory(Path) :-
  working_directory(_OldPath,Path).

% Testing whether exists the given directory
my_directory_exists(Path) :-
  file_exists(Path),
  file_property(Path,type(directory)).

% Testing whether exists the given file
my_file_exists(File) :-
  file_exists(File),
  file_property(File, type(regular)).

% Getting the current directory
my_working_directory(Path) :-
  working_directory(Path, Path).

% Getting the ordered list of files from the given path
my_directory_files(Path, List) :-
  directory_files(Path, UnorderedList),
  sort(UnorderedList, List).

% Getting the absolute filename for a file
my_absolute_filename(Path, AbsolutePath) :-
  absolute_file_name(Path, AbsolutePath).

% Testing whether the input is a file
my_is_file(File) :-
  file_property(File, type(regular)).

% Testing whether the input is a directory
my_is_directory(Path) :-
  file_property(Path, type(directory)).

% Giving an absolute file name
my_absolute_filename(F,AFN) :-
  my_working_directory(WD),
  (name(F,SF), [SC,Sl,BSl] = ":/\\", SF = [L,SC,X|_Xs], X \== Sl, X \== BSl -> % TODO
   nl, write('Cannot access '), write_log_string([L,SC]), write('.'), !, fail; true),
  my_dir_file(F,P,FN),
  (my_directory_exists(P) ->
    my_change_directory(P),
    my_working_directory(AP),
    atom_concat(AP,'/',ASP),  
    atom_concat(ASP,FN,AFN),
    my_change_directory(WD);
    F=AFN).

% Extracting the absolute path and file from an absolute file name
my_dir_file(AFN,AP,FN) :-
  name(AFN,SF),
  (([S]="/", reverse_find(S,SF,SP,SFN), name(AP,SP), name(FN,SFN), !); 
   ([S]="\\", reverse_find(S,SF,SP,SFN), name(AP,SP), name(FN,SFN), !); 
   (FN=AFN, AP='')).

reverse_find(X,S,P,F) :-
  reverse(S,RS),
  my_append(RF,[X|RP],RS), 
  reverse(RP,P),
  reverse(RF,F).

reverse(L,RL) :-
  reverse(L,[],RL).
reverse([],R,R).
reverse([A|As],Bs,R) :-
  reverse(As,[A|Bs],R).

% Gets a byte from the handle
my_get0(HIn,C) :- get_code(HIn,C).

% Gets a byte from the current handle
my_get0(C) :- get_code(C).

% Negation by failure
not(X) :-
  my_not(X).

% Reading terms along with variable names and its scope in line numbers
% TODO: Get line numbers
my_read(Term, VariableNames, (0,0)) :-
  read_term(Term, [variable_names(VariableNames)]).

% Timing: Resetting and displaying the elapsed time
reset_elapsedtime :-
  statistics(walltime,_).

display_elapsedtime :-
  timing(Switch),
  (Switch==on ->
   statistics(walltime,[_,Elapsed]),
   write_log_list(['Info: Elapsed time: ',Elapsed,' ms.',nl])
   ;
   true).
