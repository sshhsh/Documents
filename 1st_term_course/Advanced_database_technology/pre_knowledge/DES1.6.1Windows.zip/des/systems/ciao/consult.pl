:- use_module(library(compiler)).

consult(X) :- ensure_loaded(X).