/*********************************************************/
/*                                                       */
/* DATALOG Educational System v.1.6.0                    */
/*                                                       */
/*    SYSTEM DEPENDENT PREDICATES 2                      */
/*    Tested for GNU Prolog 1.3.0                        */
/*                                                       */
/*                                                       */
/*                                                       */
/*                          Fernando S�enz (c) 2004-2008 */
/*                                             DISIA UCM */
/*             Please send comments, questions, etc. to: */
/*                                     fernan@sip.ucm.es */
/*                                Visit the Web site at: */
/*                           http://des.sourceforge.net/ */
/*                                                       */
/*********************************************************/


% Current opened streams
my_current_stream(St) :-
  current_stream(St).
  
false :-
  fail.

% Executing operating system commands
my_shell(C,S) :-
  shell(C,S).

% Date and time
my_datetime((Y,M,D,H,Mi,S)) :-
  date_time(dt(Y,M,D,H,Mi,S)).
  
% Sorting a list, removing duplicates
my_sort(List, Orderedlist) :-
  sort0(List, Orderedlist).

% Changing the current directory
my_change_directory(Path) :-
  change_directory(Path).

% Testing whether exists the given directory
my_directory_exists(Path) :-
  file_exists(Path),
  file_property(Path, type(directory)).

% Testing whether exists the given file
my_file_exists(File) :-
  file_exists(File),
  file_property(File, type(regular)).

% Getting the current directory
my_working_directory(Path) :-
  working_directory(Path).

% Getting the ordered list of files from the given path
my_directory_files(Path, List) :-
  directory_files(Path, UnorderedList),
  sort0(UnorderedList, List).

% Testing whether the input is a file
my_is_file(File) :-
  file_property(File, type(regular)).

% Testing whether the input is a directory
my_is_directory(Path) :-
  file_property(Path, type(directory)).
  
% Getting the absolute filename for a file
my_absolute_filename(Path, AbsolutePath) :-
  absolute_file_name(Path, AbsolutePath).

% Extracting the absolute path and file from an absolute file name
my_dir_file(AFN,AP,FN) :-
%  decompose_file_name(AFN,AP,P,S), % TODO: This should work with a new GNU release
%  atom_concat(P,'.',PP),
%  atom_concat(PP,S,FN).
  name(AFN,SF),
  (([S]="/", reverse_find(S,SF,SP,SFN), name(AP,SP), name(FN,SFN), !); 
   ([S]="\\", reverse_find(S,SF,SP,SFN), name(AP,SP), name(FN,SFN), !); 
   (FN=AFN, AP='')).

reverse_find(X,S,P,F) :-
  my_reverse(S,RS),
  my_append(RF,[X|RP],RS), 
  my_reverse(RP,P),
  my_reverse(RF,F).

my_reverse(L,RL) :-
  my_reverse(L,[],RL).
my_reverse([],R,R).
my_reverse([A|As],Bs,R) :-
  my_reverse(As,[A|Bs],R).
  
% Gets a byte from the handle
my_get0(HIn,C) :- get_code(HIn,C).

% Gets a byte from the current handle
my_get0(C) :- get_code(C).

% Negation by failure
not(X) :-
  my_not(X).

% Reading terms along with variable names and its scope in line numbers
% TODO: Get line numbers
my_read(Term, VariableNames, (0,0)) :-
  read_term(Term, [variable_names(VariableNames)]).

% Timing: Resetting and displaying the elapsed time
reset_elapsedtime :-
  statistics(real_time,_).

display_elapsedtime :-
  timing(Switch),
  (Switch==on ->
   statistics(real_time,[_,Elapsed]),
   write_log_list(['Info: Elapsed time: ',Elapsed,' ms.',nl])
   ;
   true).
   