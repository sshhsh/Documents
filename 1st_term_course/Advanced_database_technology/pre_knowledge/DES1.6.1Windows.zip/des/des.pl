/*********************************************************/
/*                                                       */
/* DES: Datalog Educational System v.1.6.1               */
/*                                                       */
/*    MAIN PROGRAM                                       */
/*                                                       */
/*                                                       */
/*                                                       */
/*                          Fernando S�enz (c) 2004-2008 */
/*                                             DISIA UCM */
/*             Please send comments, questions, etc. to: */
/*                                     fernan@sip.ucm.es */
/*                                Visit the Web site at: */
/*                           http://des.sourceforge.net/ */
/*                                                       */
/*********************************************************/

% LOOK FOR WARNING

% TODO:
% - Display Prolog answers with the answer substitution
% - Multiline input

des_version('1.6.1').

/*********************************************************************/
/* Dynamic Predicates                                                */
/*********************************************************************/

:- dynamic(log/2).        % Log file information (filename and associated stream)
:- dynamic(verbose/1).    % Verbose mode flag 
:- dynamic(pretty_print/1). % Pretty print for listings (takes more lines to print)
:- dynamic(batch/3).      % Batch mode flag 
:- dynamic(consult/2).    % Consult mode flag 
:- dynamic(et/1).         % Extension Table 
:- dynamic(called/1).     % Call Patterns
:- dynamic(et_flag/1).    % Extension Table flag 
:- dynamic(datalog/4).    % Datalog Rules Database 
:- dynamic(strata/1).     % Result from a stratification
:- dynamic(pdg/1).        % Predicate Dependency Graph
:- dynamic(neg/1).        % Flag indicating the negation algorithm: et_not [SD91] or strata (optimized)
:- dynamic(timing/1).     % Flag indicating whether elapsed time should be displayed: yes or no
:- dynamic(def_preds/1).  % List of defined predicates in the current program
:- dynamic(error/0).      % Flag indicating whether there was an error
:- dynamic(safe/1).       % Flag indicating whether program transformation for safe objects is allowed
:- dynamic(language/1).   % Flag indicating the current default query language
:- dynamic(start_path/1). % Path on first initialization

/*********************************************************************/
/* Initial Status                                                    */
/*********************************************************************/

set_initial_status :-
  assertz(verbose(off)),      % Verbose output disabled
  assertz(pretty_print(on)),  % Pretty print activated
  assertz(neg(strata)),       % Default algorithm for solving negation
  assertz(timing(off)),       % Elapsed time display activated
  assertz(safe(off)),         % Program transformation disabled
  assertz(language(datalog)). % Default interpreter language (possible values are: datalog, prolog, sql)

/*********************************************************************/
/* Autorun Information (only for reference)                          */
/*********************************************************************/

%Autorun:
% Sicstus:
%  -l des.pl
% SWI Prolog:
%  -g "[des],start"
% GNU Prolog:
%  --entry-goal ['des.pl']
% CIAO Prolog:
%  -l ciaorc

/*********************************************************************/
/* System dependent predicates                                       */
/*********************************************************************/

:- initialization(consult('des1.pl')).
:- initialization(consult('desdebug.pl')).
:- initialization(consult('dessql.pl')).


/*********************************************************************/
/* Starting the System from scratch: start                           */
/*********************************************************************/

start :- 
  banner, 
  init_des, 
  display_status,
  exec_des.

% System initialization on start
init_des :- 
  (start_path(D) -> cd_path(D) ; my_working_directory(D), assertz(start_path(D))),
  retractall(log(_,_)),
  retractall(batch(_,_,_)),
  retractall(consult(_,_)),
  processC(abolish,[],_Vars),
  set_flag(et_flag,no),
  reset_id,
  set_initial_status,
  process_batch. %If des.ini exists, their entries are processed as command prompt inputs

% Entry execution point
exec_des :-
  !, 
  catch(des, M, message(M)), 
  (M == '$aborted' ->
     true
     ;
     complete_pending_tasks, 
     exec_des). % For SWI Prolog

% Completing pending tasks upon exceptions
%::WARNING: Other views/rules might be removed upon exceptions. Hint: use answer as a view and follow the dependencies
complete_pending_tasks :-
  abolishDL(answer),
  abolishET,
  compute_stratification.
  

% Exception handling
message(M) :- 
   (consult(_,CSt) ->    % Closes the program file currently loading, if any
    close(CSt),
    retractall(consult(_,_))
    ; 
    true), 
  (M = instantiation_error(_,_) ->
   true
  ;
   nl,
   my_print_message(error,M),
   nl
  ),
  (batch(_,_,_) -> 
   repoint_batch_file;
   true).

% Print exception messages
my_print_message(_,M) :-
  write_log_list([nl,'Exception: ',M,nl]).

% Relocating the pointer to the batch file
repoint_batch_file :- 
   batch(L,F,S),
  (my_current_stream(S) -> close(S);true),
  open(F,read,S1),
  set_input(S1),
  retractall(batch(_,_,_)),
  assertz(batch(L,F,S1)), 
  my_skip_line(L).       % Skip the offending line

my_skip_line(0) :- 
  !.
my_skip_line(N) :- 
  readln(_,_),
  N1 is N-1,
  my_skip_line(N1).
  
% Processing the batch file des.ini at the distribution directory
process_batch :-
  F = 'des.ini',
  my_file_exists(F),
  process_batch(F,'initialization batch').
process_batch.

process_batch(F) :-
  (my_file_exists(F) ->
   true
   ;
   write_log_list(['Error: File ''',F,''' not found.',nl]), fail),
  process_batch(F,'file'),
  !.
process_batch(F) :-
  write_log_list(['Error: When processing file ''',F,'''',nl]).

process_batch(F,M) :-
  my_absolute_filename(F,CFN),
  seeing(OldInput),   % Current input stream
  open(CFN,read,BSt), % Open initialization batch
  set_input(BSt),
  assertz(batch(0,CFN,BSt)),
  write_log_list([nl,'Info: Processing ',M,' ''',F,''' ...',nl,nl]), 
  process_batch_file_lines(OldInput).

process_batch_file_lines(OldInput) :-
  repeat,
    readln(S,E),          % Read a line
    (E == end_of_file ->
      true
     ;
      inc_line,
      write_prompt,
      write_log_string(S), 
      nl_log, 
      nl_log, 
      catch(process_input(S), M, message(M)), 
      nl_log, 
      fail),
  batch(_,_,BSt),
  close(BSt),             % Close the input batch file
  see(OldInput),          % Restore current input stream
  retractall(batch(_,_,_)),
  write('Info: Batch file processed.'), nl.
      
inc_line :-
  retract(batch(L,F,S)),
  L1 is L+1,
  assertz(batch(L1,F,S)).

/*********************************************************************/
/* Informative banner                                                */
/*********************************************************************/

banner :-
  write_log('*********************************************************'), nl_log,
  write_log('*                                                       *'), nl_log,
  write_log('*        DES: Datalog Educational System v.1.6.1        *'), nl_log,
  write_log('*                                                       *'), nl_log,
  write_log('*                                                       *'), nl_log,
  write_log('* Type "/help" for help about commands                  *'), nl_log,
  write_log('* Type "des." to continue if you get out of DES         *'), nl_log,
  write_log('*   from a Prolog interpreter                           *'), nl_log,
  write_log('*                                                       *'), nl_log,
  write_log('*                          Fernando S�enz (c) 2004-2008 *'), nl_log,
  write_log('*                                             DISIA UCM *'), nl_log,
  write_log('*             Please send comments, questions, etc. to: *'), nl_log,
  write_log('*                                     fernan@sip.ucm.es *'), nl_log,
  write_log('*                                Visit the Web site at: *'), nl_log,
  write_log('*                           http://des.sourceforge.net/ *'), nl_log,
  write_log('*********************************************************'), nl_log.


/*********************************************************************/
/* Datalog Prompt                                                    */
/*********************************************************************/

des :-
  nl_log, 
  write_prompt,
  flush_output, 
  readln(S,_E), 
  write_only_to_log(S), nl_only_to_log, nl_log, 
  process_input(S), 
  !, 
  des.
des :-
  write_log('Error: Input processing error.'), nl_log, 
  des.

write_prompt :- 
  language(L),
  (L==datalog -> write_log('DES-Datalog> ') ; true),
  (L==prolog  -> write_log('DES-Prolog> ')  ; true),
  (L==sql     -> write_log('DES-SQL> ')     ; true).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% readln(-String,-EOF). Read a line from the current input stream
% (console, by default). Informs whether the line ends with a
% 'end of file' or 'end of line' character.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

readln(S,E) :-
        current_input(HIn),
        readln(HIn,S,E).

readln(HIn,Cs,E) :-
        my_get0(HIn,C),
        read_chars(HIn,C,Cs,E).

read_chars(_HIn,C,[],end_of_line) :-
        end_of_line(C), !.
read_chars(_HIn,C,[],end_of_file) :-
        end_of_file(C), !.
read_chars(HIn,C,[C|Cs],E) :-
        readln(HIn,Cs,E).

end_of_line(C) :- (C = 13; C = 10).

end_of_file(C) :- (C = 26; C = -1).


/*********************************************************************/
/* Processing                                                        */
/*********************************************************************/

process_input(end_of_file) :- !.
process_input(Input) :-
  reset_elapsedtime,
  % cd and ls commands can end with a mandatory dot (e.g., "cd ." or "cd ..")
  (((Command=cd;Command=ls;Command=dir), 
    (parse_command(Command,[..],_VarsT,Input,[]); 
     parse_command(Command,[.],_VarsF,Input,[]))) -> 
   (Input=CInput, !);
   (my_append(CInput,".",Input), !; % Inputs are allowed to end with an optional dot
    CInput=Input)),
   (command(CInput) -> 
    process_command(CInput), !
    ; 
    (blank_input(CInput), !; 
     process_comment(CInput), !;
     language(datalog), process_datalog(CInput), !; 
     language(prolog),  process_prolog(CInput), !; 
     language(sql),     process_sql(CInput), !; 
     invalid_input)).


process_command(SCommand) :- 
  lang_interpreter_cmd(Language,SCommand,CInput),
  atom_concat('process_',Language,F),
  P=..[F,CInput],
  call(P),
  !.
process_command(SCommand) :- 
  (parse_command(Command,Arguments,Vars,SCommand,[]) -> 
    processC(Command,Arguments,Vars); 
    syntax_error('command and/or its argument. Type /help for help on commands')).

process_datalog(CInput) :-
  (process_datalog_query(CInput), !; 
   process_view(CInput), !; 
   process_autoview(CInput)).

process_prolog(CInput) :-
  parse_body(Goal,[],Vars,CInput,[]), 
  solve_prolog(Goal,Vars).

process_sql(CInput) :-
  write_verb_list(['Info: Parsing query...',nl]),
  parse_sql_query(Query,CInput,[]), 
  write_verb_list(['Info: Query successfully parsed.',nl]),
  !,
  reset_id,
  solve_sql_query(Query).

lang_interpreter_cmd(datalog) --> 
  command_begin,
  my_blanks_star,
  my_kw("DATALOG"),
  my_blanks_star.
lang_interpreter_cmd(prolog) --> 
  command_begin,
  my_blanks_star,
  my_kw("PROLOG"),
  my_blanks_star.
lang_interpreter_cmd(sql) --> 
  command_begin,
  my_blanks_star,
  my_kw("SQL"),
  my_blanks_star.

process_datalog_query(SQuery) :-
  parse_datalog_query(Query,NVs,SQuery,[]),
  make_safe(':-'(query,Query),NVs,exec,query,':-'(query,SafeQuery),Error),
  (Error==true ->
   true
   ;
   solve_datalog_query(SafeQuery,Undefined),
   display_solutions(SafeQuery,Undefined)).

process_view(SRule) :-
  name(':-',[S,D]),
  my_appendfind(SHead,[S,D|SBody],SRule), 
  (parse_head(Head,[],V,SHead,[]) -> true; syntax_error('rule head'), fail),
  (parse_body(Body,V,NVs,SBody,[]) -> true; syntax_error('rule body'), fail),
  make_safe(':-'(Head,Body),NVs,exec,view,':-'(Head,SafeBody),Error),
  (Error ->
   true
   ;
   process_rule(Head,SafeBody)).
  
process_autoview(SAutoview) :-
  parse_body(Body,[],NVs,SAutoview,[]), 
  build_head(autoview,NVs,Head),
  make_safe(':-'(autoview,Body),NVs,exec,'conjunctive query',':-'(autoview,SafeBody),Error),
  (Error ->
   true
   ;
   write_log_list(['Info: Processing:',nl,'  ']), 
   write_with_vars(Head,NVs), 
   write_log(' :- '), 
   write_with_vars(SafeBody,NVs), nl_log,
   process_rule(Head,SafeBody)).

process_rule(Head,Body) :-
  Rule =.. [':-',Head,Body],
  strata(CurrentStrata),
  pdg(CurrentPDG),
  assertz(datalog(Rule,[],[],_)),
  compute_stratification,
  solve_datalog_query(Head,Undefined),
  display_solutions(Head,Undefined),
  retract(datalog(Rule,[],[],_)),
  abolishET,	%TODO: Restore previous state
  load_stratification(CurrentStrata,CurrentPDG).

build_head(Functor,VarPairs,Head) :-
  get_variables(VarPairs,Vs),
  Head =.. [Functor|Vs].
  
get_variables([],[]).
get_variables([_N=V|Ps],IV) :-
  get_variables(Ps,Vs),
  my_append(Vs,[V],IV).

process_comment(SComment) :-
  parse_line_comment(SComment,_), !.

blank_input(SBlanks) :-
  my_blanks_star(SBlanks,[]).  

invalid_input :-
  language(datalog),
  !,
  write_log('Error: Input not recognized as a valid Datalog query, view, autoview or command.'), nl_log, 
  write_log('  Queries   : Atom      |'), nl_log, 
  write_log('              not(Atom) |'), nl_log, 
  write_log('              X Infix Y '), nl_log, 
  write_log('  Views     : Head :- Body'), nl_log, 
  write_log('  Autoviews : Body'), nl_log, 
  write_log('  Commands  : /Command Argument(s)'), nl_log, 
  write_log('Queries, views and commands can optionally end with a dot.'), nl_log.
invalid_input :-
  language(sql),
  !,
  write_log('Error: Input not recognized as a valid SQL statement or command.'), nl_log, 
  write_log('  Queries  : Consult the manual for syntax'), nl_log, 
  write_log('  Commands : /Command Argument(s)'), nl_log, 
  write_log('Queries and commands can optionally end with a semicolon or a dot, resp.'), nl_log.
invalid_input :-
  language(prolog),
  !,
  write_log('Error: Input not recognized as a valid Prolog goal or command.'), nl_log, 
  write_log('  Goals    : Atom      |'), nl_log, 
  write_log('             not(Atom) |'), nl_log, 
  write_log('             X Infix Y '), nl_log, 
  write_log('  Commands : /Command Argument(s)'), nl_log, 
  write_log('Queries and commands can optionally end with a dot or a semicolon.'), nl_log.

processC(SQuit,[],_Vars) :- 
  (SQuit=q; SQuit=quit; SQuit=e; SQuit=exit; SQuit=halt), !, halt.
processC(STerminate,[],_Vars) :- 
  STerminate=t, !, fail.
processC(SCommand,[C],_Vars) :- 
  (SCommand=shell; SCommand=s), !, my_shell(C,S),
  (S=0 -> 
    (nl_log, 
     write_verb(['Info: Operating system command executed.']))
   ;
    (write_log('Error: Operating system command failed.'), nl_log)).
processC(SHelp,[],_Vars) :- (SHelp=h; SHelp=help), !,
  write_log('Available Commands:'), nl_log,
  write_log(' * Rule Database Commands:'), nl_log,
  write_log('   - /consult Filename     Consults a Datalog file, abolishing previous rules'), nl_log,
  write_log('   - /c Filename           Shorthand for /consult Filename'), nl_log,
  write_log('   - /[Filenames]          Consults Datalog files, abolishing previous rules'), nl_log,
  write_log('   - /reconsult Filename   Consults a Datalog file, keeping previous rules'), nl_log,
  write_log('   - /r Filename           Shorthand for /reconsult Filename '), nl_log,
  write_log('   - /[+Filenames]         Consults Datalog files, keeping previous rules'), nl_log,
  write_log('   - /assert Head:-Body    Asserts a rule. :-Body is optional (for facts)'), nl_log,
  write_log('   - /retract Head:-Body   Retracts a rule. :-Body is optional (for facts)'), nl_log,
  write_log('   - /retractall Head      Retracts all rules matching the given head'), nl_log,
  write_log('   - /abolish              Abolishes all Datalog rules'), nl_log,
  write_log('   - /abolish Name         Abolishes all Datalog rules matching a predicate name'), nl_log,
  write_log('   - /abolish Name/Arity   Abolishes all Datalog rules matching the pattern'), nl_log,
  write_log('   - /listing              Lists Datalog rules'), nl_log,
  write_log('   - /listing Name         Lists Datalog rules matching a name'), nl_log,
  write_log('   - /listing Name/Arity   Lists Datalog rules matching the pattern'), nl_log,
  write_log(' * Debugging:'), nl_log,
  write_log('   - /debug Goal           Debugs a goal'), nl_log,
  write_log('   - /debug Goal Level     Debugs a goal at clause (c) or predicate (p) level'), nl_log,
  write_log(' * Extension Table Commands:'), nl_log,
  write_log('   - /list_et              Lists contents of the extension table'), nl_log,
  write_log('   - /list_et Name         Lists contents of the extension table matching a name'), nl_log,
  write_log('   - /list_et Name/Arity   Lists contents of the extension table matching the pattern'), nl_log,
  write_log('   - /clear_et             Clears the extension table'), nl_log,
  write_log(' * Operating System Commands:'), nl_log,
  write_log('   - /cd Path              Sets the current directory to path'), nl_log,
  write_log('   - /cd                   Sets the current directory to the one DES was started from'), nl_log,
  write_log('   - /pwd                  Displays the current directory'), nl_log,
  write_log('   - /ls                   Displays the contents of the current directory'), nl_log,
  write_log('   - /dir                  Synonym for /ls'), nl_log,
  write_log('   - /ls Path              Displays the contents of the given directory'), nl_log,
  write_log('   - /dir Path             Synonym for /ls path'), nl_log,
  write_log('   - /shell Command        Submits command to the OS shell'), nl_log,
  write_log('   - /s Command            Shorthand for /shell'), nl_log,
  write_log(' * Log Commands:'), nl_log,
  write_log('   - /log                  Displays the current log file, if any'), nl_log,
  write_log('   - /log Filename         Sets the current log to the given filename'), nl_log,
  write_log('   - /nolog                Disables logging'), nl_log,
  write_log(' * Informative Commands:'), nl_log,
  write_log('   - /help                 Displays this help'), nl_log,
  write_log('   - /h                    Shorthand for /help'), nl_log,
  write_log('   - /builtins             Lists builtin operators'), nl_log,
  write_log('   - /operators            Lists the available arithmetic operators'), nl_log,
  write_log('   - /dbschema             Displays the database schema'), nl_log,
  write_log('   - /dbschema Object      Displays the database schema for the given view or table name'), nl_log,
  write_log('   - /negation             Displays the selected algorithm for solving negation'), nl_log,
  write_log('   - /safe                 Displays whether program transformation is enabled'), nl_log,
  write_log('   - /timing               Displays whether elapsed time display is enabled'), nl_log,
  write_log('   - /timing Switch        Enables or disables elapsed time display (on or off, resp.)'), nl_log,
  write_log('   - /verbose              Displays whether verbose output is enabled'), nl_log,
  write_log('   - /verbose Switch       Enables or disables verbose output messages (on or off, resp.)'), nl_log,
  write_log('   - /pretty_print         Displays whether pretty print listings is enabled'), nl_log,
  write_log('   - /pretty_print Switch  Enables or disables pretty print for listings (on or off, resp.)'), nl_log,
  write_log('   - /strata               Displays the stratification for the loaded program'), nl_log,
  write_log('   - /pdg                  Displays the predicate dependency graph for the loaded program'), nl_log,
  write_log('   - /version              Displays the current system version'), nl_log,
  write_log('   - /status               Displays the current status of the system'), nl_log,
  write_log(' * Languages:'), nl_log,
  write_log('   - /datalog              Switches to Datalog interpreter'), nl_log,
  write_log('   - /datalog Query        Triggers Datalog evaluation for query'), nl_log,
  write_log('   - /prolog               Switches to Prolog interpreter'), nl_log,
  write_log('   - /prolog Goal          Triggers Prolog evaluation for goal'), nl_log,
  write_log('   - /sql                  Switches to SQL interpreter'), nl_log,
  write_log('   - /sql Query            Triggers SQL evaluation for query'), nl_log,
  write_log(' * Miscellanea:'), nl_log,
  write_log('   - /process Filename     Processes the contents of Filename as if they were typed at the system prompt'), nl_log,
  write_log('   - /safe Switch          Enables or disables program transformation (on or off, resp.)'), nl_log,
  write_log('   - /negation Algorithm   Sets the required Algorithm for solving negation (strata or et_not)'), nl_log,
  write_log('   - /halt                 Quits DES'), nl_log,
  write_log('   - /quit,/q,/exit,/e     Synonyms/Shorthands for /halt'), nl_log,
  write_log('Any other input is evaluated as a Prolog goal, SQL or Datalog query,'), nl_log,
  write_log('view or autoview, depending on the prompt.'), nl_log,
  write_log('Type des. if you get out of DES from a Prolog interpreter.'), nl_log.
processC(SConsult,Files,_Vars) :-
  (SConsult=consult; SConsult=c), !, 
  (Files=[] ->
    write_log('Warning: Nothing consulted.'), nl_log;
    abolishFT,
    abolishDL, 
    abolishET, 
    remove_duplicates(Files,UFiles),
    consultDLlist(UFiles,false,Success),
    (Success -> compute_stratification; true)).
processC(SReconsult,Files,_Vars) :-
  (SReconsult=reconsult; SReconsult=r), !, 
  (Files=[] ->
    write_log('Warning: Nothing reconsulted.'), nl_log;
    abolishET, 
    remove_duplicates(Files,UFiles),
    consultDLlist(UFiles,false,Success),
    (Success -> compute_stratification; true)).
processC(assert,[R],Vars) :-
  !, 
  assert_rules([(R,Vars)],Error),
  (var(Error) -> 
    abolishET, 
    drilldown_stratification([R])
   ;
   true).
processC(retract,[R],_Vars) :-
  !, 
  (R=(H:-true) -> DR=H; DR=R),
  retract_rule(DR,Error),
  (var(Error) ->
    abolishET, 
    rollup_stratification([DR])
    ;
    true).
processC(retractall,[H],_Vars) :-
  !, 
  dlrules(head,H,RV),
  (RV=[] ->
    write_log('Warning: Nothing retracted.'), nl_log
    ;
    getFileIdsHead(H,Fids),
    retractallDL(H),
    retract_fileids(Fids),
    write_verb(['Info: Rule(s) retracted:',nl]),
    (verbose(on) -> write_log('      '), write_list_with_vars(RV), nl_log; true),
    abolishET, 
    rollup_stratification(_Rs)).
processC(abolish,[],_Vars) :-
  !, 
  abolishFT,
  abolishDL, 
  write_verb(['Info: Program abolished.',nl]), 
  abolishET, 
  reset_stratification.
processC(abolish,[N/A],_Vars) :-
  !,
  dlrules(namearity,N/A,RV), 
  (RV=[] -> 
    write_log('Warning: Nothing abolished.'), nl_log
    ;
    retract_DL_rules_pattern(N/A,RV),
    abolishET, 
    rollup_stratification(_Rs)).
processC(abolish,[N],_Vars) :-
  !,
  dlrules(predname,N,RV), 
  (RV=[] -> 
    write_log('Warning: Nothing abolished.'), nl_log
    ;
    retract_DL_rules_pattern(N,RV),
    abolishET, 
    rollup_stratification(_Rs)).
processC(l,[],_Vars) :-
  !,
  listing(filet).
processC(listing,[],_Vars) :-
  !,
  list_rules(0).
processC(listing,[N/A],_Vars) :-
  !,
  list_rules(N,A,0).
processC(listing,[N],_Vars) :-
  !,
  list_rules(N,0).
processC(dbschema,[],_Vars) :-
  !,
  list_schema.
processC(dbschema,[N],_Vars) :-
  !,
  list_schema(N).
processC(list_et,[],_Vars) :-
  !,
  list_et.
processC(list_et,[N/A],_Vars) :-
  !,
  list_et(N/A).
processC(list_et,[N],_Vars) :-
  !,
  list_et(N).
processC(clear_et,[],_Vars) :- 
  !,
  retractall(et(_E)),
  retractall(called(_C)), 
  write_verb(['Info: Extension table cleared.', nl]).
processC(builtins,[],_Vars) :-
  !,
  list_builtins.
processC(operators,[],_Vars) :-
  !,
  list_operators.
processC(datalog,[],_Vars) :-
  !,
  retractall(language(_L)),
  assertz(language(datalog)),
  write_verb(['Info: Switched to Datalog interpreter.', nl]).
processC(prolog,[],_Vars) :-
  !,
  retractall(language(_L)),
  assertz(language(prolog)),
  write_verb(['Info: Switched to Prolog interpreter.', nl]).
processC(sql,[],_Vars) :-
  !,
  retractall(language(_L)),
  assertz(language(sql)),
  write_verb(['Info: Switched to SQL interpreter.', nl]).
processC(sql,[Query],_Vars) :-
  !,
  reset_id,
  solve_sql_query(Query).
processC(cd,[],_Vars) :-
  !,
  start_path(Path),
  cd_path(Path).
processC(cd,[Path],_Vars) :-
  !,
  cd_path(Path).
processC(pwd,[],_Vars) :-
  !,
  pwd_path.
processC(LS,[],_Vars) :-
  (LS=ls; LS=dir),
  !,
  ls.
processC(LS,[P],_Vars) :-
  (LS=ls; LS=dir),
  !,
  ls(P).
processC(verbose,[],_Vars) :-
  !, 
  verbose(Switch),
  write_log_list(['Info: Verbose output is ', Switch, '.', nl]).
processC(verbose,[Switch],_Vars) :-
  !, 
  ((Switch == on; Switch == off) ->
    retractall(verbose(_)), 
    assertz(verbose(Switch)),
    write_log_list(['Info: Verbose output is ', Switch, '.', nl])
    ;
    write_log_list(['Error: Incorrect switch. Use ''on'' or ''off''', nl])
    ).
processC(negation,[],_Vars) :-
  !, 
  neg(Algorithm),
  write_log_list(['Info: Algorithm ''', Algorithm, ''' selected for solving negation.', nl]).
processC(negation,[Algorithm],_Vars) :-
  !, 
  ((Algorithm == strata; Algorithm == et_not) ->
    retractall(neg(_)), 
    assertz(neg(Algorithm)),
    write_verb(['Info: Algorithm ''', Algorithm, ''' selected for solving negation.',nl])
    ;
    write_log_list(['Error: Algorithm ''', Algorithm, ''' is not supported. Use ''strata'' or ''et_not''.', nl])
    ).
processC(timing,[],_Vars) :-
  !, 
  timing(Switch),
  write_log_list(['Info: Elapsed time display is ', Switch, '.', nl]).
processC(timing,[Switch],_Vars) :-
  !, 
  ((Switch == on; Switch == off) ->
    retractall(timing(_)), 
    assertz(timing(Switch)),
    processC(timing,[],_)
    ;
    write_log_list(['Error: Incorrect switch. Use ''on'' or ''off''', nl])
    ).
processC(pretty_print,[],_Vars) :-
  !, 
  pretty_print(Switch),
  write_log_list(['Info: Pretty print is ', Switch, '.', nl]).
processC(pretty_print,[Switch],_Vars) :-
  !, 
  ((Switch == on; Switch == off) ->
    retractall(pretty_print(_)), 
    assertz(pretty_print(Switch)),
    processC(pretty_print,[],_)
    ;
    write_log_list(['Error: Incorrect switch. Use ''on'' or ''off''', nl])
    ).
processC(safe,[],_Vars) :-
  !, 
  safe(Switch),
  write_log_list(['Info: Program transformation is ', Switch, '.', nl]).
processC(safe,[Switch],_Vars) :-
  !, 
  ((Switch == on; Switch == off) ->
    retractall(safe(_)), 
    assertz(safe(Switch)),
    processC(safe,[],_)
    ;
    write_log_list(['Error: Incorrect switch. Use ''on'' or ''off''', nl])
    ).
processC(strata,[],_Vars) :-
  !, 
  (strata(S) -> 
   (write_log(S), nl_log); 
   (write_log('Warning: Strata not yet computed.'), nl_log)).
processC(pdg,[],_Vars) :-
  !, 
  (pdg((N,A)) -> 
   (write_log('Nodes: '), write_log(N), nl_log, write_log('Arcs : '), write_log(A), nl_log)
   ; 
   (write_log('Info: Predicate dependency graph not yet computed.'), nl_log)).
processC(log,[],_Vars) :-
  !, 
  (log(F,_S) -> 
   (write_log('Info: Currently logging to '), write_log(F), write_log('.'), nl_log)
   ;
   (write_log('Info: Logging currently disabled.'), nl_log)).
processC(nolog,[],_Vars) :-
  !, 
  (log(F,S) -> 
   (close(S), retract(log(F,S)), write_verb(['Info: Logging to ', F, ' disabled.', nl]))
   ;
   (write_log('Warning: Logging already disabled.'), nl_log)).
processC(log,[F],_Vars) :-
  !, 
  (log(CF,_S) -> 
   (write_log('Warning: Currently logging to '), write_log(CF), 
    write_log('. First, use /nolog for disabling the current log.'), nl_log)
   ;
   (my_absolute_filename(F,AFN),
    my_dir_file(AFN,AP,_FN),
    (my_directory_exists(AP) ->
     (open(AFN,write,S),
      assertz(log(AFN,S)), 
      write_verb(['Info: Logging enabled to ',AFN,'.',nl]))
     ;
     (write_log('Warning: Directory '), write_log(AP), write_log(' does not exist.'), nl_log)
     )
    )
   ). 
processC(process,[F],_Vars) :-
  !,
  process_batch(F).
processC(version,[],_Vars) :-
  !, 
  des_version(V), 
  write_log_list(['Info: DES version ',V,'.',nl]).
processC(status,[],_Vars) :-
  !, 
  display_status.
processC(debug,[Goal],Vars) :-
  !, 
  debugGoalLevel(Goal,'p',Vars).
processC(debug,[Goal,Level],Vars) :-
  !, 
  debugGoalLevel(Goal,Level,Vars).
processC(_Error,_L,_Vars) :-
  !, 
  write_log('Error: Unknown command or incorrect number of arguments. Use /help for help.'), nl_log.

debugGoalLevel(Goal,Level,Vars) :-
  (filet(_F,_Fid) -> 
   ((Level == c ; Level == p) ->
     solve_datalog_query(Goal,_Undefined),
    !, 
    nl_log, write_verb(['Info: Starting debugger...']), 
    initDebug(Goal, Level, Vars)
   ;
   write_log_list(['Warning: Unsupported option ''',Level,'''.',nl]))
  ; 
  write_log('Error: Program not yet loaded.'), nl_log).


/*********************************************************************/
/* Parsing                                                           */
/*********************************************************************/

%
% Parsing commands
%

command(CInput) :-
  command_begin(CInput,_).

command_begin -->
  my_blanks_star,
  "/".
  
parse_command(reconsult,Files,[]) -->
  command_begin,
  my_blanks_star, 
  "[+",
  my_blanks_star,
  my_arguments(Files),
  my_blanks_star,
  "]",
  my_blanks_star,
  !.
parse_command(consult,Files,[]) -->
  command_begin,
  my_blanks_star,
  "[",
  my_blanks_star,
  my_arguments(Files),
  my_blanks_star,
  "]",
  my_blanks_star,
  !.
parse_command(Command,[],[]) -->
  command_begin,
  my_blanks_star,
  my_command(Command),
  my_blanks_star,
  !.
parse_command(datalog,[Goal],Vars) -->
  command_begin,
  my_blanks_star,
  my_command(datalog),
  " ",
  !,
  my_blanks_star,
  my_body(Goal,[],Vars),
  my_blanks_star. 
parse_command(prolog,[Goal],Vars) -->
  command_begin,
  my_blanks_star,
  my_command(prolog),
  " ",
  !,
  my_blanks_star,
  my_body(Goal,[],Vars),
  my_blanks_star. 
parse_command(abolish,[N/A],[]) -->
  command_begin,
  my_blanks_star,
  my_command(abolish),
  my_blanks,
  my_pattern(N/A),
  my_blanks_star,
  !.
parse_command(list_schema,[N],[]) -->
  command_begin,
  my_blanks_star,
  my_command(list_schema),
  my_blanks,
  my_user_identifier(N),
  my_blanks_star,
  !.
parse_command(list_et,[N/A],[]) -->
  command_begin,
  my_blanks_star,
  my_command(list_et),
  my_blanks,
  my_pattern(N/A),
  my_blanks_star,
  !.
parse_command(listing,[N/A],[]) -->
  command_begin,
  my_blanks_star,
  my_command(listing),
  my_blanks,
  my_pattern(N/A),
  my_blanks_star,
  !.
parse_command(retract,[Rule],[]) -->
  command_begin,
  my_blanks_star,
  my_command(retract),
  " ",
  !,
  my_blanks_star,
  my_rule(Rule,[],_Vars),
  my_blanks_star.
parse_command(retractall,[Head],[]) -->
  command_begin,
  my_blanks_star,
  my_command(retractall),
  " ",
  !,
  my_blanks_star,
  my_head(Head,[],_Vars),
  my_blanks_star.
parse_command(assert,[Rule],Vars) -->
  command_begin,
  my_blanks_star,
  my_command(assert),
  " ",
  !,
  my_blanks_star,
  my_rule(Rule,[],Vars),
  my_blanks_star.
parse_command(debug,[Goal],Vars) -->
  command_begin,
  my_blanks_star,
  my_command(debug),
  my_blanks,
  my_literal(Goal,[],Vars),
  my_blanks_star,
  !.
parse_command(debug,[Goal,Level],Vars) -->
  command_begin,
  my_blanks_star,
  my_command(debug),
  " ",
  !,
  my_blanks_star,
  my_literal(Goal,[],Vars),
  my_blanks_star,
  my_symbol(Level),
  my_blanks_star.
parse_command(Command,Arguments,[]) -->
  command_begin,
  my_blanks_star,
  my_command(Command),
  my_blanks,
  my_arguments(Arguments),
  my_blanks_star.

my_command(Command) -->
  my_identifier_chars(Cs),
  {to_lowercase_list(Cs,LCs),
   name(Command,LCs)}.

my_arguments([]) -->
  [].
my_arguments([A|As]) -->
  my_charsbutcomma(Cs),
  my_blanks_star,
  ",",
  my_blanks_star,
  {name(A,Cs)},
  my_arguments(As).
my_arguments([A]) -->
  my_charsbutcomma(Cs),
  {name(A,Cs)}.

my_charsbutcomma([C]) -->
  my_charbutcomma(C).
my_charsbutcomma([C|Cs]) -->
  my_charbutcomma(C),
  my_charsbutcomma(Cs).

my_charbutcomma(C) -->
  [C],
  {C\=","}.

my_pattern(N/A) -->
  my_blanks_star,
  my_symbol(N),
  my_blanks_star,
  "/",
  my_blanks_star,
  my_positive_integer(A),
  my_blanks_star.


%
% Parsing queries
%

parse_datalog_query(Term,Vo) -->
  my_blanks_star,
  my_literal(Term,[],Vo),
  my_blanks_star.

%
% Parsing rule heads
%

parse_head(Term,Vi,Vo) -->
  my_blanks_star,
  my_atom(Term,Vi,Vo),
  my_blanks_star,
  {redef_error(Term)}, !.
  
redef_error(Term) :-
   Term =.. [F|As],
   length(As,A),
   (my_infix_relation(F,_), A=2       -> redefinition_error(F,A); true),
%  (my_infix_comparison(F,_), A=2     -> redefinition_error(F,A); true), % Infix comparison operators are rejected when parsing
%  (my_infix_arithmetic(F,_), A=2     -> redefinition_error(F,A); true), % Names of arithmetic Built-ins can be reused because of their scope
   (F = (','), A=2                    -> redefinition_error(F,A); true),
   (F = 'not', A=1                    -> redefinition_error(F,A); true),
   (F = 'autoview'                    -> redefinition_error(F,A); true).
  
%
% Parsing rule bodies
%

parse_body(Terms,Vi,Vo) -->
  my_blanks_star,
  my_body(Terms,Vi,Vo),
  my_blanks_star.


%
% Parsing line comments
%

parse_line_comment -->
  my_blanks_star,
  "%".


%
% Rules, heads, bodies and queries
%

my_rule(':-'(H,B),Vi,Vo) -->
  my_blanks_star,
  my_head(H,Vi,Vo1),
  my_blanks_star,
  ":-",
  my_blanks_star,
  my_body(B,Vo1,Vo),
  my_blanks_star.
my_rule(H,Vi,Vo) -->
  my_blanks_star,
  my_head(H,Vi,Vo),
  my_blanks_star.

my_head(H,Vi,Vo) -->
  my_atom(H,Vi,Vo).

my_body(B,Vi,Vo) -->
  my_literals(B,Vi,Vo).

my_query(Q,Vi,Vo) -->
  my_literal(Q,Vi,Vo).


%
% Constants, Variables, Terms, Atoms, Literals
%

my_constant(A) -->
  my_number(A).
my_constant(A) -->
  my_symbol(A).

my_variable(V,Vi,Vo) -->
  my_uppercase(C),
  {name(N,[C]),
  append_var(N,V,Vi,Vo)}.
my_variable(V,Vi,Vo) -->
  my_uppercase(C),
  my_identifier_chars(Cs),
  {name(N,[C|Cs]),
   append_var(N,V,Vi,Vo)}.
my_variable(V,Vi,Vo) -->
  "_",
  my_identifier_chars(Cs),
  {[US]="_",
   name(N,[US|Cs]),
   append_var(N,V,Vi,Vo)}.
my_variable(_,Vi,Vi) -->
  "_".

my_noncompoundterms([T|Ts],Vi,Vo) -->
  my_noncompoundterm(T,Vi,Vo1),
  my_blanks_star,
  ",",
  my_blanks_star,
  my_noncompoundterms(Ts,Vo1,Vo).
my_noncompoundterms([T],Vi,Vo) -->
  my_noncompoundterm(T,Vi,Vo).

my_noncompoundterm(A,V,V) -->
  my_constant(A).
my_noncompoundterm(A,Vi,Vo) -->
  my_variable(A,Vi,Vo).

my_atom(A,Vi,Vo) -->
  my_symbol(F),
  my_blanks_star,
  "(",
  {F\==not},
  my_blanks_star,
  my_noncompoundterms(LT,Vi,Vo),
  my_blanks_star,
  ")",
  {A =.. [F|LT]}.
my_atom(A,V,V) -->
  my_symbol(A).
my_atom(A,Vi,Vo) -->
  my_noncompoundterm(L,Vi,Vo1),
  my_blanks_star,
  my_infix_comparison(P),
  my_blanks_star,
  my_noncompoundterm(R,Vo1,Vo), 
  my_blanks_star,
  {A =.. [P,L,R]}.
my_atom(A,Vi,Vo) -->
  my_noncompoundterm(L,Vi,Vo1),
  my_blanks_star,
  "is",
  my_blanks_star,
  my_arithmeticexp(R,Vo1,Vo),
  my_blanks_star,
  {A =.. [is,L,R]}.

my_literals((T,Ts),Vi,Vo) -->
  my_literal(T,Vi,Vo1),
  my_blanks_star,
  ",",
  my_blanks_star,
  my_literals(Ts,Vo1,Vo).
my_literals(T,Vi,Vo) -->
  my_literal(T,Vi,Vo).

my_literal(L,Vi,Vo) -->
  my_atom(L,Vi,Vo).
my_literal(L,Vi,Vo) -->
  "not",
  my_blanks_star,
  "(",
  my_atom(A,Vi,Vo),
  my_blanks_star,
  ")",
  {L = not(A)}.


%
% Ancillary Stuff
%
    
my_blank -->         % One blank
  " ".
  
my_blanks_star -->   % Zero or more blanks. Eagerly consumes blanks
  my_blanks.
my_blanks_star -->
  [].

my_blanks -->        % One or more blanks
  my_blank,
  my_blanks_star.

my_lowercase(C) --> 
  [C],
  {my_lowercase(C)}.
my_uppercase(C) -->
  [C],
  {C>="A",
   C=<"Z"}.
my_digit(C) -->
  [C],
  {C>="0",
   C=<"9"}.

my_lowercase(C) :-
  C>="a",
  C=<"z".

my_uppercase(C) :-
  C>="A",
  C=<"Z".

% my_identifier_chars: 
% one or more digits, letters, underscores or dollars
my_identifier_chars([C]) -->
  my_identifier_char(C).
my_identifier_chars([C|Cs]) -->
  my_identifier_char(C),
  my_identifier_chars(Cs).

% my_identifier_chars_star:
% zero or more digits, letters, underscores or dollars
my_identifier_chars_star([]) -->
  [].
my_identifier_chars_star(Cs) -->
  my_identifier_chars(Cs).

my_identifier_char(C) --> 
  my_lowercase(C).
my_identifier_char(C) -->
  my_uppercase(C).
my_identifier_char(C) -->
  my_digit(C).
my_identifier_char(C) -->
  "_",
  {[C]="_"}.
my_identifier_char(C) -->
  "$",
  {[C]="$"}.

% my_chars: one or more characters
my_chars([C]) -->
  my_char(C).
my_chars([C|Cs]) -->
  my_char(C),
  my_chars(Cs).

my_char(C) -->
  [C].

% my_symbol is intended to parse constants, function (functor), and relation (predicate) symbols
my_symbol(A) -->
  my_lowercase(C),
  my_identifier_chars_star(Cs),
 {name(A,[C|Cs])}.
% my_symbol(A) -->
%   my_lowercase(C),
%   {name(A,[C])}.
my_symbol(A) -->
  "'",
  my_identifier_chars(Cs),
  "'",
  {name(A,Cs)}.
  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parsing of arithmetic expressions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

my_arithmeticexp(E,Vi,Vo) --> 
  my_aterm(T,Vi,Vo1),
  my_blanks_star, 
  my_arithmeticexp_r(T,E,Vo1,Vo).
my_arithmeticexp_r(E0,E,Vi,Vo) --> 
  {my_priority_operator(low,SOP,OP)}, 
  my_string(SOP),
  my_blanks_star, 
  my_aterm(T,Vi,Vo1),
  my_blanks_star, 
  {TOP =.. [OP,E0,T]},
  my_arithmeticexp_r(TOP,E,Vo1,Vo).
my_arithmeticexp_r(E,E,V,V) -->
  [].

my_aterm(T,Vi,Vo) --> 
  my_power(P,Vi,Vo1),
  my_blanks_star, 
  my_aterm_r(P,T,Vo1,Vo).
my_aterm_r(T0,T,Vi,Vo) --> 
  {my_priority_operator(medium,SOP,OP)}, 
  my_string(SOP),
  my_blanks_star, 
  my_power(P,Vi,Vo1),
  my_blanks_star, 
  {TOP =.. [OP,T0,P]},
  my_aterm_r(TOP,T,Vo1,Vo).
my_aterm_r(T,T,V,V)    --> [].

my_power(P,Vi,Vo) --> 
  my_factor(F,Vi,Vo1),
  my_blanks_star, 
  my_power_r(F,P,Vo1,Vo).
my_power_r(P0,TOP,Vi,Vo) --> 
  {my_priority_operator(high,SOP,OP)}, 
%  SOP,  % Unsupported in GNU Prolog
  my_string(SOP), 
  my_blanks_star, 
  my_factor(P1,Vi,Vo1),
  my_blanks_star,
  {TOP =.. [OP,P0,P]},
  my_power_r(P1,P,Vo1,Vo).
my_power_r(P,P,V,V) -->
  [].

my_factor(N,Vi,Vi) -->
  my_number(N).
my_factor(V,Vi,Vo) -->
  my_variable(V,Vi,Vo).
my_factor(C,Vi,Vi) -->
  my_arithmetic_constant(C).
my_factor(T,Vi,Vo) --> 
  {my_arithmetic_function(SF,F,A)},
  my_string(SF), 
  my_blanks_star,
  "(",
  my_blanks_star,
  my_function_arguments(A,As,Vi,Vo),
  my_blanks_star,
  ")",
  {T=..[F|As]}.
my_factor(E,Vi,Vo) -->
  "(",
  my_blanks_star,
  my_arithmeticexp(E,Vi,Vo),
  my_blanks_star,
  ")".
my_factor(T,Vi,Vo) --> 
  {my_unary_operator(SOP,OP)},
  my_string(SOP),
  my_blanks_star, 
  my_arithmeticexp(E,Vi,Vo),
  {T=..[OP,E]}.

%my_priority_operator(Priority, StringOperator, Operator)
my_priority_operator(P,SOP,POP) :-
  my_infix_arithmetic(OP,POP,_,P),
  name(OP,SOP).

my_function_arguments(1,[E],Vi,Vo) -->
  !,
  my_arithmeticexp(E,Vi,Vo).
my_function_arguments(A,[E|Es],Vi,Vo) -->
  {A>1},
  my_arithmeticexp(E,Vi,Vo1),
  my_blanks_star,
  ",",
  my_blanks_star,
  {A1 is A-1},
  my_function_arguments(A1,Es,Vo1,Vo).

  
%
% Numbers
%

my_number(N) -->
  my_negative_number(N).
my_number(N) -->
  my_positive_number(N).

my_negative_number(N) -->
  "-",
  my_positive_number(P),
  {N is -P}.

my_positive_number(N) -->
  my_fractional_positive_number(M),
  "E+",
  my_integer(E),
  {N is M*(10**E)}.
my_positive_number(N) -->
  my_fractional_positive_number(M),
  "E",
  my_integer(E),
  {N is M*(10**E)}.
my_positive_number(N) -->
  my_fractional_positive_number(N).
my_positive_number(N) -->
  my_positive_integer(N).

my_fractional_positive_number(N) -->
  my_digits(Is),
  ".",
  my_digits(Ds),
  {concatLsts([Is,".",Ds],Ns),
   name(N,Ns)}.

my_integer(N) -->
  my_negative_integer(N).
my_integer(N) -->
  my_positive_integer(N).

my_negative_integer(N) -->
  "-",
  my_positive_integer(P),
  {N is -P}.

my_positive_integer(N) -->
  my_digits(Ds),
  {name(N,Ds)}.

my_digits([D]) -->
  my_digit(D).
my_digits([D|Ds]) -->
  my_digit(D),
 my_digits(Ds).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Built-ins
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Built-in Arithmetic Constants

my_arithmetic_constant(Value) --> 
  {arithmetic_constant(Value,Constant,_), 
   name(Constant, SConstant)}, 
  my_string(SConstant).

arithmetic_constant(4*atan(1),'pi','Archimedes'' constant').
arithmetic_constant(exp(1),'e','Euler''s number').

% Built-in Arithmetic Functions

my_arithmetic_function(SF,PF,A) :- 
  arithmetic_function(F,PF,_,A),
  name(F,SF).

% arithmetic_function(Name, PrologPredefined, Description, Arity)
arithmetic_function('sqrt','sqrt','Square root',1).
arithmetic_function('ln','log','Neperian logarithm',1).
arithmetic_function('log','log','Neperian logarithm',1).
arithmetic_function('log','log','Logarithm of the second argument in the base of the first one',2).
arithmetic_function('sin','sin','Sine',1).
arithmetic_function('cos','cos','Cosine',1).
arithmetic_function('tan','tan','Tangent',1).
arithmetic_function('cot','cot','Cotangent',1).
arithmetic_function('asin','asin','Arc sine',1).
arithmetic_function('acos','acos','Arc cosine',1).
arithmetic_function('atan','atan','Arc tangent',1).
arithmetic_function('acot','acot','Arc cotangent',1).
arithmetic_function('abs','abs','Absolute value',1).
arithmetic_function('float','float','Float value of its argument',1).
arithmetic_function('integer','integer','Closest integer between 0 and its argument',1).
arithmetic_function('sign','sign','Returns -1 if its argument is negative, 0 otherwise',1).
arithmetic_function('gcd','gcd','Greatest common divisor',2).
arithmetic_function('min','min','Least of two numbers',2).
arithmetic_function('max','max','Greatest of two numbers',2).
arithmetic_function('truncate','truncate','Closest integer between 0 and its argument',1).
arithmetic_function('float_integer_part','float_integer_part','Integer part as a float',1).
arithmetic_function('float_fractional_part','float_fractional_part','Fractional part as a float',1).
arithmetic_function('round','round','Closest integer',1).
arithmetic_function('floor','floor','Greatest integer less or equal to its argument',1).
arithmetic_function('ceiling','ceiling','Least integer greater or equal to its argument',1).

% Built-in Predicates

my_builtin_pred(X) :- 
  my_infix_relation(X,_);
  my_infix_comparison(X,_).

% Built-in Operators

my_infix(X) :- 
  X==(':-'); 
  my_infix_relation(X,_); 
  my_infix_comparison(X,_); 
  my_infix_arithmetic(X,_,_,_).

% Built-in Unary Operators
my_unary_operator(SOP,POP) :-
  unary_operator(OP,POP,_),
  name(OP,SOP).
  
unary_operator('\\','\\','Bitwise negation').
unary_operator('-','-','Negative value of its single argument').

% Built-in Binary Operators

% Built-in arithmetic expression evaluation operator
my_infix_relation('is','Evaluation of arithmetic expressions').

% Built-in Binary Comparison Operators
% my_infix_comparison(Name, Description)
my_infix_comparison('=','Syntactic equality').
my_infix_comparison('\\=','Syntactic disequality').
my_infix_comparison('>','Greater than').
my_infix_comparison('>=','Greater or equal than').
my_infix_comparison('<','Less than').
my_infix_comparison('=<','Less or equal than').

my_infix_comparison(Op) --> {my_infix_comparison(Op,_), name(Op,SOp)}, my_string(SOp).


% Built-in Binary Arithmetic Operators
% my_infix_arithmetic(Name, PrologBuiltin, Description, PriorityGroup)
% The priority of an operator in each priority group follows textual order of clauses (the first one has the higher priority, the last one has the lower priority)
my_infix_arithmetic('^','**','Power',high).
my_infix_arithmetic('**','**','Power',high).
my_infix_arithmetic('*','*','Multiplication',medium).
my_infix_arithmetic('/','/','Real division',medium).
my_infix_arithmetic('//','//','Integer quotient',medium).
my_infix_arithmetic('rem','rem','Integer remainder',medium).
my_infix_arithmetic('\\/','\\/','Bitwise disjunction between integers',medium).
my_infix_arithmetic('#','#','Bitwise exclusive or between integers',medium).
my_infix_arithmetic('+','+','Addition',low).
my_infix_arithmetic('-','-','Difference between its arguments',low).
my_infix_arithmetic('/\\','/\\','Bitwise conjuntion between integers',low).
my_infix_arithmetic('<<','<<','Shift left the first argument the number of places indicated by the second one',low).
my_infix_arithmetic('>>','>>','Shift right the first argument the number of places indicated by the second one',low).


/*********************************************************************/
/* Solving Prolog Goals                                              */
/*********************************************************************/

solve_prolog(Goal,Vars) :- 
  solve_prolog_body(Goal,Vars), 
  write_with_vars(Goal,Vars), 
  nl_log, 
  write_log('? (type ; for more solutions, <Intro> to continue) '), 
  flush_output,
  readln(S,_), 
  (batch(_,_,_) -> write_string(S), nl, inc_line; true),
  write_only_to_log(S), nl_only_to_log, 
  S=="", !, nl_log, write_log(yes), nl_log.
solve_prolog(_Goal,_R) :- 
  write_log(no), 
  nl_log.

solve_prolog_body(true,_) :- 
  !.
solve_prolog_body((G,Gs),R) :- 
  !, 
  solve_prolog_goal(G,R), 
  solve_prolog_body(Gs,R).
solve_prolog_body(G,R) :- 
  solve_prolog_goal(G,R).

solve_prolog_goal(not(G),R) :- % Negation
  !, 
  my_not(solve_prolog_body(G,R)).
solve_prolog_goal(G,_) :-      % Solves a goal using all of its matching rules
  (datalog((G:-B),NVs,Ls,Fid); (datalog(G,NVs,Ls,Fid),B=true)),
  R=datalog((G:-B),NVs,Ls,Fid),
  solve_prolog_body(B,R).
solve_prolog_goal(G,R) :-      % Prolog Built-ins
  G =.. [P|As],
  (my_builtin_pred(P) ->
   call(G)
   ;
   (user_predicates(Ps),
    length(As,L),
    (my_memberchk(P/L,Ps) ->
     fail
     ;
     my_raise_exception(G,undefined,R)
    )
   )
  ).


/*********************************************************************/
/* Solving Datalog Queries                                           */
/*********************************************************************/

solve_datalog_query(Query,Undefined) :-
  strata(S),
  (S==[] ->
    solve_datalog_stratum(Query,Undefined)  % No program was loaded; so, no strata computed
    ;
    (S==[non-stratifiable] -> 
      try_solve_stratified(Query,Undefined) % Although in a non-stratifiable program, try to solve for the given query, hopefully finding a stratifiable subprogram
     ;
      solve_stratified(Query,Undefined))).  % Stratifiable program: stratum solving

solve_datalog_stratum(Query,_Undefined) :- 
  solve_star(Query). % This call is always made to fail
solve_datalog_stratum(_Query,Undefined) :-
  remove_undefined(Undefined).

solve_datalog_stratum_list(Query,Undefined,[Q|Qs]) :-
  solve_datalog_stratum(Q,_U),
  solve_datalog_stratum_list(Query,Undefined,Qs).
solve_datalog_stratum_list(Query,Undefined,[]) :-
  solve_datalog_stratum(Query,Undefined).
  
try_solve_stratified(Query,Undefined) :-
  (Query=not(Q) -> true; Query=Q),
  pdg(G),
  functor(Q,N,A),
  sub_pdg(N/A,G,SG),
  stratify(NS,SG,B), !,
  (B==false -> 
   (write_log_list(['Warning: Unable to ensure correctness for this query.', nl]),
    solve_datalog_stratum(Query,Undefined)); % Non-stratifiable yet
   (write_log_list(['Info: Stratifiable subprogram found for the given query.', nl]),
    strata(S),
    load_stratification(NS,SG),
    solve_stratified(Query,Undefined),
    load_stratification(S,G))).

solve_stratified(Query,Undefined) :- 
  (Query=not(Q) -> true; Query=Q),
  pdg(G),
  functor(Q,N,A),
  sub_pdg(N/A,G,(_Nodes,Arcs)),
  neg_dependencies(Arcs,ND),
  (ND=[] ->
   solve_datalog_stratum(Query,Undefined)
   ;
   strata(S),
   sort_by_strata(S,ND,SR),
   build_queries(SR,Queries,NVs),
   (verbose(on) -> 
    write_log('Info: Computing by stratum of '),
    write_with_varsL(Queries,NVs),
    write_log_list(['.',nl])
    ;
    true),
   solve_datalog_stratum_list(Query,Undefined,Queries)).

neg_dependencies([],[]).
neg_dependencies([_T-F|As],[F|Fs]) :-
  neg_dependencies(As,Fs).
neg_dependencies([_T+_F|As],Fs) :-
  neg_dependencies(As,Fs).

sort_by_strata(S,R,SR) :-
  flip_pairs(S,FS),
  my_sort(FS,OFS),
  filterdrop(OFS,R,SR).

flip_pairs([],[]).
flip_pairs([(P,S)|Xs],[(S,P)|Ys]) :-
  flip_pairs(Xs,Ys).

filterdrop([],_,[]).
filterdrop([(_S,P)|Xs],R,[P|Ps]) :-
  my_member(P,R),
  !,
  filterdrop(Xs,R,Ps).
filterdrop([(_S,_P)|Xs],R,Ps) :-
  filterdrop(Xs,R,Ps).

build_queries([],[],[]).
build_queries([N/A|Ps],[Q|Qs],NVs) :-
  length(L,A),
  Q =.. [N|L],
  name_term_vars(L,[],NV1s),
  build_queries(Ps,Qs,NV2s),
  my_append(NV1s,NV2s,NVs).
  
name_term_varsL([],[]).
name_term_varsL([T|Ts],[(T,Vs)|RTVs]) :-
  name_term_vars(T,[],Vs),
  name_term_varsL(Ts,RTVs).

name_term_vars(T,JNVs,NVs) :-
  my_term_variables(T,Vs),
  name_vars(Vs,JNVs,_,NVs).

% (Vars,AlreadyNamed by other procedure, Last name, Name vars)
name_vars([],_,_,[]).
name_vars([V|Vs],JNVs,LN,[N=V|NVs]) :-
  name_var(JNVs,LN,N),
  name_vars(Vs,JNVs,N,NVs).

name_var(NVs,LN,N) :-
  (var(LN) -> 
   first(SN),
   name(TN,SN);
   next(LN,TN)),
   (my_member(TN=_,NVs) ->
    name_var(NVs,TN,N)
    ;
    TN=N).

next(X,Y) :-
  name(X,SX),
  nextS(SX,SY),
  name(Y,SY).

nextS("",SF) :- 
  !, first(SF).
nextS(SX,SY) :-
  my_append(SFX,[LX],SX),
  last([CZ]),
  (LX<CZ ->
   LY is LX+1,
   my_append(SFX,[LY],SY)
   ;
   nextS(SFX,SFY),
   first(SF),
   my_append(SFY,SF,SY)
  ).

first(SF) :-
  name('A',SF).
last(SL) :-
  name('Z',SL).
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fixpoint Computation: solve_star
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

solve_star(Q) :-
  repeat,
  (remove_calls,
   et_not_changed,       % Sets a flag indicating that the extension table has not changed 
   solve(Q,_),           % Solves the call using memoization
   fail;                 % Requests all alternatives
   no_change,!,fail).    % When no more alternatives, restart the computation if the extension table has changed,
                         % otherwise, fail and exit

% Building a Predicate with Fresh Variables
duplicate(Q) :-
  build(Q,G), et(G), equal_up_to_vars(Q,G).

/*********************************************************************/
/* Testing whether two literals are equal up to renaming variables   */
/*********************************************************************/

equal_up_to_vars(not(A),not(NA)) :-
  !, equal_up_to_vars(A,NA).
equal_up_to_vars(G,Q) :-
  G =.. [P|Args],
  Q =.. [P|NArgs],
  equal_up_to_vars_list(Args,NArgs).

equal_up_to_vars_list([],[]).
equal_up_to_vars_list([A|As],[NA|NAs]) :-
  var(A), !, var(NA), equal_up_to_vars_list(As,NAs).
equal_up_to_vars_list([A|As],[NA|NAs]) :-
  nonvar(NA), A=NA,
  equal_up_to_vars_list(As,NAs).

% Get the variables of a term
my_term_variables(T,Vs):-
  my_term_variables(T,[],Vs).
  
my_term_variables(V,Vi,Vo) :-
  var(V), !,
  (my_memberchk(V,Vi) ->
   Vo=Vi
   ;
   my_append(Vi,[V],Vo)).
my_term_variables(T,V,V) :-
  atomic(T), !.  
my_term_variables(T,Vi,Vo) :-
  T=..[_|As], my_terms_variables(As,Vi,Vo).  

my_terms_variables([],Vs,Vs).
my_terms_variables([T|Ts],Vi,Vs) :-
  my_term_variables(T,Vi,Vo1),
  my_terms_variables(Ts,Vo1,Vs).
  
/*********************************************************************/
/* Removing previous calls on a new run of fixpoint computation      */
/*********************************************************************/

remove_calls :-
  retractall(called(_X)).

/*********************************************************************/
/* Testing whether the extension table has not changed               */
/*********************************************************************/

no_change :-
  et_flag(no).

/*********************************************************************/
% Setting Extension Table Flag to 'changed'
/*********************************************************************/

et_changed :-
  set_flag(et_flag,yes).

/*********************************************************************/
% Setting Extension Table Flag to 'not changed'
/*********************************************************************/

et_not_changed :-
  set_flag(et_flag,no).

/*********************************************************************/
% Setting a flag
/*********************************************************************/

set_flag(Flag,Value) :-
  Fact =.. [Flag,_OldValue],
  retractall(Fact),
  NewFact =.. [Flag,Value],
  assertz(NewFact).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solving with Extension Table: solve
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

solve(true,_) :- !.
solve((G,Gs),R) :- !, solve(G,R), solve(Gs,R).
solve(G,R) :- memo(G,R).

% Already called. Extension table with an entry for the current call
memo(G,_) :-
  build(G,Q),           % Builds in Q the same call with fresh variables
  called(Q),            % Tries to find a unifiable call in the extension table for the current call
  my_subsumes(Q,G), !,  % Tests whether the extension table call subsumes the current call
  et(G).                % If so, use the result in the extension table; otherwise, process the new call with the next memo clause
% New call. Extension table without an entry for the current call
memo(G,R) :-
  assertz(called(G)), % Asserts the current call in the extension table (because: 1) there is no previous call to G, or (2) G is not subsumed by a previous call to G
  (et(G);             % If the et is not empty, the first call have to return all the possible answers computed in a previous pass of the fixpoint computation
   (solve_goal(G,R),  % Solves the current call using its matching rules
    build(G,Q),       % Builds in Q the same call with fresh variables
    my_not((et(Q),    % Tests whether there is not an entry in the extension table subsuming the current result
            my_subsumes(Q,G))),
    assertz(et(G)),   % Asserts the new result
    et_changed)).     % Sets a flag indicating that the extension table has changed

% Solving a Goal: solve_goal
solve_goal(not(G),R) :- % Negation; follows the et mechanism
  !, solve_not(G,R).
solve_goal(G,R) :-      % Primitives do not use the et mechanism
  exec_primitive(G,R).
solve_goal(G,_) :-      % Solves a goal using all of its matching rules
  (datalog((G:-B),NVs,Ls,Fid); (datalog(G,NVs,Ls,Fid),B=true)),
  R=datalog((G:-B),NVs,Ls,Fid),
%  clause(G,B), 
  solve(B,R).

% Solving Negation: solve_not for et_not [SD91] and solve_strata (optimized)
solve_not(G,R) :-
  neg(A),
  (A=strata -> 
    solve_strata(G,R);
    solve_et_not(G)).

solve_strata(G,R) :- solve(G,R), !, fail.
solve_strata(_G,_R).

solve_et_not(G) :-
  (solve_star(G), fail; true),  % ET* evaluation
  (et(G), !, fail; true).         % ET lookup

% Executing Prolog Primitives: exec_primitive
exec_primitive(A is B,R) :- 
  (my_ground(B) ->
   A is B
   ;
   my_raise_exception(A is B,instantiation,R)
  ).
exec_primitive(A=B,_R) :- 
  A=B.
exec_primitive(A\=B,R) :- 
  ((var(A); var(B)) ->
   my_raise_exception(A\=B,instantiation,R)
   ;
   A\=B
  ).
exec_primitive(A>B,R)  :- 
  ((var(A); var(B)) ->
   my_raise_exception(A>B,instantiation,R)
   ;
   (number(A) -> A>B  ; A@>B)
  ).
exec_primitive(A>=B,R) :- 
  ((var(A); var(B)) ->
   my_raise_exception(A>=B,instantiation,R)
   ;
   (number(A) -> A>=B ; A@>=B)
  ).
exec_primitive(A<B,R)  :- 
  ((var(A); var(B)) ->
   my_raise_exception(A<B,instantiation,R)
   ;
   (number(A) -> A<B  ; A@<B)
  ).
exec_primitive(A=<B,R) :- 
  ((var(A); var(B)) ->
   my_raise_exception(A=<B,instantiation,R)
   ;
   (number(A) -> A=<B ; A@=<B)
  ).

  
my_raise_exception(G,Mid,R_V) :-
  (seen;true),
  (Mid = instantiation 
   -> 
   Message = 'Non ground argument(s) found in goal'
   ;
   (Mid = undefined ->
    Message = 'Undefined predicate'
    ;
    fail)
  ),
  write_log_list(['Exception: ',Message,' ']),
  (R_V=datalog(R,NVs,Ls,Fid) 
  ->
   write_with_vars(G,NVs),
   write_log_list([' in the instanced rule:',nl,'           ']),
   write_with_vars(R,NVs),
   write_log_list(['.',nl]),
   display_rule_info(Ls,Fid)
  ;
   write_with_vars(G,R_V)
  ),
  nl_log,
  throw(instantiation_error(G,R)).

% Building a Predicate with Fresh Variables
build(A,B) :-
  copy_term(A,B).

% Testing whether a term T1 subsumes a term T2
% i.e., T1 is 'more general' than T2

my_subsumes(General,Specific) :-
  \+ \+ (make_ground(Specific),
         General=Specific).

% Instantiates all variables in Term to fresh constants.

make_ground(Term) :-
  numbervars(Term, 0, _).

% Tests whether a term is ground

my_ground(Term) :-
  copy_term(Term,Copy),
  (Term == Copy ->
   true;
   fail).
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% remove_undefined
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

remove_undefined(Undefined) :-
  setof(Fact, 
        (et(not(Fact)), et(Fact)
         , retract(et(not(Fact))), retract(et(Fact))), 
        Undefined).
remove_undefined([]).


/*********************************************************************/
/* Building a predicate dependency graph: build_pdg/1                */
/*********************************************************************/
% A predicate dependency graph is a pair of a list of predicate nodes 
% (name/arity), and a list of arcs (nto/ato + nfrom/afrom, meaning that
% the predicate nto/ato depends on -has in the rhs of any of its defining
% rules- the predicate nfrom/afrom; alternatively, nto/ato - nfrom/afrom 
% is used when the predicate nfrom/afrom appears negated)
% Follows [ZCF+97]

build_pdg((Nodes,Arcs)) :-
  write_verb(['Info: Computing predicate dependency graph...',nl]),
  (setof(LLArcs,find_pdg_arcs(LLArcs),LLArcs);LLArcs=[]),
  concatLsts(LLArcs,LArcs),
  remove_duplicates(LArcs,Arcs),
  user_predicates(LHSNodes),
  !,
  rhsnodes(Arcs,RHSNodes),
  my_merge(LHSNodes,RHSNodes,Nodes),
  display_undefined(RHSNodes,LHSNodes), 
  !.
build_pdg(([],[])).

user_predicates(Preds) :-
  setof(N/A, 
        H^B^LN^V^Fid^((datalog(':-'(H,B),V,LN,Fid);datalog(H,V,LN,Fid)),functor(H,N,A),N\==(':-')), 
        Preds).
        
find_pdg_arcs(Arcs) :-
  datalog(':-'(H,B),_,_,_), 
  functor(H,N,A), 
  pdg_arcs_from_to(B,N/A,Arcs).

pdg_arcs_from_to((B,Bs),P,[Arc|Arcs]) :-
  pdg_arc(B,P,Arc),
  !,
  pdg_arcs_from_to(Bs,P,Arcs).
pdg_arcs_from_to(B,P,[Arc]) :-
  pdg_arc(B,P,Arc).

pdg_arc(not(T),P,P-N/A) :- % Negative dependency
  functor(T,N,A), !.
pdg_arc(T,P,P+N/A) :-      % Positive dependency
  functor(T,N,A), !.

rhsnodes([],[]).
rhsnodes([Arc|Arcs],[N/A|Nodes]) :-
  (Arc = P-N/A; Arc = P+N/A),
  rhsnodes(Arcs,Nodes).

display_undefined(RHSNodes,LHSNodes) :-
  my_builtin_preds(BIPreds),
  my_append(LHSNodes,BIPreds,LBIPreds),
  findall(TableName/Arity,table(TableName,Arity),TAs),
  my_append(LBIPreds,TAs,Preds),
  my_set_diff(RHSNodes,Preds,UndefPred),
  (UndefPred == [] -> 
   true
   ;
   remove_duplicates(UndefPred,RUndefPred),
   my_sort(RUndefPred,SUndefPred),
   write_log_list(['Warning: Undefined predicate(s): ',SUndefPred,nl])).
   
my_builtin_preds(BIPreds) :-
  setof(IR/2,M1^my_infix_relation(IR,M1),IRs),
  setof(IC/2,M2^my_infix_comparison(IC,M2),ICs),
  my_append(IRs,ICs,BIPreds).

/*********************************************************************/
/* Building a predicate dependency subgraph: sub_pdg/3               */
/*********************************************************************/
% Given a starting node N and a pdg G, build the subgraph of nodes reachable from N in G

sub_pdg(N,(_Nodes,Arcs),(SNodes,SArcs)) :-
  setof(Path,N^Q^Arcs^reachable(N,Q,Arcs,[],Path),Path),
  concatLsts(Path,G),
  remove_duplicates(G,SArcs),
  nodes_in(SArcs,DNodes),
  remove_duplicates(DNodes,SNodes).

% reachable(From,To,Arcs,Used,AccUsed)
reachable(F,F,_Arcs,U,U). 
reachable(F,T,Arcs,U,[Arc|U]) :- 
  arc(F,T,Arc,Arcs), my_not(my_member(Arc,U)).
reachable(F,T,Arcs,U,Uo) :- 
  arc(F,R,Arc,Arcs), my_not(my_member(Arc,U)), 
  reachable(R,T,Arcs,[Arc|U],Uo).

arc(F,T,F+T,[F+T|_As]).
arc(F,T,F-T,[F-T|_As]).
arc(F,T,Arc,[_A|As]) :- arc(F,T,Arc,As).

nodes_in([],[]).
nodes_in([Arc|Arcs],[F,T|Nodes]) :-
  (Arc=F+T; Arc=F-T),
  nodes_in(Arcs,Nodes).


/*********************************************************************/
/* Finding a stratification: stratify/3                              */
/*********************************************************************/
% Follows Ullman, but modified for pdg
% Finds a stratification from a given predicate dependency graph, 
% and returns whether it was successful

stratify(S,(N,A),Success) :-
  write_verb(['Info: Computing strata...',nl]),
  assign_1st_stratum(N,FS),
  length(N,Max),
  lfp_recompute_strata(A,FS,S,Max,Success).

assign_1st_stratum([],[]).
assign_1st_stratum([N/A|Ns],[(N/A,1)|SNs]) :-
  assign_1st_stratum(Ns,SNs).

lfp_recompute_strata(A,Si,Sj,Max,Success) :-
  recompute_strata(A,Si,So,Max,false,Change,SSuccess),
  (SSuccess=false -> fail; true),
  (Change=false -> So=Sj, Success=true, !;
   lfp_recompute_strata(A,So,Sj,Max,Success)).
lfp_recompute_strata(_A,S,S,_Max,false).

recompute_strata([],S,S,_Max,C,C,true) :- !. 
recompute_strata([A|As],Si,Sj,Max,Ci,Co,B) :-
  (A = Nt/At-Nf/Af, Add=1 ; A = Nt/At+Nf/Af, Add=0),
  recompute_stratum(Nt/At,Nf/Af,Add,Si,So,Stratum,C1),
  my_or(Ci,C1,C2),
  (Stratum > Max -> fail ; 
   recompute_strata(As,So,Sj,Max,C2,Co,B)).
recompute_strata(_A,S,S,_Max,false). % Non-stratifiable program

recompute_stratum(Nt/At,Nf/Af,Add,Si,Sj,Stratum,Change) :-
  find_stratum(Nt/At,Si,Stt),
  find_stratum(Nf/Af,Si,Stf),
  IStf is Stf+Add,
  my_max(Stt,IStf,Stratum),
  (Stt=Stratum -> Change=false, Si=Sj; Change=true, reassign_stratum(Nt/At,Stratum,Si,Sj)).

find_stratum(N/A,[(N/A,Stratum)|_Ps],Stratum) :- !.
find_stratum(N/A,[_P|Ps],Stratum) :-
  find_stratum(N/A,Ps,Stratum).

reassign_stratum(N/A,Stratum,[(N/A,_St)|Ps],[(N/A,Stratum)|Ps]) :- !.
reassign_stratum(N/A,Stratum,[P|Ps],[P|NPs]) :-
  reassign_stratum(N/A,Stratum,Ps,NPs).


/*********************************************************************/
/* Computing Stratification: compute_stratification/0                */
/*********************************************************************/

compute_stratification :-
  clear_stratification,
  build_pdg(G),
  stratify(S,G,Success),
  assertz(pdg(G)),
  (Success==true -> 
   assertz(strata(S)), !
   ; 
   (assertz(strata([non-stratifiable])), !,
    write_log('Warning: Non stratifiable program.'), nl_log)
  ).


/*********************************************************************/
/* Loading Stratification: load_stratification/2                     */
/*********************************************************************/

load_stratification(S,G) :-
  clear_stratification, 
  assertz(strata(S)),
  assertz(pdg(G)).


/*********************************************************************/
/* Drilling Down Stratification: drilldown_stratification/1          */
/*********************************************************************/

drilldown_stratification(_L) :- %TODO
  compute_stratification.


/*********************************************************************/
/* Rolling Up Stratification: rollup_stratification/1                */
/*********************************************************************/

rollup_stratification(_L) :- %TODO
  compute_stratification.


/*********************************************************************/
/* Reset Stratification: reset_stratification/0                   */
/*********************************************************************/

reset_stratification :- 
  clear_stratification,
  assertz(strata([])),
  assertz(pdg([])).


/*********************************************************************/
/* Clearing Stratification: clear_stratification/0                   */
/*********************************************************************/

clear_stratification :- 
  retractall(strata(_)),
  retractall(pdg(_)).


/*********************************************************************/
/* Save extension table: save_et/1                                   */
/*********************************************************************/

save_et((ESet,CSet)) :- 
  findall(et(EFact), (et(EFact), retractall(et(EFact))), ESet),
  findall(called(CFact), (called(CFact), retractall(called(CFact))), CSet).


/*********************************************************************/
/* Restoring extension table: restore_et/1                           */
/*********************************************************************/

restore_et((ESet,CSet)) :- 
  retractall(et(_EFact)),
  retractall(called(_CFact)),
  my_apply(assertz,ESet),
  my_apply(assertz,CSet).



/*********************************************************************/
/* Listing Datalog Rules (Command): list_rules/1                     */
/*********************************************************************/

list_rules(I) :- 
  bagof((R,Vs),L^F^datalog(R,Vs,L,F),RVs),
  !,
  my_quicksort(RVs,ORVs),
  display_datalog_rules(ORVs,I).
list_rules(_I).


/*********************************************************************/
/* Listing Datalog Rules matching name and arity (Command): list_rules/3  */
/*********************************************************************/

list_rules(N,A,I) :- 
  bagof((R,Vs),
        H^B^L^F^
        (datalog(R,Vs,L,F),
        (R=':-'(H,B); H=R), 
        functor(H,N,A)),
        RVs),
  !,
  my_quicksort(RVs,ORVs),
  display_datalog_rules(ORVs,I).
list_rules(_N,_A,_I).


/*********************************************************************/
/* Listing Datalog Rules matching a name (Command): list_rules/2     */
/*********************************************************************/

list_rules(N,I) :- 
%  list_rules(N,_A,I).
  bagof((R,Vs),
        H^B^L^F^A^
        (datalog(R,Vs,L,F),
        (R=':-'(H,B); H=R), 
        functor(H,N,A)),
        RVs),
  !,
  my_quicksort(RVs,ORVs),
  display_datalog_rules(ORVs,I).
list_rules(_N,_I).


/*********************************************************************/
/* Listing Extension Table Contents (Command): list_et               */
/*********************************************************************/

list_et :- 
  write_log_list(['Answers:',nl]),
  list_answers,
  write_log_list(['Calls:',nl]),
  nl_log,
  list_calls.

list_answers :-
  bagof(Fact, et(Fact), Set),
  !,
  display_ordered_set(Set).
list_answers :-
  display_ordered_set([]).

list_calls :-
  bagof(Fact, called(Fact), Set),
  !,
  display_ordered_set(Set).
list_calls :- 
  display_ordered_set([]).

/*********************************************************************/
/* Listing Extension Table Contents matching a Pattern (Command): list_et/1 */
/*********************************************************************/
% Negative information regarding pattern must be explicitly recalled

list_et(N/A) :- 
  !, 
  write_log('Answers:'), nl_log, list_answers(N/A),
  write_log('Calls:'), nl_log, list_calls(N/A).
list_et(N) :- 
  list_et(N/_A).

list_answers(N/A) :- 
  bagof(Fact,
        F^N^A^(
         (et(Fact), functor(Fact,N,A)); 
         (et(Fact), (Fact=not(F)), functor(F,N,A)) 
        ),
        Set), !,
  display_ordered_set(Set).
list_answers(_N/_A) :- 
  display_ordered_set([]).

list_calls(N/A) :- 
  bagof(Fact,
        F^N^A^(
         (called(Fact), functor(Fact,N,A)); 
         (called(Fact), (Fact=not(F)), functor(F,N,A)) 
        ),
        Set), !,
  display_ordered_set(Set).
list_calls(_N/_A) :- 
  display_ordered_set([]).


/*********************************************************************/
/* Listing Builtins (Command): list_builtins                         */
/*********************************************************************/

list_builtins :-
  write_log('Comparison Operators:'), nl_log,
  (my_infix_comparison(OP,M), write_log('  '), write_tab_log(OP,10), write_log(' '), write_log(M), nl_log, fail; true),
  write_log('Arithmetic Operators:'), nl_log,
  (unary_operator(OP,_,M), write_log('  '), write_tab_log(OP,10), write_log(' '), write_log(M), nl_log, fail; true),
  (my_infix_arithmetic(OP,_,M,_), write_log('  '), write_tab_log(OP,10), write_log(' '), write_log(M), nl_log, fail; true),
  write_log('Arithmetic Functions:'), nl_log,
  (arithmetic_function(F,_,M,_), write_log('  '), write_tab_log(F,21), write_log(' '), write_log(M), nl_log, fail; true),
  write_log('Arithmetic Constants:'), nl_log,
  (arithmetic_constant(_,C,M), write_log('  '), write_tab_log(C,10), write_log(' '), write_log(M), nl_log, fail; true),
  write_log('Others:'), nl_log,
  (my_infix_relation(R,M), write_log('  '), write_tab_log(R,10), write_log(' '), write_log(M), nl_log, fail; true),
  write_log('  not(goal)  Stratified negation'), nl_log,
  write_log('  autoview   Reserved word for automatic temporary views'), nl_log.


/*********************************************************************/
/* Asserting Datalog Rules: assert_rules                             */
/*********************************************************************/

assert_rules([],_Error).
assert_rules([R|Rs],Error) :-
  assert_rule(R,Error),
  (var(Error) -> 
    assert_rules(Rs,Error)
    ;
    true).

assert_rule((R,Vars),Error) :-
  my_datetime(X),
  process_term(R,SR,Vars,[],asserted(X),assert,Error),
  (var(Error) -> 
    (verbose(on) -> 
     write_log('Info: Rule '), 
     write_with_vars(SR,Vars), 
     write_log(' asserted.'), 
     nl_log
     ; 
     true)
   ;
   true).


/*********************************************************************/
/* Retracting Datalog Rules: retract_rules                           */
/*********************************************************************/

retract_rules(Rs,Error) :-
  (nonvar(Rs) -> retract_rules_g(Rs,Error) ; true).

retract_rules_g([],_Error).
retract_rules_g([DR|DRs],Error) :-
  retract_rule(DR,Error),
  retract_rules_g(DRs,Error).

retract_rule((DR,_Vs),Error) :-
  retract_rule(DR,Error).
retract_rule(DR,Error) :-
  (datalog(DR,Vars,_,_) ->
   (DR=':-'(H,_B) -> R = DR ; R = ':-'(H,true)),
   (getFileIdsRule(R,Fids) -> retract_fileids(Fids); true),
   retractall(datalog(DR,Vars,_,_)),
   ((verbose(on) -> 
     write_log('Info: Rule(s) '), 
     write_with_vars(DR,Vars), 
     write_log(' retracted.'), 
     nl_log
     ;
     true
    ), 
    !)
    ;
    (write_log('Warning: Cannot retract.'),
     nl_log,
     Error=true
     )
  ).


retract_DL_rules_pattern(_P,[]) :-
  !.
retract_DL_rules_pattern(P,RV) :-
	getFileIds(P,Fids),
	abolishDL(P),
	retract_fileids(Fids),
	write_verb(['Info: Rule(s) retracted:',nl]),
	(verbose(on) ->
	  write_log('      '),
	  write_list_with_vars(RV),
	  nl_log
	 ;
	  true).


/*********************************************************************/
/* Abolishing Datalog Rules (Command): abolishDL/1                   */
/*********************************************************************/

abolishDL(N/A) :- 
  !, 
  length(L,A), 
  H =.. [N|L], 
  retractallDL(H).
abolishDL(N) :- 
  datalog(R,_,_,_), 
  (R =.. [N|_],H=R
   ; 
   R=':-'(H,_B),
   functor(H,N,_A)
  ), 
  retractallDL(H), 
  fail.
abolishDL(_).


/*********************************************************************/
/* Abolishing Datalog Rules (Command): abolishDL                     */
/*********************************************************************/

abolishDL :- 
  datalog(R,_,_,_), 
  retract(datalog(R,_,_,_)), 
  fail.
abolishDL.


/*********************************************************************/
/* Abolishing Extension Table: abolishET                             */
/*********************************************************************/

abolishET :- 
  retractall(et(_F)), 
  retractall(called(_C)).


/*********************************************************************/
/* Abolishing File Table: abolishFT                                  */
/*********************************************************************/

abolishFT :- 
  retractall(filet(_F,_Fid)).


/*********************************************************************/
/* Get File Ids for Rule Pattern: getFileIdsRule/2                   */
/*********************************************************************/

getFileIdsRule(R,Fids) :- 
  copy_term(R,CR),
  setof(Fid,Vs^Ls^(datalog(CR,Vs,Ls,Fid)),Fids).


/*********************************************************************/
/* Get File Ids for Head Pattern: getFileIdsHead/2                   */
/*********************************************************************/

getFileIdsHead(H,Fids) :- 
  copy_term(H,CH),
  setof(Fid,B^Vs^Ls^((datalog(':-'(CH,B),Vs,Ls,Fid); 
                      datalog(CH,Vs,Ls,Fid))),Fids).


/*********************************************************************/
/* Get File Ids: getFileIds/2                                        */
/*********************************************************************/

getFileIds(N/A,Fids) :- 
  !,
  setof(Fid,H^B^Vs^Ls^((datalog(':-'(H,B),Vs,Ls,Fid); 
                        datalog(H,Vs,Ls,Fid)),functor(H,N,A)),Fids).

/*********************************************************************/
/* Get File Ids: getFileIds/2                                        */
/*********************************************************************/

getFileIds(N,Fids) :- 
  setof(Fid,H^B^Vs^Ls^A^((datalog(':-'(H,B),Vs,Ls,Fid); 
                          datalog(H,Vs,Ls,Fid)), functor(H,N,A)),Fids).

  
/*********************************************************************/
/* Retracting File Table Entries: retract_fileids/2                  */
/*********************************************************************/

retract_fileids([]).
retract_fileids([Fid|Fids]) :-
  (datalog(_R,_Vs,_Ls,Fid) ->
   true
   ;
   retractall(filet(_,Fid))),
  retract_fileids(Fids).

  
/*********************************************************************/
/* Displaying                                                        */
/*********************************************************************/

display_solutions(G,U) :-
  et_entries(G,L),
  display_ordered_set(L),
  display_nbr_of_tuples(L,computed),
  display_undefined(U),
  display_elapsedtime.

display_nbr_of_tuples(L,M) :-
  length(L,N),
  (N == 1 -> R = tuple ; R = tuples),
  write_log_list(['Info: ',N,' ',R,' ',M,'.',nl]).

et_entries(S,L) :-
  bagof(S,et(S),L), !.
et_entries(_S,[]).

display_undefined([]) :- !.
display_undefined(U) :-
  write_log('Undefined:'), nl_log,
  display_ordered_set(U).
  
display_ordered_set(L) :-
  write_log('{'),
  my_sort(L, OL),
  my_display_list(OL),
  write_log_list([nl,'}',nl]).

my_display_list([]).
my_display_list([X]) :-
  write_log_list([nl,'  ']),
  write_log_fresh_vars(X). 
my_display_list([X,Y|Xs]) :-
  write_log_list([nl,'  ']),
  write_log_fresh_vars(X),
  write_log(','), 
  my_display_list([Y|Xs]).

display_rule_info(Ls,Fid) :-
   (filet(F,Fid)->
    write_log_list(['           File :',F,nl,
                '           Lines:',Ls])
    ;
    Fid=asserted((Y,M,D,H,Mi,S)),
    write_log_list(['           Asserted at ',H,':',Mi,':',S,' on ',M,'-',D,'-',Y,'.'])
   ).

% Displaying Datalog rules
display_datalog_rules(DLs) :-
  display_datalog_rules(DLs,0).

display_datalog_rules(DLs,I) :-
  write_datalog_rules(DLs,I).

write_datalog_rules([],_I).
write_datalog_rules([DV|DVs],I) :-
  write_datalog_rule(DV,I),
  nl_log,
  write_datalog_rules(DVs,I).

% Rules/Facts, no pretty print
write_datalog_rule((D,Vs),I) :-
  pretty_print(off),
  !,
  write_indent(I),
  write_with_vars(D,Vs),
  write_log('.'). 
% Rules, pretty-print
write_datalog_rule((':-'(Head,Body),Vars),I) :-
  !,
  write_indent(I),
  write_with_vars(Head,Vars), 
  write_log(' :-'),
  nl_log,
  I1 is I+2,
  my_list_to_tuple(Goals,Body),
  write_goals_with_vars(Goals,Vars,I1),
  write_log('.').
% Facts, pretty-print
write_datalog_rule((F,Vars),I) :-
  write_indent(I),
  write_with_vars(F,Vars),
  write_log('.').

write_goals_with_vars([],_Vars,_I).
write_goals_with_vars([Goal],Vars,I) :-
  write_indent(I),
  write_with_vars(Goal,Vars).
write_goals_with_vars([Goal1,Goal2|Goals],Vars,I) :-
  write_indent(I),
  write_with_vars(Goal1,Vars),
  write(','),
  nl_log,
  write_goals_with_vars([Goal2|Goals],Vars,I).


/*********************************************************************/
/* Consulting a list of Datalog programs (Command): consultDLlist    */
/*********************************************************************/

consultDLlist([],Success,Success).
consultDLlist([File|Files],Si,So) :-
  consultDL(File,S),
  my_or(S,Si,S1),
  consultDLlist(Files,S1,So).

/*********************************************************************/
/* Consulting a Datalog Program (Command): consultDL                 */
/*********************************************************************/

consultDL(F,true) :-
  current_input(OldInput),
  try_open(F,CFN,St),             % Try to open file F, which has the complete file name CFN
  assertz(consult(CFN,St)),
  my_new_file_id(CFN,Fid),
  write_verb(['Info: Consulting ',F,'...', nl]),
  repeat,
    my_read(T,Vs,Ls),             % Read a term, along with its variable names and line numbers
    process_term(T,Ts,Vs,Ls,Fid,consult,_Error), % Process it, i.e., parse and assert
    (verbose(on) -> 
     write_log('  '), 
     write_with_vars(Ts,Vs), 
     write_log('.'), 
     nl_log
     ; 
     true), 
    T == end_of_file,             % Loop back if not at end of file
    !,
  close(St),                      % Close the file
  retractall(consult(_,_)),
  set_input(OldInput).
consultDL(F,false) :-
  write_log_list(['Error: Reading file ''',F,'''.', nl]),
  (consult(_,St) -> close(St); true).

process_term(end_of_file,end_of_file,_Vs,_Ls,_Fid,_Action,_Error) :- !.
process_term(T,ST,Vs,Ls,Fid,Action,Error) :-
  (T = ':-'(Head,Body), !; T=Head), 
  my_term_to_string(Head,SHead,Vs),
  (parse_head(Head,[],VH,SHead,[]) -> 
   true
   ; 
   write_log('Error: Syntax error in rule head.'), 
   nl_log, 
   Error=true),
  (nonvar(Body)->
    ((my_term_to_string(Body,SBody,Vs),
      parse_body(_BodyList,VH,_VB,SBody,[]) ->
    true
     ; 
     write_log('Error: Syntax error in rule body.'), nl_log, Error=true))
    ; 
    true),
  ((var(Error);safe(on)) -> 
    make_safe(T,Vs,Action,rule,ST,_Error), 
    assertz(datalog(ST,Vs,Ls,Fid))
    ; 
    ST=T), 
  !.

my_new_file_id(F,Fid) :-
  filet(F,Fid), !,
  write_verb(['Warning: Reloading an already loaded program.',nl,
              '         References to source program may have changed.',nl]).
my_new_file_id(F,Fid) :-
  my_max_fid(MaxFid),
  Fid is MaxFid+1,
  assertz(filet(F,Fid)).

my_max_fid(MaxFid) :-
  setof(Fid,F^filet(F,Fid),Fids),
  my_list_max(Fids,1,MaxFid), 
  !.
my_max_fid(0).
  
my_list_max([],M,M).
my_list_max([X|Xs],M,Max) :- 
  (X>M ->
   my_list_max(Xs,X,Max)
   ;
   my_list_max(Xs,M,Max)
  ).


/*********************************************************************/
/* Trying to safe a rule/goal/view/autoview: make_safe/4             */
/*********************************************************************/

make_safe(':-'(H,B),NVs,Action,Object,':-'(H,OB),Error) :-
  !,
  copy_term((H,B),(CH,CB)),
  mark_safe_vars(CB,H,B,NVs,[],_,Object,Action,Err1),
  (Object=query -> Error=Err1 ; true),
  % Try to reorder when:
  ((my_ground((CH,CB));           % Either all variables are safe,
   (my_ground(CB),Object\=view);  % or body variables are safe,
   (my_term_variables(CB,V1s),    % or only head variables are unsafe. May be safe at run-time
    my_term_variables(CH,V2s),
    same_variables(V1s,V2s)))
    ->
    reorder_goals(B,OGs),% Goals can actually be reordered to ensure that, upon execution, 
                         % demanded arguments become ground before the call,
                         % but this modifies performance for some cases:
                         % p(X) :- X>1,q(X) could be translated into p(X) :- q(X),X>1
                         % In the first case, q(X) is not actually computed for X<=1
    (safe(on) -> OGs=OB; OB=B),
    ((safe(on), B \= OB) ->
     write_log_list(['Info: For allowing a (possible) safe computation, the ',Object,':',nl,'  ']),
     ((Object=rule;Object=view)-> write_with_vars(H,NVs), write_log(' :- '); true),
     write_with_vars(B,NVs),
     write_log_list([nl,'has been translated into:',nl,'  ']),
     ((Object=rule;Object=view)-> write_with_vars(H,NVs), write_log(' :- '); true),
     write_with_vars(OB,NVs),
     nl_log
    ;
    (safe(off)->Error=Err1;true)
    )
   ;
   Error=true,
   OB=B
   ),
   (my_ground(CH) ->
    true
    ;
    (var(Error) -> Error=true; true),
    (%(H,B)=(CH,CB),
     display_unsafe(H,B,CH,CB,NVs,Action,Object),
     fail
     ;
     true
    )
   ),
   (var(Error) -> Error=false; true).
make_safe(H,NVs,Action,Object,H,false) :-
  (my_ground(H) ->
   true;                                             % Contains no variables
   display_unsafe(H,true,H,true,NVs,Action,Object)). % Unsafe: nonground fact
   
same_variables(V1s,V2s) :-
  length(V1s,L),
  length(V2s,L),
  my_set_diff(V1s,V2s,[]).
  
% (Goals (marked), Head, Body, Variables in negated atoms, Names of variables)
mark_safe_vars((G,Gs),H,(B,Bs),NVs,PVi,PVo,Object,Action,Error) :-
  !,
  mark_safe_vars(G,H,B,NVs,PVi,PVo1,Object,Action,E1),
  mark_safe_vars(Gs,H,Bs,NVs,PVo1,PVo,Object,Action,E2),
  my_or(E1,E2,Error).
mark_safe_vars('='(A,A),_,_,_,PVi,PVo,_,_,false) :- 
  !,
  (my_ground(A) ->
   make_ground_pending(PVi,PVo)
   ;
   PVo=PVi).
mark_safe_vars(is(X,Y),H,B,NVs,PVi,PVo,Object,_,Error) :- 
  !,
  (my_ground(Y) -> 
   make_ground(X), % X gets bound when Y does
   make_ground_pending(PVi,PVo),
   Error=false
   ; 
   B=is(_,YB),     % If Y is not safe, 'is' may or will raise an exception
   my_term_variables(Y,Vs),
   PVo=[(X,Vs)|PVi],
   display_warning_comput(B,Y,H,YB,NVs,Object,Error)
  ).
mark_safe_vars(G,H,B,NVs,PVi,PVo,Object,Action,Error) :-
  functor(G,P,A),
  (def_pred(P/A) ->
   make_ground(G),   % Defined predicate 
   make_ground_pending(PVi,PVo),
   Error=false       % (assumed safe, but actually it may not;
                     %  a global analysis should be performed),
                     % all variables are marked as safe
   ;
   (my_ground(G) ->  % Built-in (including negation)
    Error=false      % Nothing to do if all variables are safe (ground goal)
    ;
    (P/A == not/1 -> % Deciding whether not or other built-in
                     % If negation, the rule cannot be computed
     display_neg_error(G,H,B,NVs,Action),
     Error=true
     ;               % If built-in, display computation warning
     display_warning_comput(B,G,H,B,NVs,Object,Error)
    )
   ),
   PVo=PVi
  ).

make_ground_pending([],[]).
make_ground_pending([(X,Vs)|PVi],PVo) :-
  my_ground(Vs),
  !,
  make_ground(X),
  make_ground_pending(PVi,PVo).
make_ground_pending([(X,Vs)|PVi],[(X,Vs)|PVo]) :-
  make_ground_pending(PVi,PVo).

reorder_goals(B,OB) :-
  my_list_to_tuple(Bs,B),
  copy_term(Bs,CBs),
  reorder_goals(Bs,CBs,[],[],OBs),
  my_list_to_tuple(OBs,OB).
  
reorder_goals([],[],[],[],[]) :-
  !.
reorder_goals([B],[_CB],[],[],[B]) :-
  !.
reorder_goals([],[],PGs,CPGs,OBs) :-
  !,
  reorder_goals(PGs,CPGs,[],[],OBs).
reorder_goals(Bs,CBs,PGs,CPGs,OBs) :-
  get_safe_goals(PGs,CPGs,PG1s,CPG1s,SGs),
  SGs\==[],
  !,
  my_append(SGs,VGs,OBs),
  reorder_goals(Bs,CBs,PG1s,CPG1s,VGs).
reorder_goals([B|Bs],[CB|CBs],PGs,CPGs,[B|OBs]) :-
  functor(B,P,A),
  (def_pred(P/A),
   make_ground(CB)
   ; 
   P/A = ('=')/2,
   (my_ground(CB) -> true ; call(CB))),
  !,
  reorder_goals(Bs,CBs,PGs,CPGs,OBs).
reorder_goals([BI|Bs],[CBI|CBs],PGs,CPGs,OBs) :-
  !,
  (CBI=not(A) -> 
   BG=A
   ;
   (CBI=is(X,Y) ->
    BG=Y
    ;
    BG=BI)),
  (my_ground(BG) ->
   (CBI=is(X,Y) -> 
    make_ground(X)
    ;
    true),
   OBs=[BI|OB1s],
   reorder_goals(Bs,CBs,PGs,CPGs,OB1s)
   ;
   reorder_goals(Bs,CBs,[BI|PGs],[CBI|CPGs],OBs)).
reorder_goals(Bs,_CBs,[],[],Bs) :-
  !.

get_safe_goals([],[],[],[],[]).
get_safe_goals([G|Gs],[CG|CGs],PGs,CPGs,[G|SGs]) :-
  my_ground(CG),
  !,
  get_safe_goals(Gs,CGs,PGs,CPGs,SGs).
get_safe_goals([G|Gs],[CG|CGs],[G|PGs],[CG|CPGs],SGs) :-
  get_safe_goals(Gs,CGs,PGs,CPGs,SGs).

display_neg_error(G,H,B,NVs,Action) :-
  (write_log('Error: '),
   write_with_vars(B,NVs),
   write_log_list([' might not be correctly computed because of the unrestricted variable(s):',nl]),
   B=G,
   my_term_variables(B,Vs),
   write_log('  '),
   write_with_varsL(Vs,NVs), 
   write_log(' in rule: '), nl_log,
   fail
  ;
   (Action=consult,verbose(off) -> 
    write_with_vars(':-'(H,B),NVs), nl_log
    ;
    true)
  ).

def_pred(Pred/Arity) :-
  Pred/Arity \== not/1,
  my_builtin_preds(BIPreds),
  my_not(my_member(Pred/Arity,BIPreds)).

display_unsafe(H,B,CH,CB,NVs,Action,Object) :-
  my_term_variables(CH,HVs),
  collect_neg_vars(CB,BVs),
  my_append(HVs,BVs,TVs),
  remove_duplicates(TVs,Vars),
  (Vars==[] ->
   true;
   write_log('Warning: '),
   (Action == consult -> 
    M='Next '
    ;
    M='This '
   ),
   write_log_list([M,Object,' is unsafe because of variable(s):',nl,'  ']),
   (CH=H,
    CB=B,
    write_with_varsL(Vars,NVs),
    fail
    ;
    true),
   write_log_list([nl])),
  (Action == consult, verbose(off) ->
   write_with_vars(':-'(H,B),NVs), nl_log
   ;
   true).

collect_neg_vars((G,Gs),Vs) :-
  !,
  collect_neg_vars(G,GVs),
  collect_neg_vars(Gs,GsVs),
  my_append(GVs,GsVs,Vs).
collect_neg_vars(not(P),Vs) :-
  !, my_term_variables(P,Vs).
collect_neg_vars(_,[]).
   
% Reference literal, copied part of the reference literal, head, original part of the reference lieral, variable names
% Ex: (X is Y, _Y, fib(N,M), Y, ['Y'=Y|...])
% Ex: (X < Y, _X < _Y, fib(N,M), X < Y, ['Y'=Y|...])
display_warning_comput(B,SG,H,SB,NVs,Object,_Error) :-
  my_term_to_string(B,S,NVs),
  SB=SG,
  my_term_variables(H,HVs),
  my_term_variables(SB,BVs),
  ((my_set_diff(BVs,HVs,[]),Object\=view) -> 
   I='Warning: ', M=' may raise a computing exception if non-ground at run-time.'
   ; 
   I='Error: ', M=' will raise a computing exception at run-time.',
   assertz(error)
  ),
  write_log(I),
  write_log_string(S),
  write_log_list([M,nl]),
  fail.
display_warning_comput(_,_,_,_,_,_,Error) :-
  (error -> 
   Error=true,
   retractall(error)
   ;
   Error=false). 
  
/*********************************************************************/
/* Finding Datalog Rules matching a pattern: dlrules/3               */
/*********************************************************************/

dlrules(head,H,L) :-
  (setof((R,V),H^B^LN^Fid^((R=H;R=':-'(H,B)),datalog(R,V,LN,Fid)),L) -> true; L=[]).
dlrules(predname,N,L) :-
  (setof((R,V), H^B^LN^Fid^V^A^((R=':-'(H,B);R=H),datalog(R,V,LN,Fid),functor(H,N,A),N\==(':-')),L) -> true; L=[]).
dlrules(namearity,N/A,L) :-
  (setof((R,V),H^B^LN^Fid^N^A^((R=H;R=':-'(H,B)),functor(H,N,A),datalog(R,V,LN,Fid)),L) -> true; L=[]).


/*********************************************************************/
/* Auxiliary Predicates                                              */
/*********************************************************************/

% Appending two lists
my_append([],X,X).
my_append([X|Xs],Y,[X|Zs]) :-
  my_append(Xs,Y,Zs).

% Appending two lists for finding substrings
my_appendfind([],X,X) :-
  !.
my_appendfind([X|Xs],Y,[X|Zs]) :-
  my_appendfind(Xs,Y,Zs).

% Appending a pair (VariableName,Variable) to an input list
append_var(N,V,Vi,Vi) :- 
  my_member('='(N,V),Vi),
  !.
append_var(N,V,Vi,['='(N,V)|Vi]).

% Member of a list
%my_member(X,[X|_Xs]) :- !.
my_member(X,[X|_Xs]).
my_member(X,[_Y|Xs]) :-
  my_member(X,Xs).

my_memberchk(X,[Y|_Xs]) :-
  X==Y.
my_memberchk(X,[Y|Xs]) :-
  X\==Y,
  my_memberchk(X,Xs).

% Bidirectional list to tuple
my_list_to_tuple([X],X) :-
  X \= (_H,_T).
my_list_to_tuple([X,Y|Xs],(X,Ts)) :-
  my_list_to_tuple([Y|Xs],Ts).

%% Appending two tuples
%my_tuple_append((X,Xs),Y,(X,Zs)) :- !, my_tuple_append(Xs,Y,Zs).
%my_tuple_append(X,Y,(X,Y)).

% List to set
remove_duplicates(L,S) :-
  remove_duplicates(L,[],S).

remove_duplicates([],L,L).
remove_duplicates([X|Xs],AL,L) :-
  my_memberchk(X,AL), !,
  remove_duplicates(Xs,AL,L).
remove_duplicates([X|Xs],AL,L) :-
  remove_duplicates(Xs,[X|AL],L).

% Multiset difference
my_set_diff([], _, []).
my_set_diff([Element|Elements], Set, Difference) :-
%    my_member(Element, Set),
    my_memberchk(Element, Set),
    !,
    my_set_diff(Elements, Set, Difference).
my_set_diff([Element|Elements], Set, [Element|Difference]) :-
    my_set_diff(Elements, Set, Difference).

% Merging two lists; the first one contains no duplicates
my_merge(L,[],L).
my_merge(L,[A|As],Rs) :-
  my_member(A,L), !,
  my_merge(L,As,Rs).
my_merge(L,[A|As],Rs) :-
  my_merge([A|L],As,Rs).

% Quicksort, keeping duplicates
my_quicksort([],[]).
my_quicksort([Head|Tail],Sorted) :- 
  partition(Head,Tail,Left,Right),                                 
  my_quicksort(Left,SortedL),
  my_quicksort(Right,SortedR),
  my_append(SortedL,[Head|SortedR],Sorted).

partition(_Pivot,[],[],[]).
partition(Pivot,[Head|Tail],[Head|Left],Right) :-
  Head @=< Pivot,
  !,
  partition(Pivot,Tail,Left,Right).
partition(Pivot,[Head|Tail],Left,[Head|Right]) :-
  partition(Pivot,Tail,Left,Right).

% Map
my_apply(_X,[]).
my_apply(X,[L|Ls]) :-
  L = [_H|_T],
  !,
  T =.. [X|L],
  call(T),
  my_apply(X,Ls).
my_apply(X,[Y|Ys]) :-
  !,
  T =.. [X,Y],
  call(T),
  my_apply(X,Ys).
 
% Maximum of two numbers
my_max(A,B,A) :- A>=B,!.
my_max(_A,B,B).

% Term to string
my_term_to_string(T,S,_Vs) :- 
  number(T), 
  !,
  name(T,S).
my_term_to_string(T,S,_Vs) :-
  atom(T),
  !,
  name(T,S1),
  S1=[D|_], 
  ((my_uppercase([D]) ; [D]="$")->
   [A] = "'",
   my_append([A|S1],[A],S)
   ;
   S=S1).
my_term_to_string(V,S,Vs) :- 
  var(V),
  !,
  my_var_name(V,N,Vs),
  name(N,S).
my_term_to_string(T,S,Vs) :-
  T =.. [F,A],
  unary_operator(F,_POp,_D),
  !,
  my_term_to_string(F,S1,Vs),
  my_term_to_string(A,S2,Vs),
  "(" = [OP], ")" = [CP], 
  my_append(S1,[OP|S2],S3),
  my_append(S3,[CP],S).
my_term_to_string(C,S,Vs) :- 
  C =.. [F|As],
  !, 
  (F = (',') ->
    my_terms_to_string(As,S,Vs)
    ;
    (my_infix(F) ->
     As = [L|Rs],
     my_term_to_string(L,S1,Vs),
     name(F,S2),
     " " = [BL],
     my_append(S1,[BL|S2],S3), 
     my_terms_to_string(Rs,S4,Vs),
     my_append(S3,[BL|S4],S) 
     ;
     my_terms_to_string(As,S2,Vs),
     my_term_to_string(F,S1,Vs),
     "(" = [OP], ")" = [CP], 
     my_append(S1,[OP|S2],S3),
     my_append(S3,[CP],S))).

my_terms_to_string([],"",_Vs) :-
  !.
my_terms_to_string([T1],S,Vs) :-
  !,
  my_term_to_string(T1,S,Vs).
my_terms_to_string([T1,T2|Ts],S,Vs) :- !, 
  my_term_to_string(T1,S1,Vs), 
  my_terms_to_string([T2|Ts],S2,Vs), 
  "," = [C], 
  my_append(S1,[C|S2],S).

  
% Get the program variable name

my_var_name(V,N,[N=V1|_Vs]) :- 
  V == V1, !.
my_var_name(V,N,[_|Vs]) :- 
  my_var_name(V,N,Vs).
my_var_name(_,'_',[]).

% Logical disjunction
my_or(true,true,true).
my_or(true,false,true).
my_or(false,true,true).
my_or(false,false,false).

% Retractall
retractallDL(H) :-
  retractall(datalog(H,_,_,_)),
  retractall(datalog((H:-_B),_,_,_)).

% Prolog implementation of negation
my_not(G) :- 
  call(G), 
  !, 
  fail.
my_not(_G).

% Testing whether the input list contains variables
vars([]).
vars([V|Vs]) :- 
  var(V), 
  vars(Vs).

% concatLsts(+ListOfLists,-List) Appends a list of lists 
%   and returns the flattened list

concatLsts([],[]).
concatLsts([[]|R],S) :-
  concatLsts(R,S).
concatLsts([[C|R1]|R2],[C|S]) :-
  concatLsts([R1|R2],S).

% Building a conjunctive term
conjunctive_term([T],T) :- !.
conjunctive_term([T1,T2],CT) :- 
  !, CT =.. [',',T1,T2].
conjunctive_term([T|Ts],CT) :- 
  CT =.. [',',T,CTT],
  conjunctive_term(Ts,CTT).

% Opening a File
try_open(F,CFN,St) :- 
  (my_file_exists(F) ->
   FP=F
  ;
   name(F,L), 
   my_append(L,".dl",FPL), 
   name(FP,FPL), 
   my_file_exists(FP)
  ),
  !, 
  my_absolute_filename(FP,CFN),
  (open(FP,read,St),
   set_input(St) ->
   true
   ;
   write_log_list(['Error: Stream cannot be opened.',nl]), fail). 
try_open(F,_,_) :-
  write_log_list(['Error: File ''',F,''' not found.',nl]), fail.


% Changing the Current Path

cd_path(NPath) :-
  ensure_atom(NPath,Path),
  (my_directory_exists(Path), !,
   my_change_directory(Path),
   pwd_path;
   write_log_list(['Error: Cannot access the path ''', Path, '''.', nl])).

% Displaying the Current Path

pwd_path :-
  write_log('Info: Current directory is:'), 
  nl_log, 
  write_log('  '), 
  my_working_directory(Path), 
  write_log(Path), 
  nl_log.

% Listing Directory Contents

ls :-
  my_working_directory(WorkingPath),
  ls(WorkingPath).

ls(NPath) :-
  ensure_atom(NPath,Path),
  (my_not(my_directory_exists(Path)) ->
   (write_log('Warning: Path '''), write_log(Path), write_log(''' does not exist.'), nl_log);
   (my_directory_files(Path, List),
    my_absolute_filename(Path, AbsolutePath),
    write_log('Info: Contents of '), write_log(AbsolutePath), nl_log, nl_log, 
    write_log('Files:'), write_dir_files(List, Path), nl_log,
    write_log('Directories:'), write_dir_directories(List, Path), nl_log)).

% Returns always an atom, just in case its input is a number

ensure_atom(N,A) :-
  (number(N) -> number_codes(N,CL), atom_codes(A,CL); N=A).

% Writing each File in a Directory. Path comes without final slash

write_dir_files([],_Path).
write_dir_files([F|Fs],Path) :-
  name(Path,SPath), 
  name(F,SF), 
  concatLsts([SPath,"/",SF],SFN), 
  name(FN,SFN),
  my_is_file(FN), 
  !, 
  nl_log, 
  write_log('  '), 
  write_log(F), 
  write_dir_files(Fs,Path).
write_dir_files([_F|Fs],Path) :-
  write_dir_files(Fs,Path).

% Writing each Directory in a Directory

write_dir_directories([],_Path).
write_dir_directories([F|Fs],Path) :-
  name(Path,SPath), 
  name(F,SF), 
  concatLsts([SPath,"/",SF],SFN), 
  name(FN,SFN),
  my_is_directory(FN), 
  F \== '.',
  F \== '..', !,
  nl_log,
  write_log('  '),
  write_log(F),
  write_dir_directories(Fs,Path).
write_dir_directories([_F|Fs],Path) :-
  write_dir_directories(Fs,Path).

% Writing a term with its textual variable names

write_with_vars(T,Vs) :-
  my_term_to_string(T,S,Vs),
  write_log_string(S).
  
% Writing a list of terms with their textual variable names

write_list_with_vars(RV) :-
  write_log('['),
  write_csa_with_vars(RV),
  write_log(']').

write_csa_with_vars([]).
write_csa_with_vars([(T,V)]) :-
  write_with_vars(T,V).
write_csa_with_vars([(T1,V1),(T2,V2)|RVs]) :-
  write_with_vars(T1,V1),
  write_log(','), 
  write_csa_with_vars([(T2,V2)|RVs]).

write_with_varsL(Ts,NVs) :-
  write_log('['),
  write_csa_with_vars(Ts,NVs),
  write_log(']').

write_csa_with_vars([],_).
write_csa_with_vars([T],Vs) :-
  write_with_vars(T,Vs).
write_csa_with_vars([T1,T2|RTs],Vs) :-
  write_with_vars(T1,Vs),
  write_log(','), 
  write_csa_with_vars([T2|RTs],Vs).

% Verbose output of lists

write_verb(L) :-
  (verbose(on) -> write_verb_list(L); true).
write_verb_list(_L) :-
  verbose(off),
  !.
write_verb_list([]).
write_verb_list([T|Ts]) :-
  (T==nl, !, nl_log; write_log(T)),
  write_verb_list(Ts).

% Output: both current stream and log file, if enabled

write_log(X) :-
  write(X), 
  (log(_F,S) -> write(S,X); true).

write_log_fresh_vars(X) :-
  name_term_vars(X,[],NVs),
  write_with_vars(X,NVs).

write_log_list([]).
write_log_list([T|Ts]) :-
  (T==nl, !, nl_log; write_log(T)),
  write_log_list(Ts).


write_only_to_log(S) :-
  (log(_F,H) -> name(X,S), write(H,X); true).

nl_log :-
  nl, nl_to_log.

nl_only_to_log :-
  nl_to_log.

nl_to_log :-
  (log(_F,H) -> nl(H); true).


% Writing a string

write_log_string([]) :- !.
write_log_string([C|Cs]) :-
  name(A,[C]),
  write_log(A), 
  write_log_string(Cs).

write_string([]) :- !.
write_string([C|Cs]) :-
  name(A,[C]),
  write(A), 
  write_string(Cs).

  
% Writing a term and spaces to fit a given width

write_tab_log(T,L) :-
  write_log(T),
  atom_length(T,AL),
  SL is L-AL,
  my_spaces(SL,S),
  write_log(S).
  
my_spaces(SL,T):-
  my_spacesS(SL,S),
  name(T,S).
my_spacesS(0,[]) :-
  !.
my_spacesS(N,[Sp|Ts]) :-
  [Sp] = " ",
  N1 is N-1,
  my_spacesS(N1,Ts).


%Syntax error reporting

syntax_error(Where) :- 
  write_log_list(['Error: Syntax error in ', Where, nl]).
  

% Redefinition error

redefinition_error(F,A) :-
  write_log_list(['Error: Syntax error. Trying to redefine the builtin ',F,'/',A,nl]),
  !, fail.

% For parsing variables, e.g.:
% a --> {p(X)}, X
% a --> {p(X)}, my_string(X)
  
my_string([]) --> 
  [].
my_string([C|Cs]) -->
  [C],
  {[A] = "'",
   A =\= C},
  my_string(Cs).

% For parsing keywords, irrespective of the case

% my_kw(CKW) -->
%   my_string(KW),
%   {capitalizeList(KW,CKW)}.

my_kw([],Cs,Cs).
my_kw([CC|CCs],[C|Cs],Ys) :-
  [C] =\= "'",
  to_uppercase(C,CC),
  my_kw(CCs,Cs,Ys).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% to_uppercase_list(+List,-UppercaseList) Converts 
%   the input list to uppercase
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

to_uppercase_list([],[]).
to_uppercase_list([X|Xs],[U|Cs]) :-
  to_uppercase(X,U),
  to_uppercase_list(Xs,Cs).

to_uppercase(X,U) :-
  [X] >= "a",
  [X] =< "z",
  !,
  [UA] = "A",
  [LA] = "a",
  U is X+UA-LA.
to_uppercase(X,X).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% to_lowercase_list(+List,-UppercaseList) Converts 
%   the input list to lowercase
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

to_lowercase_list([],[]).
to_lowercase_list([X|Xs],[U|Cs]) :-
  to_lowercase(X,U),
  to_lowercase_list(Xs,Cs).

to_lowercase(X,U) :-
  [X] >= "A",
  [X] =< "Z",
  !,
  [UA] = "A",
  [LA] = "a",
  U is X-UA+LA.
to_lowercase(X,X).

% Debugging when developing

deb([]).
deb([X|Xs]) :-
  nl, write(X), deb(Xs).
  
% Displaying the system status

display_status :-
  processC(version,[],_),
  processC(verbose,[],_),
  processC(timing,[],_),
  processC(pretty_print,[],_),
  processC(log,[],_), 
  processC(negation,[],_),
  processC(safe,[],_).


%The following is needed for Ciao, it does not work with SWI but do for others

:- initialization((start;true)).

