/sql
create table p(x,y);
insert into p values ('a','b');
insert into p values ('c','d');
create table q(x,y);
insert into q values ('b','c');
insert into q values ('d','e');
create view pqs(x,y) as select * from p union select * from q union select pqs.x,p.y from pqs,p where pqs.y=p.x union select pqs.x,q.y from pqs,q where pqs.y=q.x;
