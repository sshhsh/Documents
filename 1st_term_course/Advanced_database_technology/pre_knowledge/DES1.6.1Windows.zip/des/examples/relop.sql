% Switch to SQL interpreter
/sql
%drop schema;
drop table a;
drop table b;
drop table c;
% Creating tables
create table a(a);
create table b(b);
create table c(a,b);
% Listing the database schema
/dbschema
% Inserting values into tables
insert into a values ('a1');
insert into a values ('a2');
insert into a values ('a3');
insert into b values ('b1');
insert into b values ('b2');
insert into b values ('a1');
insert into c values ('a1','b2');
insert into c values ('a1','a1');
insert into c values ('a2','b2');
% Testing the just inserted values
select * from a;
select * from b;
select * from c;
% Projection
select a from c;
% Selection
select a from a where a='a2';
% Cartesian product
select * from a,b;
% Join
select a from a inner join b on a.a=b.b;
% Union 
select * from a union select * from b;
% Difference
select * from a except select * from b;
