/*********************************************************/
/*                                                       */
/* DATALOG Educational System v.1.6.1                    */
/*                                                       */
/*    SQL Subsystem                                      */
/*                                                       */
/*                                                       */
/*                                                       */
/*                                        Fernando S�enz */
/*                                              (c) 2008 */
/*                                             DISIA UCM */
/*             Please send comments, questions, etc. to: */
/*                                     fernan@sip.ucm.es */
/*                                Visit the Web site at: */
/*                           http://des.sourceforge.net/ */
/*                                                       */
/*********************************************************/

/*********************************************************/
/* Features:                                             */
/* - CREATE [OR REPLACE] TABLE                           */
/* - CREATE [OR REPLACE] VIEW                            */
/* - DROP TABLE                                          */
/* - DROP VIEW                                           */
/* - INSERT INTO ... VALUES ...                          */
/* - INSERT INTO ... SQL                                 */
/* - DELETE FROM ... [WHERE ...]                         */
/* - Subqueries defining relations                       */
/* - Relation and attribute autorenaming                 */
/* - Correlated subqueries in EXISTS and IN conditions   */
/* - UNION, INTERSECT, EXCEPT                            */ 
/* - WITH for recursive views                            */
/* - Projection list wildcards: Relation.*, *            */
/* - Subqueries in comparisons (=, <, >, ...)            */
/* - Expressions in projection list                      */ 
/* Limitations:                                          */
/* - Untyped SQL                                         */
/* - No NULL values                                      */
/* - No multiset answers                                 */
/* - No aggregates                                       */
/* TODO:                                                 */
/* - Warn when a view or table is dropped and other      */
/*   view depends on it                                  */
/* - NULL values                                         */
/* - Types                                               */
/* - Multiset answers                                    */
/* - Generate code for distinguished                     */
/*   SELECT ALL and SELECT DISTINCT                      */
/* - Aggregates                                          */
/* - GROUP BY                                            */
/* - ORDER BY                                            */
/* - ALL in comparison subqueries                        */
/*********************************************************/

% ::LOOK FOR WARNING

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SQL Grammar for Valid SQL statements:
% Here, terminal symbols are: parentheses, commas, semicolons, 
% single dots, asterisks, and apostrophes.
% Other terminal symbols are written in capitals.

% SQLstmt ::=
%   DDLstmt[;]
%   |
%   DMLstmt[;]
%   |
%   DQLstmt[;]

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % DDL (Data Definition Language) statements
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% DDLstmt ::=
%   CREATE [OR REPLACE] TABLE CompleteSchema
%   |
%   CREATE [OR REPLACE] VIEW CompleteSchema AS DQLstmt
%   |
%   DROP TABLE TableName
%   |
%   DROP VIEW ViewName
%   |
%   DROP DATABASE
%   
% Schema ::=
%   RelationName
%   |
%   CompleteSchema
%   
% CompleteSchema ::=
%   RelationName(Att,...,Att)

% RelationName is a user identifier intended to name tables, views and aliases
% TableName is a user identifier intended to name tables
% ViewName is a user identifier intended to name views

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % DML (Data Manipulation Language) statements
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% DMLstmt ::=
%   INSERT INTO TableName VALUES (Cte,...,Cte)
%   |
%   INSERT INTO TableName DQLstmt
%   |
%   DELETE FROM TableName
%   |
%   DELETE FROM TableName WHERE Condition

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % DQL (Data Query Language) statements:
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% DQLstmt ::=
%   (DQLstmt) 
%   |
%   UBSQL

% UBSQL ::= 
%   SELECTstmt
%   |
%   DQLstmt UNION DQLstmt
%   |
%   DQLstmt EXCEPT DQLstmt
%   |
%   DQLstmt INTERSECT DQLstmt
%   |
%   WITH LocalViewDefinition,...,LocalViewDefinition DQLstmt

% LocalViewDefinition ::=
%   [RECURSIVE] CompleteSchema AS DQLstmt

% SELECTstmt ::=
%   SELECT [[ALL|DISTINCT]] Args
%   FROM Rels
%   [WHERE Condition]

% Args ::= 
%   *
%   |
%   Arg,...,Arg

% Arg ::=
%   UnrenamedArg
%   |
%   RenamedArg

% UnrenamedArg ::=
%   Att
%   |
%   RelationName.Att
%   |
%   RelationName.*
%   |
%   Expression 

% RenamedArg ::=
%   UnrenamedArg [AS] Identifier

% Expression ::=
%   ArithmeticExpression

% ArithmeticExpression ::=
%   Op1 ArithmeticExpression
%   |
%   ArithmeticExpression Op2 ArithmeticExpression
%   |
%   ArithmeticFunction(ArithmeticExpression,...,ArithmeticExpression)
%   |
%   Number
%   |
%   Att
%   |
%   RelationName.Att
%   |
%   ArithmeticConstant

% Op1 ::=
%   - | \ 

% Op2 ::=
%   ^ | ** | * | / | // | rem | \/ | # | + | - | /\ | << | >> 

% ArithmeticFunction ::=
%   sqrt/1 | ln/1 | log/1 | log/2 | sin/1 | cos/1 | tan/1 | cot/1
%   | asin/1 | acos/1 | atan/1 | acot/1 | abs/1 | float/1 | integer/1
%   | sign/1 | gcd/2 | min/2 | max/2 | truncate/1 | float_integer_part/1
%   | float_fractional_part/1 | round/1 | floor/1 | ceiling/1

% ArithmeticConstant ::=
%   pi | e

% Att is a relation attribute

% Rels ::=
%   Rel,...,Rel

% Rel ::=
%   UnrenamedRel
%   |
%   RenamedRel

% UnrenamedRel ::=
%   TableName
%   |
%   ViewName
%   |
%   DQLstmt
%   |
%   JoinRel

% RenamedRel ::=
%   UnrenamedRel [AS] Identifier

% JoinRel ::=
%   Rel [NATURAL] JoinOp Rel [JoinCond]

% JoinOp ::=
%   INNER JOIN

% JoinCond ::=
%   ON Condition
%   |
%   USING (Att,...,Att)

% Condition ::=
%   UBCond
%   |
%   (UBCond)

% UBCond ::=
%   EXISTS DQLstmt
%   |
%   AttCte IN DQLstmt
%   |
%   (AttCte,...,AttCte) IN DQLstmt
%   |
%   AttCte Operator AttCte 
%   |
%   AttCte Operator DQLstmt 
%   |
%   DQLstmt Operator AttCte 
%   |
%   DQLstmt Operator DQLstmt 
%   |
%   Condition AND Condition
%   |
%   Condition OR Condition
%   |
%   NOT Condition
%   |
%   TRUE
%   |
%   FALSE

% AttCte ::=
%   Att 
%   |
%   Cte

% Operator ::=
%   = | <> | < | > | >= | <= 

% Cte ::=
%   Number
%   |
%   'String'

% Number is an integer or floating-point number
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Database Schema
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% table(RelationName,Arity)
:- dynamic(table/2).
% view(RelationName,Arity,SQLSyntacticTree,DatalogRules,LocalViewDefinitions)
:- dynamic(view/5).
% attribute(Position,RelationName,AttributeName)
:- dynamic(attribute/3).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% parse_sql_query(SQLst). Parses a SQL string and gets its 
%   syntactic tree
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

parse_sql_query(SQLst) -->
  my_blanks_star, 
  my_SQL(SQLst),
  my_blanks_star, 
  my_optional_semicolon, 
  my_blanks_star.  

% DQL Statement
my_SQL(SQLst) -->
  my_DQL(SQLst).
% DML Statement
my_SQL(SQLst) -->
  my_DML(SQLst).
% DDL Statement
my_SQL(SQLst) -->
  my_DDL(SQLst).

% DDL Statements
% CREATE TABLE
my_DDL(CRTSchema) -->
  my_create_or_replace(CR),
  my_blanks,
  my_kw("TABLE"),
  my_blanks,
  my_complete_schema(Schema),
  {atom_concat(CR,'_table',CRT),
   CRTSchema=..[CRT,Schema]}.

% CREATE VIEW
my_DDL(CRVSchema) -->
  my_create_or_replace(CR),
  my_blanks,
  my_kw("VIEW"),
  my_blanks,
  my_complete_schema(Schema),
  my_blanks,
  my_kw("AS"),
  my_blanks,
  my_DQL((LSQLst,Schema)),
  {atom_concat(CR,'_view',CRVF),
   CRVSchema =.. [CRVF,(LSQLst,_AS),Schema]}.

% DROP TABLE
my_DDL(drop_table(Name)) -->
  my_kw("DROP"),
  my_blanks,
  my_kw("TABLE"),
  my_blanks,
  my_user_identifier(Name).

% DROP VIEW
my_DDL(drop_view(Name)) -->
  my_kw("DROP"),
  my_blanks,
  my_kw("VIEW"),
  my_blanks,
  my_user_identifier(Name).

% DROP SCHEMA
my_DDL(drop_database) -->
  my_kw("DROP"),
  my_blanks,
  my_kw("DATABASE").

my_create_or_replace(create) -->
  my_kw("CREATE").
my_create_or_replace(create_or_replace) -->
  my_kw("CREATE"),
  my_blanks,
  my_kw("OR"),
  my_blanks,
  my_kw("REPLACE").

my_schema(Name) -->
  my_user_identifier(Name).
my_schema(Schema) -->
  my_complete_schema(Schema).

my_complete_schema(Schema) -->
  my_user_identifier(Name),
  my_blanks_star,
  "(",
  my_blanks_star,
  my_columns(Cs),
  my_blanks_star,
  ")",
  {Schema =.. [Name|Cs]}.

my_columns([C]) --> 
  my_user_identifier(C).
my_columns([C|Cs]) -->
  my_user_identifier(C),
  my_blanks_star, 
  ",", 
  my_blanks_star, 
  my_columns(Cs).


% DML Statements
% DELETE FROM ... [WHERE]
my_DML(delete_from(TableName,Condition)) -->
  my_kw("DELETE"),
  my_blanks,
  my_kw("FROM"),
  my_blanks,
  my_tablename(TableName),
  my_where_condition(Condition).

% INSERT INTO ... VALUES / SQL
my_DML(insert_into(TableName,VS)) -->
  my_kw("INSERT"),
  my_blanks,
  my_kw("INTO"),
  my_blanks,
  my_tablename(TableName),
  my_blanks,
  my_insert_values_sql(VS).

my_insert_values_sql(Cs) -->
  my_kw("VALUES"),
  {!},
  my_blanks_star,
  "(",
  my_blanks_star,
  my_sql_constants(Cs),
  my_blanks_star,
  ")".
my_insert_values_sql(SQLst) -->
  my_DQL(SQLst).

% DQL Statements
my_DQL(SQLst) -->
  my_b_DQL(SQLst).
my_DQL(SQLst) -->
  my_ub_DQL(SQLst).
 
my_b_DQL(SQLst) -->
  "(",
  my_blanks_star,
  my_DQL(SQLst),
  my_blanks_star,
  ")".
  
% WITH
my_ub_DQL((with(SQLst,SQLsts),_AS)) -->
  my_kw("WITH"),
  my_blanks,
  {!},
  my_local_view_definition_list(SQLsts),
  my_blanks,
  my_DQL(SQLst).
% SELECT
my_ub_DQL(SQLst) -->
  my_select_DQL(SQLst).
% UNION
my_ub_DQL((union(R1,R2),_AS)) -->
  my_b_DQL(R1),
  my_blanks,
  my_kw("UNION"),
  my_blanks,
  my_DQL(R2).
my_ub_DQL((union(R1,R2),_AS)) -->
  my_select_DQL(R1),
  my_blanks,
  my_kw("UNION"),
  my_blanks,
  my_DQL(R2).
% EXCEPT
my_ub_DQL((except(R1,R2),_AS)) -->
  my_b_DQL(R1),
  my_blanks,
  my_kw("EXCEPT"),
  my_blanks,
  my_DQL(R2).
my_ub_DQL((except(R1,R2),_AS)) -->
  my_select_DQL(R1),
  my_blanks,
  my_kw("EXCEPT"),
  my_blanks,
  my_DQL(R2).
% INTERSECT
my_ub_DQL((intersect(R1,R2),_AS)) -->
  my_b_DQL(R1),
  my_blanks,
  my_kw("INTERSECT"),
  my_blanks,
  my_DQL(R2).
my_ub_DQL((intersect(R1,R2),_AS)) -->
  my_select_DQL(R1),
  my_blanks,
  my_kw("INTERSECT"),
  my_blanks,
  my_DQL(R2).

my_local_view_definition_list([V]) -->
  my_local_view_definition(V).
my_local_view_definition_list([V|Vs]) -->
  my_local_view_definition(V),
  my_blanks_star,
  ",",
  my_blanks_star,
  my_local_view_definition_list(Vs).

my_local_view_definition((SQLst,Schema)) -->
  my_optional_recursive,
  my_complete_schema(Schema),
  my_blanks,
  my_kw("AS"),
  my_blanks,
  my_DQL((SQLst,Schema)).

my_optional_recursive -->
  my_kw("RECURSIVE"),
  my_blanks.
my_optional_recursive -->
  [].

% SELECT
my_select_DQL((select(DistinctAll,ProjList,from(Relations),where(Condition)),_AS)) -->
  my_select_stmt(DistinctAll),
  my_sql_arguments(ProjList),
  my_blanks,
  my_kw("FROM"),
  my_blanks,
  my_relations(Relations),
  my_where_condition(Condition).

my_where_condition(Condition) -->
  my_blanks,
  my_kw("WHERE"),
  my_blanks,
  {!},
  my_condition(Condition).
my_where_condition(true) -->
  [].

my_select_stmt(DistinctAll) -->
  my_kw("SELECT"),
  my_blanks,
  my_select_distinct_all(DistinctAll).

my_select_distinct_all(all) -->
  my_kw("ALL"),
  my_blanks,
  {!}.
my_select_distinct_all(distinct) -->
  my_kw("DISTINCT"),
  my_blanks,
  {!}.
my_select_distinct_all(all) -->
  [].

my_sql_constants([C|Cs]) -->
  my_sql_constant(C),
  my_blanks_star, 
  my_remaining_sql_constants(Cs).

my_remaining_sql_constants(Cs) -->
  ",", 
  {!},
  my_blanks_star, 
  my_sql_constants(Cs).
my_remaining_sql_constants([]) -->
  [].

my_relations([R|Rs]) --> 
  my_p_ren_relation(R), 
  my_blanks_star,
  my_remaining_relations(Rs).

my_remaining_relations(Rs) -->
  ",", 
%  {!},   Does not work with WITH statements, where commas separate view definitions
  my_blanks_star, 
  my_relations(Rs).
my_remaining_relations([]) -->
  [].

my_p_ren_relation(R) --> 
  my_relation(R).
my_p_ren_relation(R) --> 
  my_ren_relation(R).

my_ren_relation((R,[I|Args])) -->
  my_relation((R,[I|Args])),
  my_blanks, 
  my_optional_as,
  my_user_identifier(I).

my_relation(R) --> 
  my_b_relation(R).
my_relation(R) --> 
  my_ub_relation(R).

my_b_relation(R) --> 
  "(",
  my_blanks_star,
  my_relation(R),
  my_blanks_star,
  ")".

my_ub_relation((R,_AS)) --> 
  my_join_relation(R).
%,
%  {!}.
my_ub_relation(R) --> 
  my_non_join_relation(R).

my_non_join_relation((T,_)) -->
  my_tablename(T),
  {!}.
my_non_join_relation((T,_)) -->
  my_viewname(T),
  {!}.
my_non_join_relation((R,AS)) -->
  my_DQL((R,AS)).

my_optional_as -->
  my_kw("AS"),  
  my_blanks,
  {!}.
my_optional_as -->
  [].

my_join_relation(JR,SIn,SOut) :-
  look_ahead_join_op(JOp,SIn,SOut1),
  my_list_diff(SIn,SOut1,SDiff),
  my_p_ren_relation(LR,SDiff,[]),
  my_remainder_join_relation(LR,JOp,JR,SOut1,SOut).

% look_ahead_join_op looks the input list for a join operator. 
% This way, my_ub_join_relation may fail in advance and avoid cycling
look_ahead_join_op(JOp,SIn,SOut) :-
  my_chars(_Cs,SIn,SOut),
  my_blanks(SOut,SOut1),
  my_kw("NATURAL",SOut1,SOut2),
  my_blanks(SOut2,SOut3),
  my_join_operator(JOp,SOut3,_SOut4).
look_ahead_join_op(JOp,SIn,SOut) :-
  my_chars(_Cs,SIn,SOut),
  my_blanks(SOut,SOut1),
  my_join_operator(JOp,SOut1,_SOut2).

% L1-L2=LO LO+L2=L1
my_list_diff(L1,L2,LO) :- 
  my_append(LO,L2,L1).

% NATURAL
my_remainder_join_relation(LR,JOp,JR) -->
  my_blanks,
  my_kw("NATURAL"),
  my_blanks,
  my_join_operator(JOp),
  my_blanks,
  my_p_ren_relation(RR),
  {JR =.. [JOp,LR,RR,equijoin(natural)]}.
% ON
my_remainder_join_relation(LR,JOp,JR) -->
  my_blanks,
  my_join_operator(JOp),
  my_blanks,
  my_p_ren_relation(RR),
  my_join_condition(Cond),
  {JR =.. [JOp,LR,RR,Cond]}.

my_join_operator(inner_join) -->
  my_kw("INNER"),
  my_blanks,
  my_kw("JOIN").

my_join_condition(Condition) -->
  my_blanks,
  my_kw("ON"),
  my_blanks,
  {!},
  my_condition(Condition).
my_join_condition(equijoin(Atts)) -->
  my_blanks,
  my_kw("USING"),
  my_blanks_star,
  "(",
  {!},
  my_blanks_star,
  my_column_list(Atts),
  my_blanks_star,
  ")".
my_join_condition(true) -->
  [].

my_condition(C) --> 
  my_b_condition(C),
  {!}.
my_condition(C) --> 
  my_ub_condition(C).

my_b_condition(C) --> 
  "(",
  my_blanks_star,
  my_ub_condition(C),
  my_blanks_star,
  ")".

my_ub_condition(exists(R)) --> 
  my_kw("EXISTS"),
  my_blanks,
  {!},
  my_ub_DQL(R).
my_ub_condition(exists(R)) --> 
  my_kw("EXISTS"),
  my_blanks_star,
  my_b_DQL(R).
my_ub_condition(in(L,R)) --> 
  my_column_or_constant_tuple(L),
  my_blanks,
  my_kw("IN"),
  my_blanks,
  my_DQL(R).
my_ub_condition(not(in(L,R))) --> 
  my_column_or_constant_tuple(L),
  my_blanks,
  my_kw("NOT"),
  my_blanks,
  my_kw("IN"),
  my_blanks,
  my_DQL(R).
my_ub_condition(C) --> 
  my_basic_condition(C).
my_ub_condition(not(C)) --> 
  my_kw("NOT"),
  my_blanks,
  my_ub_condition(C).
my_ub_condition(not(C)) --> 
  my_kw("NOT"),
  my_blanks_star,
  my_b_condition(C).
my_ub_condition(and(C1,C2)) --> 
  my_b_condition(C1),
  my_blanks,
  my_kw("AND"),
  my_blanks,
  my_condition(C2).
my_ub_condition(and(C1,C2)) --> 
  my_basic_condition(C1),
  my_blanks,
  my_kw("AND"),
  my_blanks,
  my_condition(C2).
my_ub_condition(or(C1,C2)) --> 
  my_b_condition(C1),
  my_blanks,
  my_kw("OR"),
  my_blanks,
  my_condition(C2).
my_ub_condition(or(C1,C2)) --> 
  my_basic_condition(C1),
  my_blanks,
  my_kw("OR"),
  my_blanks,
  my_condition(C2).

my_basic_condition(true) --> 
  my_kw("TRUE").
my_basic_condition(false) --> 
  my_kw("FALSE").
my_basic_condition(C) --> 
  my_column_or_constant_or_DQL(L), 
  my_blanks_star, 
  my_relop(O), 
  my_blanks_star, 
  my_column_or_constant_or_DQL(R),
  {C=..[O,L,R]}.

my_column_or_constant_or_DQL(C) -->
  my_column_or_constant(C).
my_column_or_constant_or_DQL(C) -->
  my_DQL(C).

my_column_or_constant_tuple(Cs) --> 
  "(",
  my_blanks_star,
  my_column_or_constant_list(Cs),
  my_blanks_star,
  ")".
my_column_or_constant_tuple([C]) --> 
  my_column_or_constant(C).

my_column_list([C,C2|Cs]) -->
  my_column(C),
  my_blanks_star,
  ",",
  my_blanks_star,
  my_column_list([C2|Cs]).
my_column_list([C]) -->
  my_column(C).

my_column_or_constant_list([C,C2|Cs]) -->
  my_column_or_constant(C),
  my_blanks_star,
  ",",
  my_blanks_star,
  my_column_or_constant_list([C2|Cs]).
my_column_or_constant_list([C]) -->
  my_column_or_constant(C).

my_column_or_constant(C) --> 
  my_column(C).
my_column_or_constant(C) --> 
  my_sql_constant(C).

my_relop(RO) --> 
  {map_cond(RO,_), 
   name(RO,SRO)},
  my_string(SRO).

my_sql_arguments(*) --> 
  "*".
my_sql_arguments([A|As]) --> 
  my_p_ren_argument(A), 
  my_blanks_star, 
  ",", 
  {!},
  my_blanks_star, 
  my_sql_arguments(As).
my_sql_arguments([A]) --> 
  my_p_ren_argument(A).

my_p_ren_argument(A) --> 
  my_ren_argument(A).
my_p_ren_argument(A) --> 
  my_sql_argument(A,_AS).

my_ren_argument(Arg) -->
  my_sql_argument(Arg,AS),
  my_blanks, 
  my_optional_as, 
  my_user_identifier(AS).

my_sql_argument(attr(R,C,AS),AS) --> % Identifers are assumed to be references to table or view attributes, even when they do not exist already (because of the view construction)
  my_column(attr(R,C,AS)).           % In sqlst2rast, references to expressions are known, so that incorrectly assumed attributes can be changed to such references
my_sql_argument((R,(*)),'$') -->  % Cannot be renamed
  my_relname(R),
  ".*".
my_sql_argument(expr(E,AS),AS) -->
  my_sql_expression(E).

my_column(attr(R,C,_AS)) --> 
  my_relname(R),
  ".",
  my_colname(C).
my_column(attr(_T,C,_AS)) --> 
  my_colname(C).

% my_expr_reference(expr_ref(AS)) -->
%   my_user_identifier(AS),
%   {my_not(attribute(_Pos,AS,_Name))}.

my_relname(T) --> 
  my_user_identifier(T).

my_tablename(T) --> 
  my_user_identifier(T),
  {table(T,_TA),
   my_not(view(T,_VA,_SQL,_DLs,_LVDs))}.

my_viewname(V) --> 
  my_user_identifier(V).
%  {view(V,_VA,_SQL,_DLs,_LVDs)}. % Maybe under construction and not yet known

my_colname(C) --> 
  my_user_identifier(C).
%  {attribute(_Pos,_T,C)}. % Maybe from a view under construction and not yet known

%my_user_identifier: an identifier starting by a letter, followed by letters, digits or underscores
% Returns an atom
my_user_identifier(I) --> 
  my_alfa(A),
  my_alfanums(Is),
  {name(I,[A|Is]),
   my_not(my_sql_identifier(I))}.

my_sql_identifier(I) :-
  name(I,Is),
  to_uppercase_list(Is,CIs),
  name(CI,CIs),
  sql_identifier(CI).

sql_identifier('ALL').
sql_identifier('AND').
sql_identifier('ANSWER').
sql_identifier('AS').
sql_identifier('CREATE').
sql_identifier('DELETE').
sql_identifier('DISTINCT').
sql_identifier('DROP').
sql_identifier('EXCEPT').
sql_identifier('EXISTS').
sql_identifier('FALSE').
sql_identifier('FROM').
sql_identifier('FULL').
sql_identifier('IN').
sql_identifier('INNER').
sql_identifier('INSERT').
sql_identifier('INTERSECT').
sql_identifier('INTO').
sql_identifier('JOIN').
sql_identifier('LEFT').
sql_identifier('NATURAL').
sql_identifier('NOT').
sql_identifier('NULL').
sql_identifier('ON').
sql_identifier('OR').
sql_identifier('OUTER').
sql_identifier('RECURSIVE').
sql_identifier('REPLACE').
sql_identifier('RIGHT').
sql_identifier('SELECT').
sql_identifier('TABLE').
sql_identifier('TRUE').
sql_identifier('UNION').
sql_identifier('USING').
sql_identifier('VALUES').
sql_identifier('VIEW').
sql_identifier('WHERE').
sql_identifier('WITH').
sql_identifier(C) :-
  arithmetic_constant(_Value,LC,_Text),
  name(LC,LCs),
  to_uppercase_list(LCs,CLCs),
  name(C,CLCs).
sql_identifier(F) :-
  arithmetic_function(LF,_PrologF,_Text,_Arity),
  name(LF,LFs),
  to_uppercase_list(LFs,CLFs),
  name(F,CLFs).

my_alfanums([A|As]) --> 
  my_alfanum(A),
  {!},
  my_alfanums(As).
my_alfanums([]) --> 
  [].

my_alfa(C) --> 
  my_lowercase(C).
my_alfa(C) --> 
  my_uppercase(C).

my_alfanum(C) --> 
  my_alfa(C).
my_alfanum(C) --> 
  my_digit(C).
my_alfanum(95)--> 
  "_".

my_sql_constant(C) --> 
  my_number(C).
my_sql_constant(C) --> 
  "'",
  my_string(Cs),
  {name(C,Cs)},
  "'".

my_optional_semicolon -->
  ";",
  {!}.
my_optional_semicolon -->
  [].

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parsing SQL expressions
%%%%%%%%%%%%%%%%%%%%%%%%%%%

my_sql_expression(E) -->
  my_sql_arithmeticexp(E).

my_sql_arithmeticexp(E) --> 
  my_sql_aterm(T),
  my_blanks_star, 
  my_sql_arithmeticexp_r(T,E).
my_sql_arithmeticexp_r(E0,E) --> 
  {my_priority_operator(low,SOP,OP)}, 
  my_string(SOP),
  my_blanks_star, 
  my_sql_aterm(T),
  my_blanks_star, 
  {TOP =.. [OP,E0,T]},
  my_sql_arithmeticexp_r(TOP,E).
my_sql_arithmeticexp_r(E,E) -->
  [].

my_sql_aterm(T) --> 
  my_sql_power(P),
  my_blanks_star, 
  my_sql_aterm_r(P,T).
my_sql_aterm_r(T0,T) --> 
  {my_priority_operator(medium,SOP,OP)}, 
  my_string(SOP),
  my_blanks_star, 
  my_sql_power(P),
  my_blanks_star, 
  {TOP =.. [OP,T0,P]},
  my_sql_aterm_r(TOP,T).
my_sql_aterm_r(T,T) -->
  [].

my_sql_power(P) --> 
  my_sql_factor(F),
  my_blanks_star, 
  my_sql_power_r(F,P).
my_sql_power_r(P0,TOP) --> 
  {my_priority_operator(high,SOP,OP)}, 
  my_string(SOP), 
  my_blanks_star, 
  my_sql_factor(P1),
  my_blanks_star,
  {TOP =.. [OP,P0,P]},
  my_sql_power_r(P1,P).
my_sql_power_r(P,P) -->
  [].

my_sql_factor(N) -->
  my_number(N).
my_sql_factor(C) -->
  my_arithmetic_constant(C).
my_sql_factor(C) -->
  my_column(C).
%my_sql_factor(E) -->
%  my_expr_reference(E).

my_sql_factor(T) --> 
  {my_arithmetic_function(SF,F,Arity)},
  my_string(SF), 
  my_blanks_star,
  "(",
  my_blanks_star,
  my_sql_function_arguments(Arity,As),
  my_blanks_star,
  ")",
  {T=..[F|As]}.
my_sql_factor(E) -->
  "(",
  my_blanks_star,
  my_sql_arithmeticexp(E),
  my_blanks_star,
  ")".
my_sql_factor(T) --> 
  {my_unary_operator(SOP,OP)},
  my_string(SOP),
  my_blanks_star, 
  my_sql_arithmeticexp(E),
  {T=..[OP,E]}.

my_sql_function_arguments(1,[E]) -->
  !,
  my_sql_arithmeticexp(E).
my_sql_function_arguments(A,[E|Es]) -->
  {A>1},
  my_sql_arithmeticexp(E),
  my_blanks_star,
  ",",
  my_blanks_star,
  {A1 is A-1},
  my_sql_function_arguments(A1,Es).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% solve_sql_query(+SQLst) Solves a SQL query
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% CREATE TABLE TableName
solve_sql_query(create_table(Schema)) :-
  functor(Schema,TableName,_Arity),
  (table(TableName,_) -> 
   write_log_list(['Error: Table already defined.',nl])
   ;
   create_table(Schema)
  ).
% CREATE OR REPLACE TABLE TableName
solve_sql_query(create_or_replace_table(Schema)) :-
  functor(Schema,TableName,_Arity),
  (table(TableName,_) -> 
   drop_table(TableName)
   ;
   true),
  create_table(Schema).
% CREATE VIEW ViewName
solve_sql_query(create_view(SQLst,Schema)) :-
  functor(Schema,TableName,_Arity),
  (table(TableName,_) -> 
   write_log_list(['Error: Object ',TableName,' already defined.',nl])
   ;
   create_view(SQLst,Schema,[])
  ).
% CREATE OR REPLACE VIEW ViewName
solve_sql_query(create_or_replace_view(SQLst,Schema)) :-
  create_or_replace_view(SQLst,Schema).
% DROP TABLE TableName
solve_sql_query(drop_table(TableName)) :-
  (my_not(table(TableName,_Arity)) -> 
   write_log_list(['Error: Table not defined.',nl])
   ;
   drop_table(TableName)
  ).
% DROP VIEW ViewName
solve_sql_query(drop_view(TableName)) :-
  (my_not(table(TableName,_Arity)) -> 
   write_log_list(['Error: View not defined.',nl])
   ;
   drop_view(TableName)
  ).
% DROP DATABASE
solve_sql_query(drop_database) :-
  write_log('Info: This will drop all views, tables, and Datalog rules. Do you want to proceed? (y/n) '),
  my_get0(Char),
  ([Char] == "y" ->
   drop_database
   ;
   write_verb_list(['Info: Nothing dropped',nl])
  ).
% INSERT INTO TableName VALUES(...)
solve_sql_query(insert_into(TableName,Cs)) :-
  Cs=[_H|_T],
  !,
  (my_not(view(TableName,Arity,_SQLst,_DLs,_LVDs)) ->
   (table(TableName,Arity) ->
    (length(Cs,Arity) ->
     Tuple=..[TableName|Cs],
     assert_rule((Tuple,[]),_Error),
     display_nbr_of_tuples([Tuple],inserted)
%     abolishET, 
%     drilldown_stratification([Tuple])
     ;
     write_log_list(['Error: Incorrect number of arguments.',nl]))
    ;
    write_log_list(['Error: Table ',TableName,' does not exist.',nl]))
   ;
   write_log_list(['Error: Cannot insert into views.',nl])).
% INSERT INTO TableName SQLStmt
solve_sql_query(insert_into(TableName,SQLst)) :-
  (my_not(view(TableName,Arity,_SQLst,_DLs,_LVDs)) ->
   (table(TableName,Arity) ->
    solve_sql_query_k(SQLst,_Schema,_TableRen,_Query,_Undefined),
    insert_tuples(TableName,Arity)
%    abolishET, 
%    drilldown_stratification(_Rules)
    ;
    write_log_list(['Error: Table ',TableName,' does not exist.',nl]))
   ;
   write_log_list(['Error: Cannot insert into views.',nl])).

% DELETE FROM
solve_sql_query(delete_from(TableName,Condition)) :-
  (my_not(view(TableName,Arity,_SQLst,_DLs,_LVDs)) ->
   (table(TableName,Arity) ->
    solve_sql_query_k((select(all,*,from([(TableName,_Ren)]),where(Condition)),_AS),_Schema,_TableRen,_Query,_Undefined),
    delete_tuples(TableName,Arity),
    abolishET 
%    rollup_stratification(_Rules)
    ;
    write_log_list(['Error: Table ',TableName,' does not exist.',nl]))
   ;
   write_log_list(['Error: Cannot delete from views.',nl])).
  

% DQL Statements
solve_sql_query(SQLst) :-
  save_et(ET),
  (solve_sql_query_k(SQLst,Schema,TableRen,Query,Undefined)
   ->
   display_answer_schema(Schema,TableRen),
   display_solutions(Query,Undefined),
   restore_et(ET)
   ;
   restore_et(ET),
   fail).

display_answer_schema([_|Args],TableRen) :-
  write_log('answer('),
  write_csas(Args,TableRen),
  write_log_list([') ->',nl]).

write_csas([A],TableRen) :-
  write_csa(A,TableRen).
write_csas([A1,A2|As],TableRen) :-
  write_csa(A1,TableRen),
  write_log(', '),
  write_csas([A2|As],TableRen).

write_csa(expr(expr_ref(E),_AS),_TableRen) :-
  !,
  write_log(E).
write_csa(expr(attr(RT,C,R),_AS),TableRen) :-
  !,
  write_csa(attr(RT,C,R),TableRen).
write_csa(expr(_E,AS),_TableRen) :-
  write_log(AS).
write_csa(attr(RT,C,_R),TableRen) :-
  find_table_name(RT,TableRen,TableRen,T),
  setof((T,RT2),my_member((T,RT2),TableRen),[(T,RT2)]), % Unambiguous only-one occurrence of table T in the renaming
  !,
  write_log_list([T,'.',C]).
write_csa(attr(RT,C,_R),TableRen) :-
  find_table_name(RT,TableRen,TableRen,T),
  !,
  (atom_concat('$t',_N,T) ->
   write_log(C)
   ;
   atom_concat('$t',N,RT),
   write_log_list([T,'_',N,'.',C])).
write_csa(attr(T,C,_R),_TableRen) :- % Lost renamings
  (atom_concat('$t',_N,T) ->
   write_log(C)
   ;
   write_log_list([T,'.',C])).

find_table_name(RT,[(T,RT)|_RTTs],_TableRen,T) :-
  my_not(atom_concat('$',_,T)),
  !.
find_table_name(RT,[(RT,RT1)|_RTTs],TableRen,T) :-
  atom_concat('$',_,RT),
  find_table_name(RT1,TableRen,TableRen,T).
find_table_name(RT,[(RT2,_RT1)|RTTs],TableRen,T) :-
  RT \= RT2,
  find_table_name(RT,RTTs,TableRen,T).
  
% Solving SQL queries, untouching ET
% WITH
solve_sql_query_k((with(SQLst,SQLsts),_AS),Schema,TableRen,Query,Undefined) :-
  !,
  create_prototype_view_list(SQLsts,_LocalViewDefs),
  create_or_replace_view_list_k(SQLsts),
  solve_sql_query_k(SQLst,Schema,TableRen,Query,Undefined),
  drop_view_list_k(SQLsts).
% SELECT, ...
solve_sql_query_k(SQLst,Schema,TableRen,Query,Undefined) :-
  sqlst2dlsts(SQLst,Schema,TableRen,UDLsts),
  replace_functor('$p1',answer,UDLsts,DLsts),
  name_term_varsL(DLsts,DVs),
  assert_rules(DVs,Error),
  abolishET, 
  drilldown_stratification(DVs),
  (var(Error) ->
   my_member(':-'(Query,_),DLsts),
   Query =.. [answer|_],
   solve_datalog_query(Query,Undefined)
   ;
   true),
  retract_rules(DLsts,_Error).

% Create table
create_table(Schema) :-
  functor(Schema,TableName,Arity),
  assertz(table(TableName,Arity)),
  Schema =.. [TableName|Args],
  assert_attr_list(1,TableName,Args),
  write_verb_list(['Info: Table created.',nl]).

assert_attr_list(_I,_Table,[]) :- !.
assert_attr_list(I,Table,[Arg|Args]) :-
  assertz(attribute(I,Table,Arg)),
  I1 is I+1,
  assert_attr_list(I1,Table,Args).

% Create view
create_view(SQLst,Schema,LVDs) :-
  create_view_k(SQLst,Schema,LVDs),
  abolishET, 
  compute_stratification.
  
% Create view, untouching ET, no stratification computation
create_view_k((with(SQLst,SQLsts),Schema),Schema,_LVDs) :-
  !,
  create_prototype_view_list(SQLsts,LocalViewDefs),
  create_or_replace_view_list_k(SQLsts),
  create_view_k(SQLst,Schema,LocalViewDefs).
create_view_k((SQLst,_Schema),Schema,LocalViewDefs) :-
  functor(Schema,TableName,Arity),
  assertz(table(TableName,Arity)),
  Schema =.. [TableName|Args],
  assert_attr_list(1,TableName,Args),
  sqlst2dlsts((SQLst,_AS),_Schema,_TableRen,DLsts),
  functor(P1,'$p1',Arity),
  my_member(':-'(P1,_B),DLsts),
  !,
  replace_functor('$p1',TableName,DLsts,ARDLsts),
  atom_concat(TableName,'$p',NLV),
  replace_functor_substring('$p',NLV,ARDLsts,RDLsts),
  name_term_varsL(RDLsts,DVs),
  assert_rules(DVs,_Error),
  assertz(view(TableName,Arity,SQLst,DVs,LocalViewDefs)),
  write_verb_list(['Info: View created.',nl]).
create_view_k(_SQLst,Schema,_LVDs) :-
  Schema =.. [TableName|_Args],
  retractall(table(TableName,_Arity)),
  retractall(attribute(_Pos,TableName,_Att)),
  write_log_list(['Error: Incorrect number of arguments in view.',nl]),
  !,
  fail.

% Create views in a list, untouching ET, no stratification computation
create_or_replace_view_list_k([]).
create_or_replace_view_list_k([(SQLst,Schema)|Vs]) :-
  create_or_replace_view_k((SQLst,Schema),Schema),
  create_or_replace_view_list_k(Vs).

% Create prototype views from SQL schemas. Returns the list of view names, and defines the prototype view schema as facts
create_prototype_view_list(Schemas,TableNames) :-
  check_no_redefinitions(Schemas),
  build_prototype_view_list(Schemas,TableNames).

check_no_redefinitions([]).
check_no_redefinitions([(_SQLst,Schema)|Vs]) :-
  functor(Schema,TableName,Arity),
  (table(TableName,Arity) -> 
    write_log_list(['Error: Syntax error. Trying to redefine ',TableName,'/',Arity,nl]),
    !,
    fail
    ;
    true),
  check_no_redefinitions(Vs).

build_prototype_view_list([],[]).
build_prototype_view_list([(_SQLst,Schema)|Vs],[TableName|TableNames]) :-
  functor(Schema,TableName,Arity),
  assertz(table(TableName,Arity)),
  Schema =.. [TableName|Args],
  assert_attr_list(1,TableName,Args),
  assertz(view(TableName,Arity,_SQL,_DVs,_LVDs)),
  build_prototype_view_list(Vs,TableNames).

% Create or replace view
create_or_replace_view((SQLst,Schema),Schema) :-
  functor(Schema,TableName,_Arity),
  (table(TableName,_) -> 
   drop_view_k(TableName),
   !
   ;
   true),
  create_view((SQLst,Schema),Schema,[]).
  
% Create or replace view, untouching ET, no stratification computation
create_or_replace_view_k((SQLst,Schema),Schema) :-
  functor(Schema,TableName,_Arity),
  (table(TableName,_) -> 
   drop_view_k(TableName),
   !
   ;
   true),
  create_view_k((SQLst,Schema),Schema,[]).

% Drop table
drop_table(TableName) :-
  table(TableName,Arity),
  retractall(table(TableName,Arity)),
  retractall(attribute(_Pos,TableName,_Attr)),
  processC(abolish,[TableName/Arity],_Vars),
  abolishET, 
  rollup_stratification(_DLsts),
  write_verb_list(['Info: Table ''',TableName,''' dropped.',nl]).

% Drop table, untouching ET, no stratification computation
drop_table_k(TableName) :-
  table(TableName,Arity),
  retractall(table(TableName,Arity)),
  retractall(attribute(_Pos,TableName,_Attr)),
  dlrules(namearity,TableName/Arity,RV),
  retract_DL_rules_pattern(TableName/Arity,RV),
  write_verb_list(['Info: Table ''',TableName,''' dropped.',nl]).

% Drop view
drop_view(TableName) :-
  table(TableName,Arity),
  retractall(table(TableName,Arity)),
  retractall(attribute(_Pos,TableName,_Attr)),
  view(TableName,Arity,SQLst,DLsts,LVDs),
  drop_viewname_list_k(LVDs),
  retract_rules(DLsts,_Error),
  retractall(view(TableName,Arity,SQLst,DLsts,LVDs)),
  abolishET, 
  rollup_stratification(DLsts),
  write_verb_list(['Info: View ''',TableName,''' dropped.',nl]).

% Drop view, untouching ET, no stratification computation
drop_view_k(TableName) :-
  table(TableName,Arity),
  retractall(table(TableName,Arity)),
  retractall(attribute(_Pos,TableName,_Attr)),
  view(TableName,Arity,SQLst,DLsts,LVDs),
  drop_viewname_list_k(LVDs),
  retract_rules(DLsts,_Error),
  retractall(view(TableName,Arity,SQLst,DLsts,LVDs)),
  write_verb_list(['Info: View ''',TableName,''' dropped.',nl]).

% Drop views in a list
drop_view_list([]).
drop_view_list([(_SQLst,Schema)|Vs]) :-
  Schema =.. [TableName|_Args],
  solve_sql_query(drop_view(TableName)),
  drop_view_list(Vs).

% Drop views in a list, untouching ET
drop_view_list_k([]).
drop_view_list_k([(_SQLst,Schema)|Vs]) :-
  Schema =.. [TableName|_Args],
  drop_view_k(TableName),
  drop_view_list_k(Vs).

% Drop database
drop_database :-
  get_viewnames(AllViewNames),
  get_localviewnames(LocalViewNames),
  my_set_diff(AllViewNames,LocalViewNames,ViewNames),
  drop_viewname_list_k(ViewNames),
  get_tablenames(TableNames),
  drop_tablename_list_k(TableNames),
  abolishDL,
  abolishET, 
  rollup_stratification(_),
  write_verb_list(['Info: Database dropped.',nl]).

drop_tablename_list_k([]).
drop_tablename_list_k([TableName|TableNames]) :-
  drop_table_k(TableName),
  drop_tablename_list_k(TableNames).

drop_viewname_list_k([]).
drop_viewname_list_k([ViewName|ViewNames]) :-
  drop_view_k(ViewName),
  drop_viewname_list_k(ViewNames).

get_tablenames(TableNames) :-
  get_tablenames(_TableName,TableNames).

get_viewnames(ViewNames) :-
  get_viewnames(_ViewName,ViewNames).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Database Commands
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

/*********************************************************************/
/* Listing the DB schema: list_schema/0                              */
/*********************************************************************/

list_schema :-
  list_schema(_N).

/*********************************************************************/
/* Listing the DB schema for either the whole database, or a given   */
/* table or view: list_schema/1                                      */
/*********************************************************************/

list_schema(Name) :-
  get_tablenames(Name,TableNames),
  (TableNames \== [] ->
   (var(Name) -> 
     write_log_list(['Info: Table(s):',nl])
     ;
     write_log_list(['Info: Table:',nl])),
   list_schema_list(TableNames)
   ;
   (var(Name) -> 
     write_log_list(['Info: No tables.',nl])
     ;
     TableNotFound=true)),
  get_viewnames(Name,ViewNames),
  (ViewNames \== [] ->
   (var(Name) -> 
     write_log_list(['Info: View(s):',nl])
     ;
     write_log_list(['Info: View:',nl])),
   list_schema_list(ViewNames)
   ;
   (var(Name) -> 
     write_log_list(['Info: No views.',nl])
     ;
     ViewNotFound=true)),
  (nonvar(Name), TableNotFound == true, ViewNotFound == true ->
     write_log_list(['Info: No table or view found with that name.',nl])
     ;
     true
   ).

get_tablenames(Name,TableNames) :-
  setof(Name,
        Arity^SQLst^DLs^LVDs^
        (table(Name,Arity),
         my_not(view(Name,Arity,SQLst,DLs,LVDs))),
        TableNames),
  !.
get_tablenames(_Name,[]).

get_viewnames(Name,ViewNames) :-
  setof(Name,
        Arity^SQLst^DLs^LVDs^
        view(Name,Arity,SQLst,DLs,LVDs),
        ViewNames),
  !.
get_viewnames(_Name,[]).

get_localviewnames(ViewNames) :-
  setof(LVDs,
        Name^Arity^SQLst^DLs^
        view(Name,Arity,SQLst,DLs,LVDs),
        ListViewNames),
  concatLsts(ListViewNames,DViewNames),
  remove_duplicates(DViewNames,ViewNames),
  !.
get_localviewnames([]).

list_schema_list([]).
list_schema_list([TableName|TableNames]) :-
  get_table_schema(TableName,Table),
  (view(TableName,_Arity,SQLst,DLs,LVDs) -> Type = view ; Type = table),
  write_log_list([' ',Table,nl]), 
  (Type=view -> 
   write_log_list(['  Defining SQL Statement:',nl]),
   display_sql(SQLst,4),
   write_log_list(['  Datalog equivalent rules:',nl]),
   display_datalog_rules(DLs,4),
   (LVDs \== [] ->
      write_log_list(['  Local view definitions:',nl,'    ',LVDs,nl]);
    true)
   ; 
   true),
  list_schema_list(TableNames).

get_table_schema(TableName,Table) :-
  get_table_arguments(TableName,ColNames),
  Table =.. [TableName|ColNames].

get_table_arguments(TableName,ColNames) :-
  setof((Pos,ColName),attribute(Pos,TableName,ColName),PosColNames),
%  findall(ColName,Pos^(my_member((Pos,ColName),PosColNames)),ColNames).
  findall(ColName,(my_member((Pos,ColName),PosColNames)),ColNames).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% sqlst2dlsts(+SQLst,-Schema,-TableRen,-DLsts) 
% Translates a SQL Syntactic Tree
% into a list of Datalog Syntactic Trees, also returning the answer schema
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

sqlst2dlsts(SQLst,Schema,TableRen,DLsts) :-
  sqlst2rast(SQLst,RAst,[],TableRen),
  (RAst = (_RA,Schema) ; true),
  rast2crast(RAst,CRAst),
  crast2dlsts(CRAst,1,_,[],_OMap,TableRen,_ORen,DLsts),
  !.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% sqlst2rast(+SQLst,-RAst,+IRen,-ORen) 
% Translates a SQL Syntactic Tree (SQLST)
% into a Relational Algebra Syntactic Tree (RAST)
% Table and subquery autorenaming is done for unrenamed 
% tables and subqueries. All renamings are annotated in ORen
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% SQLst ::=
%   (
%    with(SQLst,SQLsts),
%    Renaming
%   )
%   |
%   (
%    select(AllDistinct, 
%           Args,
%           from(Rels),
%           where(Cond)
%          ),
%    Renaming
%   )
%   |
%   (
%    union(SQL,SQL),
%    Renaming
%   )
%   |
%   (
%    except(SQL,SQL),
%    Renaming
%   )
%   |
%   (
%    intersect(SQL,SQL),
%    Renaming
%   )
%
% AllDistinct ::=
%   all
%   |
%   distinct
%
% Args ::=
%   *
%   |
%   [Arg,...,Arg]
%
% Arg ::=
%   attr(RelName,Attr,Renaming)
%   |
%   expr(Expression,Renaming)
%
% Expression ::=
%   Arithmetic expression
%
% Rels ::=
%   [Rel,...,Rel]
%
% Rel ::=
%   (Table,Renaming)
%   |
%   SQLst
%   |
%   JoinOp(Rel,Rel,JoinCond)
%
% JoinCond ::=
%   Cond
%   |
%   equijoin(natural)
%   |
%   equijoin([Attr,...,Attr])
%
% JoinOp ::=
%   inner_join
%
% Cond ::=
%   exists(SQLst)
%   |
%   in([AttrCte,...,AttrCte],SQLst)
%   |
%   AttrCte Operator AttrCte 
%   |
%   AttrCte Operator SQLst
%   |
%   SQLst Operator AttrCte
%   |
%   SQLst Operator SQLst
%   |
%   and(Cond,Cond)
%   |
%   or(Cond,Cond)
%   |
%   not(Cond)
%   |
%   true
%   |
%   false

sqlst2rast((union(R1,R2),[RR|RAS]),(union(AR1,AR2),[RR|RAS]),IRen,ORen) :-
  !,
  sqlst2rast(R1,AR1,IRen,Ren),
  sqlst2rast(R2,AR2,Ren,ORen),
  relation_autorenaming(RR),
  relation_arguments(AR1,RAS),
  arguments_autorenaming(RR,RAS).
sqlst2rast((except(R1,R2),[RR|RAS]),(minus(AR1,AR2),[RR|RAS]),IRen,ORen) :-
  !,
  sqlst2rast(R1,AR1,IRen,Ren),
  sqlst2rast(R2,AR2,Ren,ORen),
  relation_autorenaming(RR),
  relation_arguments(AR1,RAS),
  arguments_autorenaming(RR,RAS).
sqlst2rast((intersect(R1,R2),[RR|RAS]),(intersect(AR1,AR2),[RR|RAS]),IRen,ORen) :-
  !,
  sqlst2rast(R1,AR1,IRen,Ren),
  sqlst2rast(R2,AR2,Ren,ORen),
  relation_autorenaming(RR),
  relation_arguments(AR1,RAS),
  arguments_autorenaming(RR,RAS).
sqlst2rast((select(_DistinctAll,UProjList,from(SQLRelations),where(SQLCondition)),[RR|_RArgs]),
           (pi(ProjList,sigma(RACondition,RARelation)),[RR|ProjList]),
           IRen,ORen) :-
  !,
  sqlcond2racond(SQLCondition,RACondition,IRen,Ren1),
  sqlrel2rarel(SQLRelations,RARelation,Ren1,Ren2),
  relation_autorenaming(RR),
  arguments_completion(UProjList,RARelation,UProjList,Ren2,ORen,ProjList),
  arguments_autorenaming(RR,ProjList).
sqlst2rast((inner_join(LRel,RRel,SQLCondition),[RR|_RArgs]),
           (pi(ProjList,sigma(RACondition,RARelation)),[RR|ProjList]),
           IRen,ORen) :-
  !,
  sqlrel2rarel([LRel,RRel],RARelation,IRen,Ren1),
  RARelation = times((_RALR,LAS),(_RARR,RAS)),
  arguments_completion(*,RARelation,[],Ren1,Ren2,Atts),
  relation_autorenaming(RR),
  arguments_autorenaming(RR,Atts),
  sqljoincond2racond(SQLCondition,RACondition,LAS,RAS,Atts,ProjList,Ren2,ORen).
sqlst2rast((T,[RR|RArgs]),(T,[RR|RArgs]),Ren,[(T,RR)|Ren]) :-
  table(T,_Arity),
  !,
  relation_autorenaming(RR),
  get_table_arguments(T,Args),
  build_ren_arguments(T,Args,RArgs),
  arguments_autorenaming(RR,RArgs).

build_ren_arguments(_T,[],[]).
build_ren_arguments(T,[A|As],[attr(T,A,_RA)|RAs]) :-
  build_ren_arguments(T,As,RAs).

relation_arguments((_R,[_RR|RAS]),RAS).

relation_autorenaming(AS) :-
  (var(AS) ->
   build_id(t,AS)
   ;
   true).

arguments_autorenaming(_RR,[]) :-
  !.
arguments_autorenaming(Rel,[expr(E,AS)|As]) :-
  !,
  argument_autorenaming(AS),
  expr_arguments_autorenaming(E),
  arguments_autorenaming(Rel,As).
arguments_autorenaming(Rel,[attr(Rel,_A,AS)|As]) :-
  !,
  argument_autorenaming(AS),
  arguments_autorenaming(Rel,As).
arguments_autorenaming(RR,[attr(_Rel,_A,AS)|As]) :-
  argument_autorenaming(AS),
  arguments_autorenaming(RR,As).

expr_arguments_autorenaming(E) :-
  (number(E) ; atom(E)),
  !.
expr_arguments_autorenaming(expr_ref(_AS)) :- 
  !.
expr_arguments_autorenaming(attr(_Rel,_A,AS)) :- 
  !,
  argument_autorenaming(AS).
expr_arguments_autorenaming(E) :- 
  E =.. [_F|Args],
  !, 
  expr_arguments_autorenaming_list(Args).

expr_arguments_autorenaming_list([]) :-
  !.
expr_arguments_autorenaming_list([E|Es]) :-
  !, 
  expr_arguments_autorenaming(E), 
  expr_arguments_autorenaming_list(Es).

argument_autorenaming(AS) :-
  (var(AS) ->
   build_id(a,AS)
   ;
   true).

arguments_completion(*,(pi(ProjList,_S),[RR|RArgs]),_PL,IRen,ORen,RArgs) :-
  !,
  rel_ren_projlist(ProjList,RR,IRen,ORen).
arguments_completion(*,(T,[AS|_RArgs]),_PL,Ren,Ren,ProjList) :-
  table(T,_Arity),
  !,
  I=I, % For avoiding existential quantifier in next findall, since it is unavailable in GNU Prolog
  findall(attr(AS,C,CRen),
%          I^(attribute(I,T,C),
          (attribute(I,T,C),
             argument_autorenaming(CRen)),
          ProjList).
arguments_completion(*,(_Rel,[_AS|RArgs]),_PL,Ren,Ren,RArgs) :-
  !.
arguments_completion(*,times(T1,T2),_PL,IRen,ORen,ProjList) :-
  arguments_completion(*,T1,[],IRen,Ren1,PL1),
  arguments_completion(*,T2,[],Ren1,ORen,PL2),
  my_append(PL1,PL2,ProjList).
arguments_completion([],_RAst,_PL,Ren,Ren,[]) :-
  !.
arguments_completion([(Rel,(*))|As],(RAst,[Rel|RArgs]),PL,IRen,ORen,CAs) :-
  !,
  arguments_completion(As,RAst,PL,IRen,ORen,CA1s),
  my_append(RArgs,CA1s,CAs).
arguments_completion([(Rel,(*))|As],RAst,PL,IRen,ORen,CAs) :-
  !,
  rel_arguments(Rel,RAst,IRen,Ren1,RAs),
  arguments_completion(As,RAst,PL,Ren1,ORen,CA1s),
  my_append(RAs,CA1s,CAs).
% An incorrectly assumed attribute (which are in fact a reference to an expression)
% is translated into a reference to an expression
arguments_completion([attr(_Rel,A,AS)|As],RAst,PL,IRen,ORen,[expr(expr_ref(A),AS)|CAs]) :-
  pl_expr_member(expr(_E,A),PL),
  !,
  arguments_completion(As,RAst,PL,IRen,ORen,CAs).
% References to renamed attributes
arguments_completion([attr(_Rel,A,AS)|As],RAst,PL,IRen,ORen,[attr(R,C,AS)|CAs]) :-
  pl_attr_member(attr(R,C,A),PL),
  !,
  arguments_completion(As,RAst,PL,IRen,ORen,CAs).
arguments_completion([attr(Rel,A,AS)|As],RAst,PL,IRen,ORen,[attr(Rel,A,AS)|CAs]) :-
  argument_completion(attr(Rel,A,AS),RAst),
  !,
  arguments_completion(As,RAst,PL,IRen,ORen,CAs).
arguments_completion([expr(E,AS)|As],RAst,PL,IRen,ORen,[expr(RE,AS)|CAs]) :-
  expr_argument_completion(E,RAst,PL,RE),
  arguments_completion(As,RAst,PL,IRen,ORen,CAs).

% Projection list member. Checks whether the attribute attr(Rel,A,AS) can be found in the projection list.
% Note that the attribute can be a variable
% Reference to the attribute name:
pl_attr_member(attr(Rel,A,_AS),[attr(Rel,Arg,_RArg)|_PL]) :-
  A==Arg,
  !.
% Reference to the attribute renaming:
pl_attr_member(attr(Rel,A,AS),[attr(Rel,A,RArg)|_PL]) :-
  AS==RArg,
  !.
pl_attr_member(attr(Rel,A,AS),[_Attr|PL]) :-
  pl_attr_member(attr(Rel,A,AS),PL).
  
pl_expr_member(expr(E,A),[expr(E,AS)|_PL]) :-
  A==AS,
  !.
pl_expr_member(expr(E,A),[_Arg|PL]) :-
  pl_expr_member(expr(E,A),PL).

expr_argument_completion(E,_RAst,_PL,E) :- 
  (number(E) ; atom(E)),
  !.
% expr_argument_completion(expr_ref(AS),_RAst,_PL,expr_ref(AS)) :- 
%   !.
expr_argument_completion(attr(_Rel,A,_AS),_RAst,PL,expr_ref(A)) :- 
  pl_expr_member(expr(_E,A),PL),
  !.
expr_argument_completion(attr(_Rel,A,_AS),_RAst,PL,attr(R,C,A)) :- 
  pl_attr_member(attr(R,C,A),PL),
  !.
expr_argument_completion(attr(Rel,A,AS),RAst,_PL,attr(Rel,A,AS)) :- 
  !,
  argument_completion(attr(Rel,A,AS),RAst).
expr_argument_completion(E,RAst,PL,RE) :- 
  E =.. [F|Args],
  !, 
  expr_argument_completion_list(Args,RAst,PL,RArgs),
  RE =.. [F|RArgs].


expr_argument_completion_list([],_RAst,_PL,[]) :-
  !.
expr_argument_completion_list([E|Es],RAst,PL,[RE|REs]) :-
  !, 
  expr_argument_completion(E,RAst,PL,RE), 
  expr_argument_completion_list(Es,RAst,PL,REs).

argument_completion(attr(Rel,A,AS),RAst) :-
  (var(Rel) -> argument_completion_ng(attr(Rel,A,AS),RAst) ; true).

argument_completion_ng(attr(RT,C,_AS),(T,[RT|_RArgs])) :-
  attribute(_Nth,T,C).
argument_completion_ng(A,times(R1,R2)) :-
  argument_completion_ng(A,R1),
  !
  ;
  argument_completion_ng(A,R2).
argument_completion_ng(attr(AS,A,_AS),(pi(ProjList,sigma(_Cond,_Relations)),[AS|_Args])) :-
  find_argument(A,ProjList).
  
find_argument(A,[attr(_Rel,A,_RenA)|_As]) :-
  !.
find_argument(RenA,[attr(_Rel,_A,RenA)|_As]) :-
  !.
find_argument(A,[_|As]) :-
  find_argument(A,As).
  
rel_ren_projlist([],_AS,Ren,Ren).
rel_ren_projlist([attr(Rel,_Col,_ColRen)|As],AS,IRen,ORen) :-
  rel_ren_projlist(As,AS,[(AS,Rel)|IRen],ORen).

rel_arguments(Rel,RAst,IRen,ORen,RAs) :-
  arguments_completion(*,RAst,[],IRen,ORen,ProjList),
  (my_member((Rel,RelId),ORen) -> true ; RelId = Rel),
  filter_rel_arg(RelId,ProjList,RAs).

filter_rel_arg(_RelId,[],[]).
filter_rel_arg(RelId,[attr(RelId,A,AS)|RAs],[attr(RelId,A,AS)|FRAs]) :-
  !, 
  filter_rel_arg(RelId,RAs,FRAs).
filter_rel_arg(RelId,[_|RAs],FRAs) :-
  filter_rel_arg(RelId,RAs,FRAs).

% SQL condition to RA condition
sqlcond2racond(not(exists(Rel)),not(exists(RRel)),IRen,ORen) :-
  !,
  sqlst2rast(Rel,RRel,IRen,ORen).
sqlcond2racond(exists(Rel),exists(RRel),IRen,ORen) :-
  !,
  sqlst2rast(Rel,RRel,IRen,ORen).
sqlcond2racond(not(in(Args,Rel)),not(in(Args,RRel)),IRen,ORen) :-
  !,
  sqlst2rast(Rel,RRel,IRen,ORen).
sqlcond2racond(in(Args,Rel),in(Args,RRel),IRen,ORen) :-
  !,
  sqlst2rast(Rel,RRel,IRen,ORen).
sqlcond2racond(not(C),not(RC),IRen,ORen) :-
  !,
  sqlcond2racond(C,RC,IRen,ORen).
sqlcond2racond(SQLC,RAC,IRen,ORen) :-
  SQLC =.. [Op,L,R],
  my_sql_op(Op),
  !,
  sqlcond2racond(L,LRRel,IRen,Ren),
  sqlcond2racond(R,RRRel,Ren,ORen),
  RAC =.. [Op,LRRel,RRRel].
sqlcond2racond((SQLst,RR),RAst,IRen,ORen) :-
  var(RR),
  !,
  sqlst2rast((SQLst,RR),RAst,IRen,ORen).
sqlcond2racond(A,A,Ren,Ren) :-
  arguments_autorenaming(_R,[A]),
  !.
sqlcond2racond(C,C,Ren,Ren).

% SQL join condition to RA condition
sqljoincond2racond(equijoin(natural),C,_LAS,_RAS,IProjList,OProjList,Ren,Ren) :-
  !,
  eq_common_atts(IProjList,OProjList,C).
sqljoincond2racond(equijoin(Atts),C,LAS,RAS,ProjList,ProjList,Ren,Ren) :-
  !,
  build_equijoin(Atts,LAS,RAS,ProjList,C).
sqljoincond2racond(SQLCondition,RACondition,_LAS,_RAS,ProjList,ProjList,IRen,ORen) :-
  sqlcond2racond(SQLCondition,RACondition,IRen,ORen).

% IAtts: Input attribute list
% OAtts: Output attribute list (common attributes removed)
% EqCommonAtts: Output conjunctive equality condition on common attributes
eq_common_atts(IAtts,OAtts,EqCommonAtts) :-
  list_eq_common_atts(IAtts,OAtts,LEqCommonAtts),
  conjunctive_cond(LEqCommonAtts,EqCommonAtts).

list_eq_common_atts([],[],[]).
list_eq_common_atts([attr(RelA,A,RenA)|Atts],OAtts,[attr(RelA,A,RenA)=attr(RelB,A,RenB)|EqAtts]) :-
  my_member(attr(RelB,A,RenB),Atts),
  RelA \== RelB,
  !,
  list_eq_common_atts(Atts,OAtts,EqAtts).
list_eq_common_atts([Att|Atts],[Att|OAtts],EqAtts) :-
  list_eq_common_atts(Atts,OAtts,EqAtts).

build_equijoin([],_LAS,_RAS,_ProjList,true).
build_equijoin([attr(_RAtt,Att,_ArrRen)],[LAS|_LRArgs],[RAS|_RRArgs],ProjList,attr(LAS,Att,RA)=attr(RAS,Att,RB)) :-
  my_member(attr(LAS,Att,RA),ProjList),
  my_member(attr(RAS,Att,RB),ProjList).
build_equijoin([Att1,Att2|Atts],LAS,RAS,ProjList,and(C1,C2)) :-
  build_equijoin([Att1],LAS,RAS,ProjList,C1),
  build_equijoin([Att2|Atts],LAS,RAS,ProjList,C2).

% Building a conjunctive condition from a list of conditions
conjunctive_cond([],true) :-
  !.
conjunctive_cond([C],C) :-
  !.
conjunctive_cond([C1,C2],and(C1,C2)) :- 
  !.
conjunctive_cond([C|Cs],and(C,CC)) :- 
  conjunctive_cond(Cs,CC).

% SQL relation to RA relation
sqlrel2rarel([R],CR,IRen,ORen) :-
  sqlst2rast(R,CR,IRen,ORen).
sqlrel2rarel([A,B|Rs],times(CA,RRs),IRen,ORen) :-
  sqlst2rast(A,CA,IRen,Ren),
  sqlrel2rarel([B|Rs],RRs,Ren,ORen).
         

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% rast2crast(+RAst,-CRAst) Translates a 
% Relational Algebra Syntactic Tree into a
% Canonical Relational Algebra Syntactic Tree
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% EXISTS condition
rast2crast((pi(As,sigma(exists(Rel),Rs)),AS),
           (pi(As,sigma(exists(CRel),CRs)),AS)) :-
  !,
  rast2crast(Rel,CRel),
  rast2crast(Rs,CRs).

% IN condition
rast2crast((pi(As,sigma(in(Args,Rel),Rs)),AS),
           (pi(As,sigma(in(Args,CRel),CRs)),AS)) :-
  !,
  rast2crast(Rel,CRel),
  rast2crast(Rs,CRs).

% Basic condition
rast2crast((pi(As,sigma(C,Rs)),AS),
           (pi(As,sigma(CL,CRs)),AS)) :-
  (my_sql_op(Op),
   C =.. [Op,L,R],
   CL =.. [Op,CL,CR],
   rast2crast(L,CL),
   rast2crast(R,CR)
   ; 
   C=true
   ;
   C=false
  ),
  rast2crast(Rs,CRs),
  !.

% TIMES
rast2crast(times(R1,R2),times(CR1,CR2)) :-
  !,
  rast2crast(R1,CR1),
  rast2crast(R2,CR2).

% Table
rast2crast((T,AS),(T,AS)) :-
  table(T,_),
  !.
  
% AND condition
rast2crast((pi(As,sigma(and(C1,C2),Rs)),AS),
           (intersect(L,R),AS)) :-
  !,
  relation_autorenaming(RR1),
  relation_autorenaming(RR2),
  rast2crast((pi(As,sigma(C1,Rs)),[RR1|As]),L),
  rast2crast((pi(As,sigma(C2,Rs)),[RR2|As]),R). 
  
% OR condition
rast2crast((pi(As,sigma(or(C1,C2),Rs)),AS),
           (union(L,R),AS)) :-
  !,
  relation_autorenaming(RR1),
  relation_autorenaming(RR2),
  rast2crast((pi(As,sigma(C1,Rs)),[RR1|As]),L),
  rast2crast((pi(As,sigma(C2,Rs)),[RR2|As]),R). 

% NOT condition
rast2crast((pi(As,sigma(not(C),Rs)),AS),
           (minus((pi(As,sigma(true,Rs)),[RR|As]),R),AS)) :-
  !,
  relation_autorenaming(RR),
  rast2crast((pi(As,sigma(C,Rs)),[RR|As]),R). 
  
% UNION operator
rast2crast((union(RA1,RA2),AS),(union(CRA1,CRA2),AS)) :-
  !,
  rast2crast(RA1,CRA1),
  rast2crast(RA2,CRA2). 

% INTERSECT operator
rast2crast((intersect(RA1,RA2),AS),(intersect(CRA1,CRA2),AS)) :-
  !,
  rast2crast(RA1,CRA1),
  rast2crast(RA2,CRA2). 

% MINUS operator
rast2crast((minus(RA1,RA2),AS),(minus(CRA1,CRA2),AS)) :-
  !,
  rast2crast(RA1,CRA1),
  rast2crast(RA2,CRA2). 

% Argument
rast2crast(A,A) :-
  !.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% crast2dlsts(+CRAst,+Number,-LastNbr,+Mapping,-OMapping,
%             +Renaming,-ORenaming,-DLsts) 
% Translates a Canonical Relational Algebra Syntactic Tree 
% CRAst into a list of Datalog Syntactic Trees DLsts
% Mapping holds the correspondence between table columns and
% goal arguments 
% Renaming holds the already computed table and subquery renamings 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

crast2dlsts((union(R1,R2),[RR|RArgs]),N,LN,IMap,OMap,IRen,ORen,DLsts) :-
  !,
  N1 is N+1,
  crast2dlsts(R1,N1,N2,IMap,Map1,IRen,SRen,DLsts1),
  N3 is N2+1,
  DLsts1 = [':-'(H1,_)|_],
  crast2dlsts(R2,N3,LN,Map1,Map2,SRen,ORen,DLsts2),
  DLsts2 = [':-'(H2,_)|_],
  H1 =.. [_|A1s],
  H2 =.. [_|A2s],
  build_id(p,N,_,PN),
  HH1 =.. [PN|A1s],
  HH2 =.. [PN|A2s],
  my_append([':-'(HH1,H1),':-'(HH2,H2)|DLsts1],DLsts2,DLsts),
  map_rel_id_var(RR,RArgs,A1s,Map2,OMap).
crast2dlsts((minus(R1,R2),[RR|RArgs]),N,LN,IMap,OMap,IRen,ORen,DLsts) :-
  !,
  N1 is N+1,
  crast2dlsts(R1,N1,N2,IMap,Map1,IRen,SRen,DLsts1),
  N3 is N2+1,
  DLsts1 = [':-'(SG1,_)|_],
  crast2dlsts(R2,N3,LN,Map1,Map2,SRen,ORen,DLsts2),
  DLsts2 = [':-'(H2,_)|_],
  SG1 =.. [_|A1s],
  H2 =.. [P2|_],
  SG2 =.. [P2|A1s],
  build_id(p,N,_,PN),
  HH1 =.. [PN|A1s],
  my_append([':-'(HH1,(SG1,not(SG2)))|DLsts1],DLsts2,DLsts),
  map_rel_id_var(RR,RArgs,A1s,Map2,OMap).
crast2dlsts((intersect(R1,R2),[RR|RArgs]),N,LN,IMap,OMap,IRen,ORen,DLsts) :-
  !,
  N1 is N+1,
  crast2dlsts(R1,N1,N2,IMap,Map1,IRen,SRen,DLsts1),
  N3 is N2+1,
  DLsts1 = [':-'(SG1,_)|_],
  crast2dlsts(R2,N3,LN,Map1,Map2,SRen,ORen,DLsts2),
  DLsts2 = [':-'(H2,_)|_],
  SG1 =.. [_|A1s],
  H2 =.. [P2|_],
  SG2 =.. [P2|A1s],
  build_id(p,N,_,PN),
  HH1 =.. [PN|A1s],
  my_append([':-'(HH1,(SG1,SG2))|DLsts1],DLsts2,DLsts),
  map_rel_id_var(RR,RArgs,A1s,Map2,OMap).
% Build the datalog rule for a pi operator:
% - rel_subgoals builds the conjunction of source relations (times)
%   It also computes the mapping of variables' subgoals to columns
% - expr_subgoals builds the subgoals for expressions in the projection list
% - map_cols maps the projection list (ArgList) with the head arguments
% - build_id generates the name of the predicate (head)
% - cond_subgoals adds the condition to the subgoals
crast2dlsts((pi(ArgList,sigma(Condition,Relation)),[_RR|ArgList]),
            N,LN,IMap,OMap,IRen,ORen,[':-'(Head,Body)|DLsts]) :-
  !,
  rel_subgoals(Relation,N,N1,SGs,DLsts1,IMap,Map1,IRen,SRen),
%  simplify_arglist_expr(ArgList,SArgList),
  expr_subgoals(ArgList,Map1,Map2,SRen,SGs,ESGs),
  reorder_goals(ESGs,RESGs),
  map_cols(ArgList,Map2,SRen,Args),
  build_id(p,N,_,PN),
  Head =.. [PN|Args],
  cond_subgoals(Condition,N1,LN,Map2,OMap,SRen,ORen,DLsts2,RESGs,Body),
  my_append(DLsts1,DLsts2,DLsts).

% simplify_arglist_expr([],[]).
% simplify_arglist_expr([expr(attr(Rel,C,_RC),AS)|Args],[attr(Rel,C,AS)|SArgs]) :-
%   !,
%   simplify_arglist_expr(Args,SArgs).
% simplify_arglist_expr([Arg|Args],[Arg|SArgs]) :-
%   !,
%   simplify_arglist_expr(Args,SArgs).

expr_subgoals(ArgList,IMap,OMap,Ren,ISGs,OSGs) :-
  build_expr_mappings(ArgList,IMap,OMap),
  build_expr_subgoals(ArgList,OMap,Ren,ISGs,OSGs).

build_expr_mappings([],Map,Map).
build_expr_mappings([expr(_SQLExpr,AS)|Args],IMap,OMap) :-
  build_expr_mappings(Args,[(_Var,_,AS)|IMap],OMap).
build_expr_mappings([_Arg|Args],IMap,OMap) :-
  build_expr_mappings(Args,IMap,OMap).

build_expr_subgoals([],_Map,_Ren,SGs,SGs).
build_expr_subgoals([expr(SQLExpr,AS)|Args],Map,Ren,ISGs,OSGs) :-
  !,
  translate_expr(SQLExpr,DLExpr,Map,Ren),
  my_member((Var,_,AS),Map),
  tuple_append(ISGs,is(Var,DLExpr),NISGs),
  build_expr_subgoals(Args,Map,Ren,NISGs,OSGs).
build_expr_subgoals([_Arg|Args],Map,Ren,ISGs,OSGs) :-
  build_expr_subgoals(Args,Map,Ren,ISGs,OSGs).

translate_expr(E,E,_Map,_Ren) :-
  (number(E) ; atom(E)),
  !.
translate_expr(attr(Rel,Col,AS),Var,Map,Ren) :-
  !,
  map_cols([attr(Rel,Col,AS)],Map,Ren,[Var]).
translate_expr(expr_ref(AS),Var,Map,_Ren) :-
  !,
  my_member((Var,_,AS),Map).
translate_expr(SQLE,DLE,Map,Ren) :- 
  SQLE =.. [F|SQLArgs],
  !, 
  translate_expr_list(SQLArgs,DLArgs,Map,Ren),
  DLE =.. [F|DLArgs].

translate_expr_list([],[],_Map,_Ren) :-
  !.
translate_expr_list([T|Ts],[RT|RTs],Map,Ren) :-
  !, 
  translate_expr(T,RT,Map,Ren), 
  translate_expr_list(Ts,RTs,Map,Ren).

rel_subgoals(times(RelA,B),N,LN,(SGA,As),DLsts,IMap,OMap,IRen,ORen) :-
  !, 
  build_subgoal(RelA,N,N1,SGA,DLsts1,IMap,SGMap,IRen,SRen), 
  rel_subgoals(B,N1,LN,As,DLsts2,SGMap,OMap,SRen,ORen),
  my_append(DLsts1,DLsts2,DLsts).
rel_subgoals(Rel,N,LN,SG,DLsts,IMap,OMap,IRen,ORen) :-
  build_subgoal(Rel,N,LN,SG,DLsts,IMap,OMap,IRen,ORen).

build_subgoal((Table,[TableId|_RArgs]),N,N,SG,[],IMap,OMap,Ren,Ren) :-
  table(Table,Arity), 
  !,
  Length is Arity+1, 
  length(SGs,Length),
  SGs=[Table|Vars], 
  SG=..SGs, 
  map_table_id_var((Table,TableId),Vars,1,IMap,OMap,Ren).
build_subgoal((pi(ArgList,R),[RR|RArgs]),N,LN,SG,DLsts,IMap,OMap,IRen,ORen) :-
  !,
  N1 is N+1,
  crast2dlsts((pi(ArgList,R),[RR|RArgs]),N1,LN,IMap,Map1,IRen,ORen,DLsts),
  DLsts = [':-'(SG,_)|_],
  SG=..[_|Vars],
  map_rel_id_var(RR,ArgList,Vars,Map1,OMap).
build_subgoal(Rel,N,LN,SG,DLsts,IMap,OMap,IRen,ORen) :-
  N1 is N+1,
  crast2dlsts(Rel,N1,LN,IMap,OMap,IRen,ORen,DLsts),
  DLsts = [':-'(SG,_)|_].
 
% map_rel_id_var(+AS,+ArgList,+Vars,+IMap,-OMap)
map_rel_id_var(_AS,[],[],Mapping,Mapping).
map_rel_id_var(AS,[attr(_,Col,ColRen)|Cols],[Var|Vars],IMap,OMap) :-
  !,
  map_rel_id_var(AS,Cols,Vars,[(Var,AS,Col),(Var,AS,ColRen)|IMap],OMap).
map_rel_id_var(AS,[attr(_,Col,_ColRen)|Cols],[Var|Vars],IMap,OMap) :-
  map_rel_id_var(AS,Cols,Vars,[(Var,AS,Col)|IMap],OMap).
  
map_table_id_var((_Table,_TableId),[],_,Mapping,Mapping,_Renaming).
map_table_id_var((Table,TableId),[Var|Vars],N,Mapping,Mapping,Renaming) :-
  my_member((Table,TableId),Renaming),
  attribute(N,Table,Col), 
  my_member((Var,TableId,Col),Mapping), 
  !,
  N1 is N+1, 
  map_table_id_var((Table,TableId),Vars,N1,Mapping,Mapping,Renaming).
map_table_id_var((Table,TableId),[Var|Vars],N,IMapping,OMapping,Renaming) :-
  my_member((Table,TableId),Renaming),
  attribute(N,Table,Col), 
  N1 is N+1, 
  map_table_id_var((Table,TableId),Vars,N1,[(Var,TableId,Col)|IMapping],OMapping,Renaming).

% map_cols(+Cols,+Mapping,+Renaming,-Arguments)
% maps a list of projected arguments with the arguments of the head
map_cols([],_Mapping,_Renaming,[]).
map_cols([attr(TableId,_Col,ColRen)|Cols],Mapping,Renaming,[Var|Xs]) :-
  my_member((Var,TableId,ColRen),Mapping), 
  !, 
  map_cols(Cols,Mapping,Renaming,Xs).
map_cols([attr(TableId,Col,_ColRen)|Cols],Mapping,Renaming,[Var|Xs]) :-
  my_member((Var,TableId,Col),Mapping), 
  !, 
  map_cols(Cols,Mapping,Renaming,Xs).
map_cols([attr(Table,Col,_ColRen)|Cols],Mapping,Renaming,[Var|Xs]) :-
  my_member((Table,TableId),Renaming),
  my_member((Var,TableId,Col),Mapping), 
  !, 
  map_cols(Cols,Mapping,Renaming,Xs).
map_cols([expr(_Expr,ColRen)|Cols],Mapping,Renaming,[Var|Xs]) :-
  my_member((Var,_TableId,ColRen),Mapping), 
  !, 
  map_cols(Cols,Mapping,Renaming,Xs).
map_cols([Constant|Cols],Mapping,Renaming,[Constant|Xs]) :-
  atomic(Constant), 
  map_cols(Cols,Mapping,Renaming,Xs).

cond_subgoals(C,N,LN,IMap,OMap,IRen,ORen,DLsts,SGs,Body) :-
  translate_cond(C,N,LN,IMap,OMap,IRen,ORen,DLsts,NC),
  tuple_append(SGs,NC,Body).

translate_cond(true,N,N,Map,Map,Ren,Ren,[],('.')) :- 
  !.
translate_cond(false,N,N,Map,Map,Ren,Ren,[],(false)) :- 
  !.
% translate_cond('='(A,B),N,N,Map,Map,Ren,Ren,[],('.')) :-
%   map_cols([A,B],Map,Ren,[VA,VB]),
%   (var(VA); var(VB)), !,
%   VA=VB.
translate_cond(not(C),N,LN,IMap,OMap,IRen,ORen,[],not(NC)) :-
  translate_cond(C,N,LN,IMap,OMap,IRen,ORen,_SG,NC).
% 'and' and 'or' conditions do not longer occur at this stage
%translate_cond(and(C1,C2),Mapping,Renaming,NC) :-
%  translate_cond(C1,Mapping,Renaming,NC1),
%  translate_cond(C2,Mapping,Renaming,NC2),
%  tuple_append(NC1,NC2,NC).
%translate_cond(or(C1,C2),Mapping,(NC1;NC2)) :-
%  translate_cond(C1,Mapping,NC1),
%  translate_cond(C2,Mapping,NC2).
translate_cond(exists(Rel),N,LN,IMap,OMap,IRen,ORen,DLsts,(Goal)) :-
  N1 is N+1,
  build_id(p,N1,_,_PN),
  crast2dlsts(Rel,N1,LN,IMap,OMap,IRen,ORen,UDLsts),
  add_corr_vars(UDLsts,DLsts),
  DLsts=[':-'(Goal,_)|_].
translate_cond(in(Args,Rel),N,LN,IMap,OMap,IRen,ORen,DLsts,(Goal)) :-
  N1 is N+1,
  build_id(p,N1,_,_PN),
  map_cols(Args,IMap,IRen,Vars),
  crast2dlsts(Rel,N1,LN,IMap,OMap,IRen,ORen,UDLsts),
  add_corr_vars(UDLsts,DLsts),
  DLsts=[':-'(Goal,_)|_],
  Goal =.. [_F|GVars],
  my_append(Vars,_CorrVars,GVars).
% Condition with LHS DQL
translate_cond(C,N,LN,IMap,OMap,IRen,ORen,DLsts,(Goal,NC)) :-
  C=..[RelOp,Rel,Arg],
  my_sql_constant_or_column(Arg),
  my_dql_relation(Rel),
  !,
  N1 is N+1,
  build_id(p,N1,_,_PN),
  map_cols([Arg],IMap,IRen,[Var]),
  crast2dlsts(Rel,N1,LN,IMap,OMap,IRen,ORen,DLsts),
  map_cond(RelOp,DLOp),
  NC=..[DLOp,GVar,Var],
  DLsts=[':-'(Goal,_Body)|_Rules],
  Goal =.. [_F,GVar].
% Condition with RHS DQL
translate_cond(C,N,LN,IMap,OMap,IRen,ORen,DLsts,(Goal,NC)) :-
  C=..[RelOp,Arg,Rel],
  my_sql_constant_or_column(Arg),
  my_dql_relation(Rel),
  !,
  N1 is N+1,
  build_id(p,N1,_,_PN),
  map_cols([Arg],IMap,IRen,[Var]),
  crast2dlsts(Rel,N1,LN,IMap,OMap,IRen,ORen,DLsts),
  map_cond(RelOp,DLOp),
  NC=..[DLOp,Var,GVar],
  DLsts=[':-'(Goal,_Body)|_Rules],
  Goal =.. [_F,GVar].
% Condition between DQL
translate_cond(C,N,LN,IMap,OMap,IRen,ORen,DLsts,(LGoal,RGoal,NC)) :-
  C=..[RelOp,LRel,RRel],
  my_dql_relation(LRel),
  my_dql_relation(RRel),
  !,
  N1 is N+1,
  build_id(p,N1,_,_PN),
  crast2dlsts(LRel,N1,N2,IMap,Map,IRen,Ren,LDLsts),
  N3 is N2+1,
  crast2dlsts(RRel,N3,LN,Map,OMap,Ren,ORen,RDLsts),
  map_cond(RelOp,DLOp),
  NC=..[DLOp,LGVar,RGVar],
  LDLsts=[':-'(LGoal,_LBody)|_LRules],
  LGoal =.. [_LF,LGVar],
  RDLsts=[':-'(RGoal,_RBody)|_RRules],
  RGoal =.. [_RF,RGVar],
  my_append(LDLsts,RDLsts,DLsts).
%Basic condition between columns or constants:
translate_cond(C,N,N,Map,Map,Ren,Ren,[],(NC)) :-
  C=..[RelOp|Args],
  map_cols(Args,Map,Ren,Vars),
  map_cond(RelOp,DLOp),
  NC=..[DLOp|Vars].

my_dql_relation((_SQLst,RR)) :-
  RR \= (_C,_R).

my_sql_constant_or_column(Arg) :-
  number(Arg),
  !.
my_sql_constant_or_column(Arg) :-
  atomic(Arg),
  !.
my_sql_constant_or_column(attr(_RT,C,_R)) :-
  attribute(_P,_T,C),
  !.

my_sql_op(Op) :-
  map_cond(Op,_).

% map_cond(+RelationalOperator,-DatalogOperator).
map_cond('<=','=<').
map_cond('=','=').
map_cond('<>','\\='). 
map_cond('>=','>=').
map_cond('>','>').
map_cond('<','<').

% adds correlated variables
add_corr_vars(UDLsts,DLsts) :-
  (bagof(HVars,
          L1^H^B^L2^
          (my_append(L1,[':-'(H,B)|L2],UDLsts),
           my_term_variables(H,HVars)),
          HVarss) ->
   true ; HVarss = []),
  my_flatten(HVarss,FHVars),
  (bagof(BVars,
          L1^H^B^L2^
          (my_append(L1,[':-'(H,B)|L2],UDLsts),
           my_term_variables(B,BVars)),
          BVarss) ->
   true ; HVarss = []),
  my_flatten(BVarss,FBVars),
  my_subtract_var(FHVars,FBVars,FCVars),
  add_head_vars(FCVars,UDLsts,DLsts).

add_head_vars(_FCVars,[],[]).
add_head_vars(FCVars,[':-'(H,B)|UDLsts],[':-'(HC,B)|DLsts]) :-
  H =.. [P|HVars],
  my_append(HVars,FCVars,HCVars),
  HC =.. [P|HCVars],
  add_head_vars(FCVars,UDLsts,DLsts).

my_subtract_var([],L,L).
my_subtract_var([X|Xs],From,L) :-
  my_remove(X,From,To),
  !,
  my_subtract_var(Xs,To,L).

my_remove(_X,[],[]).
my_remove(X,[Y|Ys],Zs) :-
  X==Y,
  !,
  my_remove(X,Ys,Zs).
my_remove(X,[Y|Ys],[Y|Zs]) :-
  my_remove(X,Ys,Zs).

% my_flatten(Xs,Ys) is true if Ys is a list of the elements in Xs.
% e.g. my_flatten([[[3,c],5,[4,[]]],[1,b],a],[3,c,5,4,1,b,a]).    
my_flatten(Xs,Ys) :-
  my_flatten(Xs,[],Ys).

my_flatten(X,As,[X|As]) :-
  var(X),
  !.
my_flatten([X|Xs],As,Ys) :- 
  my_flatten(Xs,As,As1), 
  my_flatten(X,As1,Ys).
my_flatten(X,As,[X|As]) :-
  integer(X).
my_flatten(X,As,[X|As]) :-
  atom(X), 
  X\=[].
my_flatten([],Ys,Ys).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ancillary Stuff
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% build_id(+Name,+InputId,-OutputId,-IdName) 
% Returns an identifier of the form: '$<Name><InputId>' and
% also the next Id number .
% e.g., build_id(p,1,2,'$p1')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

build_id(O,IId,OId,Id) :-
  OId is IId+1,
  atom_concat('$',O,TO),
  atom_codes(TO,STO),
  number_codes(IId,SIId),
  my_append(STO,SIId,SId),
  atom_codes(Id,SId).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% build_id(+Name,-IdName) 
% Returns an identifier of the form: '$<Name><Id>'
% e.g., build_id(p,'$p1')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

build_id(O,Id) :-
  (retract(id(O,IId)) -> 
   OId is IId+1
   ; 
   OId is 1),
  assertz(id(O,OId)),
  atom_concat('$',O,TO),
  atom_codes(TO,STO),
  number_codes(OId,SOId),
  my_append(STO,SOId,SId),
  atom_codes(Id,SId).

reset_id :-
  retractall(id(_O,_I)).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% insert_tuples(+TableName,+Arity)) 
% Insert computed tuples (kept in the extension table)
% from a SQL statement into a table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

insert_tuples(TableName,Arity) :-
  N=answer,
  et(R),
  functor(R,N,A),
  !,
  (A==Arity ->
   bagof((Fact,[]),
         F^(
         (et(Fact), functor(Fact,N,A)); 
         (et(Fact), (Fact=not(F)), functor(F,N,A)) 
         ),
         Set),
   replace_functor(N,TableName,Set,RSet),
   assert_rules(RSet,_Error),
   display_nbr_of_tuples(RSet,inserted)
   ;
   write_log_list(['Error: Incorrect number of arguments.'])).
insert_tuples(_TableName,_Arity) :-
  write_log_list(['Warning: No tuples inserted because of empty result set.',nl]).

% Replaces all occurrences of functor O by N in a term T
replace_functor(_O,_N,T,T) :- 
  (number(T) ; atom(T) ; var(T)),
  !.
replace_functor(O,N,C,RC) :- 
  C =.. [F|As],
  !, 
  (F == O -> RF = N ; RF = F),
  replace_functor_list(O,N,As,RAs),
  RC =.. [RF|RAs].

replace_functor_list(_O,_N,[],[]) :-
  !.
replace_functor_list(O,N,[T|Ts],[RT|RTs]) :-
  !, 
  replace_functor(O,N,T,RT), 
  replace_functor_list(O,N,Ts,RTs).

% Replaces all occurrences in a term T of functors starting by O by the same functor but replacing N by O
replace_functor_substring(_O,_N,T,T) :- 
  (number(T) ; atom(T) ; var(T)),
  !.
replace_functor_substring(O,N,C,RC) :- 
  C =.. [F|As],
  !, 
  (atom_concat(O,R,F) -> atom_concat(N,R,RF) ; RF = F),
  replace_functor_substringL(O,N,As,RAs),
  RC =.. [RF|RAs].

replace_functor_substringL(_O,_N,[],[]) :-
  !.
replace_functor_substringL(O,N,[T|Ts],[RT|RTs]) :-
  !, 
  replace_functor_substring(O,N,T,RT), 
  replace_functor_substringL(O,N,Ts,RTs).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% delete_tuples(+TableName,+Arity)) 
% Delete computed tuples (kept in the extension table)
% from a SQL statement from a table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

delete_tuples(TableName,Arity) :-
  N=answer,
  et(R),
  functor(R,N,A),
  !,
  (A==Arity ->
   bagof((Fact,[]),
         F^(
         (et(Fact), functor(Fact,N,A)); 
         (et(Fact), (Fact=not(F)), functor(F,N,A)) 
         ),
         Set),
   replace_functor(N,TableName,Set,RSet),
   retract_rules(RSet,_Error),
   display_nbr_of_tuples(RSet,deleted)
   ;
   write_log_list(['Error: Incorrect number of arguments.'])).
delete_tuples(_TableName,_Arity) :-
  write_log_list(['Warning: No tuples deleted because of empty result set.',nl]).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% tuple_append(+Tuple1,+Tuple2,-Tuple) Appends the two input
%   tuples, returning a concatenated tuple
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Test cases:
% tuple_append((a,b,c),(d),(a, b, c, d))
% tuple_append((a,b,c),(d,e),(a, b, c, d, e))
tuple_append(('.'), A, A) :- !.
tuple_append(A, ('.'), A) :- !.
tuple_append((A,B), C, (A,D)) :-
  !, 
  tuple_append(B, C, D).
tuple_append(A, B, (A,B)).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Display a SQL statement from its syntactic tree
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

display_sql(SQL) :-
  display_sql(SQL,0).

display_sql(SQL,I) :-
  (pretty_print(off) -> write_indent(I) ; true),
  write_sql(SQL,I),
  write_log(';'),
  nl_log.

write_sql((SQL,_C),I) :-
  !,
  write_sql(SQL,I).
write_sql(with(SQLst,SQLsts),I) :-
  !,
  pp_indent(I),
  write_log_string("WITH "),
  pp_nl_or_blank,
  I1 is I+2,
  write_sql_list(SQLsts,I1),
  pp_nl_or_blank,
  write_sql(SQLst,I).
write_sql(select(_DistinctAll,As,from(Rs),where(Cs)),I) :-
  !,
  pp_indent(I),
  write_log_string("SELECT "),
%  (DistinctAll=distinct -> write_log_string("DISTINCT ") ; write_log_string("ALL ")),
  write_proj_list(As),
  pp_nl_or_blank,
  pp_indent(I),
  write_log_string("FROM "),
  write_rel_list(Rs),
  (Cs == true ->
   true
   ;
   pp_nl_or_blank,
   pp_indent(I),
   write_log_string("WHERE "),
   write_sql_cond(Cs,I)
   ).
write_sql(SetSQL,I) :-
  SetSQL =.. [SetOp,LSQLst,RSQLst],
  I1 is I+2,
  pp_indent_or_blank(I),
  write_log('('),
  pp_nl_or_blank,
  write_sql(LSQLst,I1),
  pp_nl_or_blank,
  pp_indent(I),
  write_log(')'),
  name(SetOp,SetOps),
  to_uppercase_list(SetOps,CSetOps),
  pp_nl_or_blank,
  pp_indent(I),
  write_log_string(CSetOps),
  pp_nl_or_blank,
  pp_indent(I),
  write_log('('),
  pp_nl_or_blank,
  write_sql(RSQLst,I1),
  pp_nl_or_blank,
  pp_indent(I),
  write_log(')').

write_sql_list([],_I).
write_sql_list([(SQLst,AS)],I) :-
  pp_indent_or_blank(I),
  write_log_list([AS,' AS']),
  pp_nl_or_blank,
  I1 is I+2,
  write_sql((SQLst,AS),I1).
write_sql_list([(SQLst,AS),SQLst2|SQLsts],I) :-
  write_sql_list([(SQLst,AS)],I),
  write_log(','),
  pp_nl_or_blank,
  write_sql_list([SQLst2|SQLsts],I).
  
pp_indent(I) :-
  (pretty_print(on) -> write_indent(I) ; true).

pp_indent_or_blank(I) :-
  (pretty_print(on) -> write_indent(I) ; write_log(' ')).

pp_nl_or_blank :-
  (pretty_print(on) -> 
     nl_log
     ;
     write_log(' ')
  ).

pp_nl :-
  (pretty_print(on) -> 
     nl_log
     ;
     true
  ).

% verbose(on) shows table names from autorenaming

write_proj_list(*) :-
  write_log(*).
write_proj_list([]).
write_proj_list([expr(E,AS)]) :-
  !,
  write_expr(E),
  (atom_concat('$',_,AS), verbose(off) -> 
   true 
   ;
   write_log(' AS '),
   write_log(AS)).
write_proj_list([attr(T,A,R)]) :-
  !,
  write_attr(attr(T,A,R)).
write_proj_list([(T,(*))]) :-
  !,
  write_log_list([T,'.',*]).
write_proj_list([A]) :-
  write_log(A).
write_proj_list([A1,A2|As]) :-
  write_proj_list([A1]),
  write_log(', '),
  write_proj_list([A2|As]).
  
write_attr(attr(T,A,_R)) :-
  (atom_concat('$',_,T), verbose(off) -> 
   true 
   ;
   write_log(T),
   write_log('.')),
  write_log(A).

write_expr(E) :-
  (number(E) ; atom(E)),
  !,
  write_log(E).
write_expr(attr(Rel,A,AS)) :- 
  !,
  write_attr(attr(Rel,A,AS)).
write_expr(E) :- 
  E =.. [Op,Arg],
  unary_operator(Op,_POp,_D),
  !,
  write_log_list([Op,'(']),
  write_expr(Arg),
  write_log(')').
write_expr(E) :- 
  E =.. [Op,Arg1,Arg2],
  my_infix_arithmetic(Op,_POp,_D,_P),
  !,
  write_expr(Arg1),
  write_log_list([' ',Op,' ']),
  write_expr(Arg2).
write_expr(E) :- 
  E =.. [F|Args],
  !, 
  write_log_list([F,'(']),
  write_expr_list(Args),
  write_log(')').

write_expr_list([E]) :-
  write_expr(E).
write_expr_list([E1,E2|Es]) :-
  !, 
  write_expr(E1),
  write_log(','), 
  write_expr_list([E2|Es]).

write_sql_arg_list([attr(T,A,_R)],I) :-
  !,
  (atom_concat('$',_,T), verbose(off) -> 
   true 
   ;
   write_log(T),
   write_log('.')),
  write_sql_arg(A,I).
write_sql_arg_list([A],I) :-
  write_sql_arg(A,I).
write_sql_arg_list([A1,A2|As],I) :-
  write_sql_arg_list([A1],I),
  write_log(', '),
  write_sql_arg_list([A2|As],I).

write_sql_arg(A,_I) :-
  number(A), 
  !,
  write_log(A).
write_sql_arg(A,_I) :-
  atomic(A), 
  sql_cte(A),
  !,
  write_log_list(['\'',A,'\'']).
write_sql_arg((SQLst,RR),I) :-
  !,
  pp_nl,
  pp_indent(I),
  write_log('('),
  pp_nl,
  I1 is I+2,
  write_sql((SQLst,RR),I1),
  write_log(')').
write_sql_arg(A,_I) :-
  write_log(A).

sql_cte(C) :-
  my_not(sql_object(C)).

sql_object(C) :-
  attribute(_P,_T,C),
  !.
sql_object(C) :-
  table(C,_A).

write_rel_list([]).
write_rel_list([(R,[RR|_RArgs])]) :-
  !,
  write_log(R),
  (atom_concat('$',_,RR), verbose(off) -> 
   true
   ;
   write_log(' AS '),
   write_log(RR)
  ).
write_rel_list([R]) :-
  write_log(R).
write_rel_list([R1,R2|Rs]) :-
  write_rel_list([R1]),
  write_log(', '),
  write_rel_list([R2|Rs]).
  
write_sql_cond(and(C1,C2),I) :-
  write_log('('),
  write_sql_cond(C1,I),
  write_log(' AND '),
  write_sql_cond(C2,I),
  write_log(')').
write_sql_cond(or(C1,C2),I) :-
  write_log('('),
  write_sql_cond(C1,I),
  write_log(' OR '),
  write_sql_cond(C2,I),
  write_log(')').
write_sql_cond(exists((SQL,_C)),I) :-
  write_log('EXISTS ('),
  pp_nl_or_blank,
  I1 is I+2,
  write_sql(SQL,I1),
  write_log(' )').
write_sql_cond(in(Args,SQL),I) :-
  write_log('('),
  write_sql_arg_list(Args,I),
  write_log(') IN ('),
  pp_nl_or_blank,
  I1 is I+2,
  write_sql(SQL,I1),
  write_log(' )').
write_sql_cond(not(in(Args,SQL)),I) :-
  write_log('('),
  write_sql_arg_list(Args,I),
  write_log(') NOT IN ('),
  pp_nl_or_blank,
  I1 is I+2,
  write_sql(SQL,I1),
  write_log(' )').
write_sql_cond(not(C),I) :-
  write_log('NOT'),
  write_log('('),
  write_sql_cond(C,I),
  write_log(')').
write_sql_cond(C,I) :-
  C =.. [Op,A1,A2],
  !,
  write_sql_arg_list([A1],I),
  write_log(' '),
  write_log(Op),
  write_log(' '),
  write_sql_arg_list([A2],I).
write_sql_cond(C,_I) :-
  write_log(C).

write_ra_cond(exists((_RA,AS,_SQL)),I) :-
  !,
  write_indent(I),
  write_log('exists('),
  write_log(AS),
  write_log(')').
write_ra_cond(C,I) :-
  write_sql_cond(C,I).

write_indent(0) :-
  !.
write_indent(I) :- 
  write_log(' '),
  I1 is I-1,
  write_indent(I1).

